# Framework Documentation

Welcome to the comprehensive documentation for the Playwright + Cucumber.js automation framework.

## Quick Links

### Getting Started

- [Architecture Overview](Architecture.md) - Framework architecture and design patterns
- [Project Structure](Project-Structure.md) - Detailed folder and file organization
- [Configuration Guide](Configuration.md) - Environment variables and runtime settings

### Development

- [Adding New Tests](Adding-New-Test.md) - Step-by-step guide for creating tests
- [Coding Guidelines](Coding-Guidelines.md) - Standards and best practices
- [Framework Components](Framework-Components.md) - Page Objects, Hooks, Utilities

### Execution & Debugging

- [Execution Flow](Execution-Flow.md) - End-to-end test execution lifecycle
- [Sequence Diagrams](Sequence-Diagrams.md) - Visual flow diagrams
- [Debugging Guide](Debugging.md) - Troubleshooting and debugging techniques

### Reporting

- [Reporting Guide](Reporting.md) - Report generation and interpretation

## Documentation Structure

### 1. Architecture.md

**What it covers:**

- Architectural layers (Test, Step Definitions, Page Objects, Utilities, Hooks, Configuration, Test Data, Reporting)
- Design patterns (POM, Factory, Singleton, Strategy, Helper)
- Technology stack
- Framework strengths and limitations
- Recommended improvements

**When to read:** Understanding overall framework design and architecture decisions

### 2. Execution-Flow.md

**What it covers:**

- Complete execution flow from command to report
- Phase-by-phase breakdown (Command Execution, Configuration Loading, Feature Discovery, Worker Initialization, Hooks, Step Execution, Cleanup, Reporting)
- UI, API, and Accessibility test flows
- Parallel execution
- Environment-based execution
- Browser selection (local and BrowserStack)

**When to read:** Understanding what happens during test execution

### 3. Sequence-Diagrams.md

**What it covers:**

- Visual representations of key flows:
    - Complete test execution lifecycle
    - UI test step execution
    - API test execution
    - Accessibility test execution
    - Browser launch (local vs BrowserStack)
    - Page object interactions
    - Test data loading
    - Report generation
    - Parallel execution
    - Screenshot and video capture

**When to read:** Visual learners, understanding component interactions

### 4. Project-Structure.md

**What it covers:**

- Complete directory tree
- Detailed explanation of each folder and file
- File naming conventions
- Folder organization principles
- Auto-generated directories
- Recommendations for improvement

**When to read:** Navigating the project, understanding file organization

### 5. Configuration.md

**What it covers:**

- Configuration files (cucumber.js, playwright.config.js, package.json)
- Environment variables (NODE_ENV, BROWSER, RECORD_VIDEO, PARALLEL_THREAD, BrowserStack)
- NPM scripts (UI tests, API tests, Accessibility tests, BrowserStack tests)
- Browser configuration (local and BrowserStack)
- Test data configuration (YAML and JSON)
- Video recording, parallel execution, timeouts
- Report configuration
- Best practices and troubleshooting

**When to read:** Configuring test execution, setting up environments

### 6. Framework-Components.md

**What it covers:**

- Page Objects (POManager, CommonPageObjects, DemoQAMainPage, DemoQAElementPage)
- Hooks (Before, BeforeStep, After, AfterStep)
- Step Definitions (UI and API)
- Utilities (UIHelper, APIUtils, BrowserUtils, AccessibilityHelper, TestDataUtils)
- Constants (BrowserConstants)
- Component interaction flows

**When to read:** Understanding framework components, adding new components

### 7. Reporting.md

**What it covers:**

- Report types (Cucumber JSON, Cucumber HTML, Multiple Cucumber HTML, Accessibility, Allure)
- Report generation workflow
- Report interpretation (status indicators, duration, attachments, impact levels)
- Report attachments (screenshots, videos, JSON)
- CI/CD integration
- Best practices

**When to read:** Generating reports, interpreting results, CI/CD setup

### 8. Coding-Guidelines.md

**What it covers:**

- General principles (Readability, DRY, KISS, Maintainability)
- JavaScript coding standards (naming, formatting, async/await, error handling, logging)
- Gherkin guidelines (feature structure, best practices, tags)
- Page Object guidelines (structure, best practices)
- Step Definition guidelines (structure, best practices)
- Utility guidelines (structure, best practices)
- Test Data guidelines (YAML, JSON, best practices)
- Git commit guidelines
- Code review checklist
- Anti-patterns to avoid
- Performance and security best practices

**When to read:** Before contributing, during code reviews

### 9. Adding-New-Test.md

**What it covers:**

- Step-by-step guide for adding UI tests
- Step-by-step guide for adding API tests
- Step-by-step guide for adding Accessibility tests
- Adding custom NPM scripts
- Best practices
- Common pitfalls
- Troubleshooting

**When to read:** Creating new tests, extending the framework

### 10. Debugging.md

**What it covers:**

- Debugging tools (Playwright Inspector, Headed Mode, Slow Motion, Console Logging, Screenshots, Videos, Trace Viewer)
- Debugging techniques (isolate problem, debugger statement, check locators, verify test data, wait for elements, network debugging, console messages)
- Common issues and solutions (element not found, flaky tests, test data not loaded, API failures, accessibility tests)
- Debugging checklist
- Best practices

**When to read:** Troubleshooting test failures, debugging flaky tests

## How to Use This Documentation

### For New Team Members

**Day 1:**

1. Read [Architecture.md](Architecture.md) - Understand framework design
2. Read [Project-Structure.md](Project-Structure.md) - Understand file organization
3. Read [Configuration.md](Configuration.md) - Understand how to run tests

**Day 2:**

1. Read [Execution-Flow.md](Execution-Flow.md) - Understand test execution
2. Read [Sequence-Diagrams.md](Sequence-Diagrams.md) - Visual understanding
3. Run existing tests locally

**Day 3:**

1. Read [Framework-Components.md](Framework-Components.md) - Understand components
2. Read [Adding-New-Test.md](Adding-New-Test.md) - Learn to create tests
3. Create a simple test

**Ongoing:**

- Reference [Coding-Guidelines.md](Coding-Guidelines.md) when writing code
- Reference [Debugging.md](Debugging.md) when troubleshooting
- Reference [Reporting.md](Reporting.md) when analyzing results

### For Experienced Team Members

**Quick Reference:**

- [Configuration.md](Configuration.md) - NPM scripts, environment variables
- [Adding-New-Test.md](Adding-New-Test.md) - Quick checklist for new tests
- [Debugging.md](Debugging.md) - Troubleshooting guide
- [Coding-Guidelines.md](Coding-Guidelines.md) - Standards and best practices

**Deep Dive:**

- [Architecture.md](Architecture.md) - Architectural improvements
- [Execution-Flow.md](Execution-Flow.md) - Execution internals
- [Framework-Components.md](Framework-Components.md) - Component details

### For Architects/Leads

**Architecture & Design:**

- [Architecture.md](Architecture.md) - Design patterns, strengths, limitations, improvements
- [Sequence-Diagrams.md](Sequence-Diagrams.md) - Visual architecture
- [Framework-Components.md](Framework-Components.md) - Component design

**Standards & Governance:**

- [Coding-Guidelines.md](Coding-Guidelines.md) - Coding standards
- [Project-Structure.md](Project-Structure.md) - Organization principles

**CI/CD & Reporting:**

- [Configuration.md](Configuration.md) - CI/CD configuration
- [Reporting.md](Reporting.md) - Report integration

## Key Concepts

### Test Types

1. **UI Tests**
    - Feature files in Gherkin
    - Page Objects for page structure
    - UIHelper for interactions
    - Test data in YAML files

2. **API Tests**
    - Feature files in Gherkin
    - APIUtils for CRUD operations
    - Test data in JSON files
    - JSONPath for response validation

3. **Accessibility Tests**
    - Feature files with WCAG tags
    - AccessibilityHelper with Axe-core
    - JSON and HTML reports
    - WCAG 2.0 and 2.1 compliance

### Execution Modes

1. **Local Execution**
    - Chromium, Firefox, or WebKit
    - Headed or headless
    - Sequential or parallel

2. **BrowserStack Execution**
    - Cloud browsers
    - Multiple OS/browser combinations
    - WebSocket connection

### Environments

- **STAGE** - Staging environment
- **QA** - QA environment
- **PROD** - Production environment

Controlled by `NODE_ENV` environment variable

### Reporting

- **Cucumber JSON** - Machine-readable
- **Cucumber HTML** - Single-page report
- **Multiple Cucumber HTML** - Multi-page report with metadata
- **Accessibility Reports** - WCAG compliance reports
- **Allure** - Advanced reporting (optional)

## Framework Highlights

### Strengths

1. **BDD Approach** - Business-readable tests with Cucumber
2. **Multi-Browser Support** - Chromium, Firefox, WebKit
3. **Multi-Environment** - STAGE, QA, PROD with separate test data
4. **API & UI Testing** - Unified framework for both
5. **Accessibility Testing** - Built-in WCAG compliance checks
6. **Cloud Testing** - BrowserStack integration
7. **Rich Reporting** - Multiple report formats with screenshots/videos
8. **Page Object Model** - Maintainable page abstractions
9. **Parallel Execution** - Configurable parallel threads
10. **CI/CD Ready** - Jenkins and Azure DevOps integration

### Opportunities for Improvement

1. **TypeScript Migration** - Better type safety and IDE support
2. **Structured Logging** - Winston or Pino for better logs
3. **Retry Mechanism** - Automatic retry for flaky tests
4. **Smart Waits** - Replace hardcoded waits with Playwright auto-waiting
5. **Test Data Builders** - Dynamic test data generation
6. **Custom Matchers** - Domain-specific assertions
7. **Allure Integration** - Richer reporting with trends
8. **Visual Regression** - Screenshot comparison testing
9. **Performance Testing** - Playwright performance APIs
10. **Docker Support** - Containerized execution

## Contributing

Before contributing:

1. Read [Coding-Guidelines.md](Coding-Guidelines.md)
2. Follow [Adding-New-Test.md](Adding-New-Test.md) for new tests
3. Test locally before committing
4. Generate and review reports
5. Follow Git commit guidelines
6. Request code review

## Support

For questions or issues:

1. Check relevant documentation section
2. Review [Debugging.md](Debugging.md) for troubleshooting
3. Search existing issues/discussions
4. Contact framework maintainers

## Maintenance

This documentation should be updated when:

- New features are added
- Framework architecture changes
- New tools or libraries are integrated
- Best practices evolve
- Common issues are discovered

## List of playwright device emulator as of 14 July , 2026

Available devices: Blackberry PlayBook, Blackberry PlayBook landscape, BlackBerry Z30, BlackBerry Z30 landscape, Galaxy Note 3, Galaxy Note 3 landscape, Galaxy Note II, Galaxy Note II landscape, Galaxy S III, Galaxy S III landscape, Galaxy S5, Galaxy S5 landscape, Galaxy S8, Galaxy S8 landscape, Galaxy S9+, Galaxy S9+ landscape, Galaxy S24, Galaxy S24 landscape, Galaxy A55, Galaxy A55 landscape, Galaxy Tab S4, Galaxy Tab S4 landscape, Galaxy Tab S9, Galaxy Tab S9 landscape, Galaxy Z Fold 6, Galaxy Z Fold 6 landscape, Galaxy Z Fold 6 Cover, Galaxy Z Fold 6 Cover landscape, Galaxy Z Fold 7, Galaxy Z Fold 7 landscape, Galaxy Z Fold 7 Cover, Galaxy Z Fold 7 Cover landscape, Galaxy Z Flip 6, Galaxy Z Flip 6 landscape, Galaxy Z Flip 6 Cover, Galaxy Z Flip 6 Cover landscape, Galaxy Z Flip 7, Galaxy Z Flip 7 landscape, Galaxy Z Flip 7 Cover, Galaxy Z Flip 7 Cover landscape, iPad (gen 5), iPad (gen 5) landscape, iPad (gen 6), iPad (gen 6) landscape, iPad (gen 7), iPad (gen 7) landscape, iPad (gen 11), iPad (gen 11) landscape, iPad Mini, iPad Mini landscape, iPad Pro 11, iPad Pro 11 landscape, iPhone 6, iPhone 6 landscape, iPhone 6 Plus, iPhone 6 Plus landscape, iPhone 7, iPhone 7 landscape, iPhone 7 Plus, iPhone 7 Plus landscape, iPhone 8, iPhone 8 landscape, iPhone 8 Plus, iPhone 8 Plus landscape, iPhone SE, iPhone SE landscape, iPhone SE (3rd gen), iPhone SE (3rd gen) landscape, iPhone X, iPhone X landscape, iPhone XR, iPhone XR landscape, iPhone 11, iPhone 11 landscape, iPhone 11 Pro, iPhone 11 Pro landscape, iPhone 11 Pro Max, iPhone 11 Pro Max landscape, iPhone 12, iPhone 12 landscape, iPhone 12 Pro, iPhone 12 Pro landscape, iPhone 12 Pro Max, iPhone 12 Pro Max landscape, iPhone 12 Mini, iPhone 12 Mini landscape, iPhone 13, iPhone 13 landscape, iPhone 13 Pro, iPhone 13 Pro landscape, iPhone 13 Pro Max, iPhone 13 Pro Max landscape, iPhone 13 Mini, iPhone 13 Mini landscape, iPhone 14, iPhone 14 landscape, iPhone 14 Plus, iPhone 14 Plus landscape, iPhone 14 Pro, iPhone 14 Pro landscape, iPhone 14 Pro Max, iPhone 14 Pro Max landscape, iPhone 15, iPhone 15 landscape, iPhone 15 Plus, iPhone 15 Plus landscape, iPhone 15 Pro, iPhone 15 Pro landscape, iPhone 15 Pro Max, iPhone 15 Pro Max landscape, iPhone 16, iPhone 16 landscape, iPhone 16 Plus, iPhone 16 Plus landscape, iPhone 16 Pro, iPhone 16 Pro landscape, iPhone 16 Pro Max, iPhone 16 Pro Max landscape, iPhone 16e, iPhone 16e landscape, iPhone 17, iPhone 17 landscape, iPhone Air, iPhone Air landscape, iPhone 17 Pro, iPhone 17 Pro landscape, iPhone 17 Pro Max, iPhone 17 Pro Max landscape, iPhone 17e, iPhone 17e landscape, Kindle Fire HDX, Kindle Fire HDX landscape, LG Optimus L70, LG Optimus L70 landscape, Microsoft Lumia 550, Microsoft Lumia 550 landscape, Microsoft Lumia 950, Microsoft Lumia 950 landscape, Nexus 10, Nexus 10 landscape, Nexus 4, Nexus 4 landscape, Nexus 5, Nexus 5 landscape, Nexus 5X, Nexus 5X landscape, Nexus 6, Nexus 6 landscape, Nexus 6P, Nexus 6P landscape, Nexus 7, Nexus 7 landscape, Nokia Lumia 520, Nokia Lumia 520 landscape, Nokia N9, Nokia N9 landscape, Pixel 2, Pixel 2 landscape, Pixel 2 XL, Pixel 2 XL landscape, Pixel 3, Pixel 3 landscape, Pixel 4, Pixel 4 landscape, Pixel 4a (5G), Pixel 4a (5G) landscape, Pixel 5, Pixel 5 landscape, Pixel 6, Pixel 6 landscape, Pixel 6 Pro, Pixel 6 Pro landscape, Pixel 6a, Pixel 6a landscape, Pixel 7, Pixel 7 landscape, Pixel 7 Pro, Pixel 7 Pro landscape, Pixel 7a, Pixel 7a landscape, Pixel 8, Pixel 8 landscape, Pixel 8 Pro, Pixel 8 Pro landscape, Pixel 8a, Pixel 8a landscape, Pixel 9, Pixel 9 landscape, Pixel 9 Pro, Pixel 9 Pro landscape, Pixel 9 Pro XL, Pixel 9 Pro XL landscape, Pixel 10, Pixel 10 landscape, Pixel 10 Pro, Pixel 10 Pro landscape, Pixel 10 Pro XL, Pixel 10 Pro XL landscape, Moto G4, Moto G4 landscape, Desktop Chrome HiDPI, Desktop Edge HiDPI, Desktop Firefox HiDPI, Desktop Safari, Desktop Chrome, Desktop Edge, Desktop Firefox

Keep documentation in sync with code to ensure accuracy and usefulness.

---

## IMPORTANT COMPATIBILITY NOTES

✅ Fully usable in Cucumber
Browser/Page/Context APIs
Locator API
Network interception
Tracing
Videos
Downloads/uploads
APIRequestContext
Device emulation
Browser channels (Chrome, Edge)
Mobile emulation
page.pause()
Codegen
Most expect(locator/page) assertions
Screenshots via page.screenshot()

❌ Requires Playwright Test Runner
test()
test.describe()
Fixtures (test.extend)
Projects
toHaveScreenshot()
toMatchSnapshot()
Snapshot management
TestInfo
test.step()
Annotations (test.skip, test.fixme, test.slow, etc.)
Built-in HTML report, trace attachment integration, and other Playwright Test runner reporting features

**Last Updated:** 2026-07-08

**Framework Version:** 1.0.0

**Maintained By:** Automation Team
