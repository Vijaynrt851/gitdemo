// @ts-check
import { devices } from '@playwright/test';
import dotenv from 'dotenv';
dotenv.config();

const config = {
    testDir: './tests',
    retries: 0,
    workers: Number(process.env.PARALLEL_THREAD ?? 3),
    /* Maximum time one test can run for. */
    //10-
    timeout: 60 * 1000,
    expect: {
        timeout: 30000,
        toHaveScreenshot: {
            maxDiffPixels: 100,
            threshold: 0.2,
            animations: 'disabled',
        },
    },

    // Visual comparison configuration
    snapshotDir: './visual-regression/baseline',
    snapshotPathTemplate: '{snapshotDir}/{testFilePath}/{arg}{ext}',
    updateSnapshots: process.env.UPDATE_SNAPSHOTS === 'true' ? 'all' : 'missing',

    reporter: [
        ['html', { open: 'never' }],
        ['junit', { outputFile: 'test-results/junit.xml' }],
    ],

    // Configure output directories for visual comparison
    use: {
        screenshot: {
            mode: 'only-on-failure',
            fullPage: true,
        },
        trace: 'retain-on-failure',
        launchOptions: {
            args: ['--start-maximized'],
        },
        headless: true,
    },

    projects: [
        {
            name: 'safari',
            use: {
                browserName: 'webkit',
                headless: true,
                screenshot: 'retain-on-failure',
                trace: 'off', //off,on
                // ...devices['iPhone 11'],
            },
        },
        {
            name: 'chromium',
            use: {
                browserName: 'chromium',
                headless: false,
                screenshot: 'retain-on-failure',
                video: 'retain-on-failure',
                ignoreHttpsErrors: true,
                permissions: ['geolocation'],
                trace: 'off', //off,on
                // ...devices['']
                //   viewport : {width:720,height:720}
            },
        },
        {
            name: 'firefox',
            use: { ...devices['Desktop Firefox'] },
        },
        {
            name: 'Mobile Chrome',
            use: { ...devices['Pixel 5'] },
        },
        {
            name: 'Mobile Safari',
            use: { ...devices['iPhone 12'] },
        },
        /* Test against branded browsers. */
        {
            name: 'Google Chrome',
            use: { ...devices['Desktop Chrome'], channel: 'chrome' }, // or 'chrome-beta'
        },
        {
            name: 'Microsoft Edge',
            use: { ...devices['Desktop Edge'], channel: 'msedge' }, // or 'msedge-dev'
        },
    ],
};

export default config;
