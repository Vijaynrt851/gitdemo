// @ts-check
import { devices } from '@playwright/test';

const config = {
  testDir: './tests',
  retries :0,
  
  /* Maximum time one test can run for. */
  timeout: 30 * 1000,
  expect: {
  
    timeout: 30000
  },
  
  reporter: 'html',
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    baseURL: 'http://google.com',
    viewport: { width: 1920, height: 1040 },
    browserName : 'webkit',
    headless : false,
    screenshot : 'on',
    trace : 'on',//off,on
    
  },
  projects: [
    {
        name: 'Chromium',
        use: { browserName: 'chromium'},
    },
    {
        name: 'Firefox',
        use: { browserName: 'firefox'},
    },
    {
        name: 'Webkit',
        use: { browserName: 'webkit'},
    },
],

};

export default config;
