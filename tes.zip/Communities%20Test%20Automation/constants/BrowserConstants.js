class BrowserConstants {
    constructor() {
        const FIREFOX = "firefox";
        this.FIREFOX = FIREFOX;
        const WEBKIT = "webkit";
        this.WEBKIT = WEBKIT;
        const EDGE = "edge";
        this.EDGE = EDGE;
        const CHROMIUM = "chromium";
        this.CHROMIUM = CHROMIUM;
        const MOBILE_CHROME = "mobile-chrome";
        this.MOBILE_CHROME = MOBILE_CHROME;
        const MOBILE_WEBKIT = "mobile-webkit";
        this.MOBILE_WEBKIT = MOBILE_WEBKIT;
        const TABLET_IPAD_WEBKIT = "tablet-ipad-webkit";
        this.TABLET_IPAD_WEBKIT = TABLET_IPAD_WEBKIT;
        const GALAXY_TAB_CHROME = "Galaxy-Tab-chrome";
        this.GALAXY_TAB_CHROME = GALAXY_TAB_CHROME;
    }

    getFirefox() {
        return this.FIREFOX;
    }

    getWebkit() {
        return this.WEBKIT;
    }

    getEdge() {
        return this.EDGE;
    }

    getChromium() {
        return this.CHROMIUM;
    }

    getMobileChrome() {
    return this.MOBILE_CHROME;
}

   getMobileWebkit() {
    return this.MOBILE_WEBKIT;
}

getTabletIpadWebkit() {
    return this.TABLET_IPAD_WEBKIT;
}

getGalaxyTabChrome() {
    return this.GALAXY_TAB_CHROME;
}

}

export { BrowserConstants };
