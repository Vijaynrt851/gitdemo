import * as report from "multiple-cucumber-html-reporter";
import fs from "fs/promises";
import path from "path";

export async function generateCucumberHtmlReport() {
    const executionInfoPath = path.resolve(
        "report-data",
        "execution-info.json"
    );

    let executionInfo = {};

    try {
        const file = await fs.readFile(executionInfoPath, "utf8");
        executionInfo = JSON.parse(file);
    } catch (error) {
        console.warn(
            "execution-info.json not found. Using default values."
        );
    }

    report.generate({
        jsonDir: "reports/",
        reportPath: "reports",

        metadata: {
            browser: {
                name: executionInfo.browser || "Chromium",
                version: executionInfo.browserVersion || ""
            },

            device: executionInfo.hostname || "",

            executionPlatform:
                executionInfo.operatingSystem ||
                executionInfo.platformName ||
                executionInfo.platform ||
                "",

            platform: {
                name:
                    executionInfo.operatingSystem ||
                    executionInfo.platformName ||
                    executionInfo.platform ||
                    "",

                version: executionInfo.platformVersion || ""
            }
        },

        customData: {
            projectName:
                executionInfo.projectName ||
                "Heathrow Playwright Cucumber",

            framework:
                executionInfo.framework ||
                "Playwright + Cucumber",

            language:
                executionInfo.language ||
                "TypeScript",

            environment:
                executionInfo.environment ||
                "QA",

            headless: String(executionInfo.headless),

            parallelThreads: String(
                executionInfo.parallelThreads || 1
            ),

            retryCount: String(
                executionInfo.retryCount || 0
            ),

            nodeVersion:
                executionInfo.nodeVersion || "",

            architecture:
                executionInfo.architecture || "",

            cpuCount: String(
                executionInfo.cpuCount || ""
            ),

            username:
                executionInfo.username || "",

            release:
                executionInfo.release || "",

            testCycle:
                executionInfo.cycle || "",

            ci: String(executionInfo.ci),

            ciProvider:
                executionInfo.ciProvider || "",

            gitBranch:
                executionInfo.gitBranch || "",

            gitCommit:
                executionInfo.gitCommit || ""
        }
    });

    console.log(
        "\n✓ Cucumber HTML Report generated successfully in reports/ directory\n"
    );
}

// If run directly as a script
generateCucumberHtmlReport().catch((error) => {
    console.error("✗ Failed to generate report:", error.message);
    process.exit(1);
});