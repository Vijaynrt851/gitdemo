// playwright.config.js
import { devices } from '@playwright/test';

const config = {
  testDir: './tests',
  retries: 0,
  workers: 3,
  timeout: 30 * 1000,
  expect: {
    timeout: 5000
  },
  reporter: 'html',
  
  // Visual comparison configuration
  // Supports UPDATE_SNAPSHOTS environment variable for baseline updates
  updateSnapshots: process.env.UPDATE_SNAPSHOTS === 'true' ? 'all' : 'missing',
  
  projects: [
    {
      name: 'BrowserStack',
      use: {
        browserName: 'chromium',
        headless: true,
        screenshot: 'on',
        video: 'retain-on-failure',
        ignoreHttpsErrors: true,
        permissions: ['geolocation'],
        trace: 'on',
        launchOptions: {
          args: [
            '--disable-dev-shm-usage',
            '--no-sandbox',
            '--disable-setuid-sandbox'
          ]
        },
        connectOptions: {
          wsEndpoint: `wss://cdp.browserstack.com/playwright?caps=${encodeURIComponent(JSON.stringify({
            'browser': 'chrome',
            'browser_version': 'latest',
            'os': 'osx',
            'os_version': 'catalina',
            'name': 'Playwright Test',
            'build': 'Playwright Build',
            'browserstack.username': process.env.BROWSERSTACK_USERNAME,
            'browserstack.accessKey': process.env.BROWSERSTACK_ACCESS_KEY,
          }))}`
        }
      }
    },
    {
      name: 'BrowserStack Firefox',
      use: {
        browserName: 'firefox',
        headless: true,
        screenshot: 'on',
        video: 'retain-on-failure',
        ignoreHttpsErrors: true,
        trace: 'on',
        connectOptions: {
          wsEndpoint: `wss://cdp.browserstack.com/playwright?caps=${encodeURIComponent(JSON.stringify({
            'browser': 'firefox',
            'browser_version': 'latest',
            'os': 'osx',
            'os_version': 'catalina',
            'name': 'Playwright Test - Firefox',
            'build': 'Playwright Build',
            'browserstack.username': process.env.BROWSERSTACK_USERNAME,
            'browserstack.accessKey': process.env.BROWSERSTACK_ACCESS_KEY,
          }))}`
        }
      }
    },
    {
      name: 'BrowserStack WebKit',
      use: {
        browserName: 'webkit',
        headless: true,
        screenshot: 'on',
        video: 'retain-on-failure',
        ignoreHttpsErrors: true,
        trace: 'on',
        connectOptions: {
          wsEndpoint: `wss://cdp.browserstack.com/playwright?caps=${encodeURIComponent(JSON.stringify({
            'browser': 'safari',
            'browser_version': 'latest',
            'os': 'osx',
            'os_version': 'catalina',
            'name': 'Playwright Test - WebKit',
            'build': 'Playwright Build',
            'browserstack.username': process.env.BROWSERSTACK_USERNAME,
            'browserstack.accessKey': process.env.BROWSERSTACK_ACCESS_KEY,
          }))}`
        }
      }
    }
  ]
};

export default config;
