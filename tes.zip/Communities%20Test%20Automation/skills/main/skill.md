---
name: heathrow-communities-cucumber-playwright-javascript-automation
description: Cucumber.js + JavaScript + Playwright test automation framework for Heathrow Communities project. Focused on BDD scenarios with Page Object Model, JSON-based test data for QNS module, POManager factory pattern, CustomWorld context, hooks for browser lifecycle, accessibility testing with Axe-core, mobile/tablet device emulation, and multiple reporting formats (Cucumber HTML, Allure, JUnit, Serenity). Use this skill when working with this specific Cucumber.js + JavaScript + Playwright codebase to maintain established patterns, reuse existing components, and follow project conventions.
---

# Heathrow Communities Cucumber.js + JavaScript + Playwright Automation Framework

This skill provides guidance for working with **this specific Cucumber.js + JavaScript + Playwright automation framework** for the **Heathrow Communities** project. The repository uses ES Modules, CustomWorld context, singleton browser pattern, Page Object Model with POManager factory, environment-based test data (YAML for UI, JSON for QNS module), device emulation, and comprehensive reporting.

## Critical Principles

### 1. This is JavaScript, NOT TypeScript

- **Language:** JavaScript (ES Modules)
- **File extensions:** `.js` only
- **No TypeScript syntax:** No types, interfaces, type annotations, or `.ts` files
- **Import syntax:** `import` statements (not `require`)
- **Module type:** `"type": "module"` in package.json

### 2. Understand Before Changing

- **Inspect existing implementations** before creating new code
- **Ignore files and folders with demo in their name unless creating new demo scenarios**
- **Reuse existing components:** page objects, utilities, step definitions
- **Follow established patterns:** locator strategies, naming conventions, test data structure
- **Verify configurations** before modifying cucumber.js, playwright.config.js, or package.json

### 3. Framework Architecture

This framework is built on:

- **Cucumber.js** (`@cucumber/cucumber` ^13.0.0) - BDD test execution
- **Playwright** (`@playwright/test` ^1.61.1) - Browser automation
- **JavaScript ES Modules** - Modern module system
- **CustomWorld** - Shared context across steps
- **POManager** - Page Object factory pattern
- **Singleton Browser** - Resource optimization across scenarios
- **Environment-based Test Data** - YAML for UI, JSON for QNS module
- **Device Emulation** - Mobile and tablet testing support
- **Multiple Reporters** - Cucumber HTML, Allure, Serenity, JUnit

---

## Project Structure

```
Communities Test Automation/
├── features/                          # Cucumber feature files and support code
│   ├── *.feature                      # BDD test scenarios (Gherkin)
│   ├── demo-tests/                    # Demo/example feature files
│   ├── qns/                           # QNS (Query/Noise Service) features
│   │   ├── submit-new-query.feature
│   │   ├── my-account.feature
│   │   └── form-validation.feature
│   ├── step_definitions/              # Step definition implementations
│   │   ├── ui-steps.js                # UI test steps
│   │   ├── demo-test/
│   │   │   └── api-steps.js           # API test steps
│   │   ├── qns/                       # QNS-specific step definitions
│   │   │   ├── submit-new-query-steps.js
│   │   │   ├── my-account-steps.js
│   │   │   └── form-validation-steps.js
│   │   ├── login-steps.js             # Login-specific steps
│   │   ├── myprofile-steps.js         # Profile management steps
│   │   ├── faq-steps.js               # FAQ page steps
│   │   ├── homepage-steps.js          # Homepage steps
│   │   └── submitquery-steps.js       # Query submission steps
│   └── support/                       # Cucumber support files
│       ├── world.js                   # CustomWorld definition
│       ├── hooks.js                   # Before/After hooks
│       └── login-hooks.js             # Login-specific hooks
│
├── pageobjects/                       # Page Object Model classes
│   ├── POManager.js                   # Page Object factory
│   ├── CommonPageObjects.js           # Shared page actions
│   ├── LoginPage.js                   # Login page
│   ├── HomePage.js                    # Home page
│   ├── FaqPage.js                     # FAQ page
│   ├── MyProfilePage.js               # Profile management page
│   ├── SubmitQueryPage.js             # Query submission page
│   ├── demo-test/                     # Demo page objects
│   │   ├── DemoQAMainPage.js
│   │   └── DemoQAElementPage.js
│   └── qns/                           # QNS module page objects
│       ├── NoiseComplaintFormPage.js  # Noise complaint form
│       ├── MyAccountPage.js           # QNS account management
│       └── ConfirmationPage.js        # Submission confirmation
│
├── utils/                             # Utility classes
│   ├── UIHelper.js                    # UI interaction wrapper
│   ├── APiUtils.js                    # API testing utilities
│   ├── BrowserUtils.js                # Browser launch logic
│   ├── AccessibilityHelper.js         # Axe-core accessibility testing
│   ├── TestDataUtils.js               # YAML test data loader
│   ├── ScreenshotHelper.js            # Screenshot capture
│   ├── VideoHelper.js                 # Video recording
│   ├── VisualComparisonHelper.js      # Visual regression testing
│   └── test-base.js                   # Base test utilities
│
├── testData/                          # Environment-based test data
│   ├── uidata/                        # UI test data (YAML)
│   │   ├── QA_env_test_data.yml
│   │   ├── SIT_env_test_data.yml
│   │   ├── UAT_env_test_data.yml
│   │   └── PROD_env_test_data.yml
│   ├── qns/                           # QNS module test data (JSON)
│   │   ├── submit-new-query-data.json
│   │   ├── my-account-data.json
│   │   └── form-validation-data.json
│   └── apidata/                       # API test data (JSON)
│       ├── QA/
│       ├── STAGE/
│       └── PROD/
│
├── constants/                         # Framework constants
│   └── BrowserConstants.js            # Browser type constants
│
├── tests/                             # Playwright native tests (optional)
│   ├── login.spec.js                  # Login tests
│   ├── EndToEndWebTest.spec.js        # E2E tests
│   ├── MoreWebUIValidationTest.spec.js # UI validation tests
│   └── visual-comparison.spec.js      # Visual regression tests
│
├── visual-regression/                 # Visual regression baseline/diff
│   ├── baseline/
│   ├── actual/
│   └── diff/
│
├── pipeline/                          # CI/CD pipeline configurations
│   └── azure/                         # Azure DevOps pipelines
│       ├── copado-post-deploy-sanity.yml
│       ├── cucumber-custom.yml
│       ├── cucumber-sanity.yml
│       ├── playwright-custom.yml
│       └── playwright-visual-comparison.yml
│
├── scripts/                           # Utility scripts
│   └── clean.js                       # Clean reports/artifacts
│
├── referece docs/                     # Reference documentation
│   ├── ARCHITECTURE.md
│   └── COPADO-INTEGRATION.md
│
├── cucumber.js                        # Cucumber runner configuration
├── playwright.config.js               # Playwright configuration
├── playwright.config-bst.js           # BrowserStack config
├── reporter.js                        # Multiple HTML reporter config
├── generateAxeReport.js               # Accessibility report generator
├── README.md                          # Project documentation
├── Jenkinsfile                        # Jenkins pipeline
├── .env.example                       # Environment variables template
└── package.json                       # Dependencies and scripts
```

### Auto-Generated Directories

```
├── reports/                           # Test execution reports
│   ├── cucumber-report.html           # Single HTML report
│   ├── cucumber_report.json           # JSON report
│   ├── junit-results.xml              # JUnit XML report
│   ├── index.html                     # Multiple reports entry point
│   └── axe-reports/                   # Accessibility reports
│       ├── json_reports/
│       └── html_reports/
├── test-results/                      # Screenshots and videos
│   ├── screenshots/
│   └── videos/
├── allure-results/                    # Allure report data
└── allure-report/                     # Generated Allure HTML report
```

---

## Framework Components

### 1. Feature Files

**Location:** `/features/*.feature`, `/features/demo-tests/*.feature`, `/features/qns/*.feature`

**Format:** Gherkin syntax

**Tags:** Used for selective execution

**Existing Tags:**

- `@sanity` - Sanity/smoke tests
- `@qns` - QNS module tests
- `@qns-sanity` - QNS sanity tests
- `@qns-regression` - QNS regression tests
- `@regression` - API regression tests
- `@accessibility` - Accessibility tests
- `@Heathrow` - Heathrow-specific tests
- `@loginToWelcome` - Login flow tests
- `@myTest123` - Custom test tag
- Work item IDs: `@777291`, `@752885`, `@752887`

**Example:**

```gherkin
Feature: QNS - Prepopulate saved details and Submit New Query
  As a registered resident
  I want to be pre-populated my personal details on noise complaint form when its saved before
  And I want to submit new query from confirmation page

   Background:
    Given I navigate to "qnsHomePage"
    And I am logged in to the QNS application

  @qns @qns-sanity @777291 @752885
  Scenario: Submit new query from confirmation page
    Given I navigate to the noise complaint form
    When I fill the postcode field if it is empty
    And I fill all required disturbance information fields
    And I submit the form
    Then the confirmation page is displayed
```

**Conventions:**

- Use descriptive scenario names
- Reference test data keys in quotes (e.g., `"qnsHomePage"`)
- Group related scenarios in same feature file
- Use tags for test organization and execution
- Include work item IDs for traceability
- Use Background for common preconditions

### 2. Step Definitions

**Location:** `/features/step_definitions/*-steps.js`

**Naming:** `{page-name}-steps.js` or `{purpose}-steps.js`

**Pattern:**

```javascript
import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Given('I navigate to {string}', async function (pageKey) {
    const commonPageObjects = this.poManager.getCommonPageObjects();
    await commonPageObjects.launchUrl(pageKey);
});

When('I fill the postcode field if it is empty', async function () {
    const noiseFormPage = this.poManager.getNoiseComplaintFormPage();
    await noiseFormPage.fillPostcodeIfEmpty();
});

Then('the confirmation page is displayed', async function () {
    const confirmationPage = this.poManager.getConfirmationPage();
    await confirmationPage.verifyConfirmationPageDisplayed();
});
```

**Key Patterns:**

- Access page objects via `this.poManager`
- Access page instance via `this.page`
- Use `async function` (not arrow functions)
- Parameter placeholders: `{string}`, `{int}`, `{float}`
- Access CustomWorld properties: `this.browser`, `this.context`, `this.page`, `this.poManager`
- Access test data via `this.testDataUtils`

### 3. Page Objects

**Location:** `/pageobjects/*Page.js`, `/pageobjects/qns/*Page.js`

**Structure:**

```javascript
import { expect } from '@playwright/test';
import UIHelper from '../utils/UIHelper.js';

class NoiseComplaintFormPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);

        // Locators defined in constructor
        this.postcodeField = page.locator("[data-locator='postcode-input']");
        this.dateField = page.locator('#disturbance-date');
        this.submitButton = page.locator("button[type='submit']");
    }

    async fillPostcodeIfEmpty() {
        const isVisible = await this.UIHelper.checkElementVisibility(this.postcodeField);
        if (isVisible) {
            const currentValue = await this.postcodeField.inputValue();
            if (!currentValue) {
                await this.UIHelper.enterTextForWebElement(this.postcodeField, 'TW6 1EW');
            }
        }
    }

    async verifyFormDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.postcodeField);
    }
}

export default NoiseComplaintFormPage;
```

**Conventions:**

- Define **all locators in constructor**
- Use UIHelper for common actions
- Export as default or named export: `export default ClassName` or `export { ClassName }`
- Import UIHelper: `import UIHelper from '../utils/UIHelper.js'`
- Use `this.page` for Playwright page instance
- Use descriptive method names that reflect user actions

### 4. POManager (Page Object Factory)

**Location:** `/pageobjects/POManager.js`

**Purpose:** Centralized page object instantiation

**Current Implementation:**

```javascript
import { CommonPageObjects } from './CommonPageObjects.js';
import { LoginPage } from './LoginPage.js';
import { FaqPage } from './FaqPage.js';
import { MyProfilePage } from './MyProfilePage.js';
import { SubmitQueryPage } from './SubmitQueryPage.js';
import { HomePage } from './HomePage.js';
import NoiseComplaintFormPage from './qns/NoiseComplaintFormPage.js';
import MyAccountPage from './qns/MyAccountPage.js';
import ConfirmationPage from './qns/ConfirmationPage.js';

class POManager {
    constructor(page) {
        this.page = page;
        this.CommonPageObjects = new CommonPageObjects(this.page);
        this.LoginPage = new LoginPage(this.page);
        this.FaqPage = new FaqPage(this.page);
        this.MyProfilePage = new MyProfilePage(this.page);
        this.SubmitQueryPage = new SubmitQueryPage(this.page);
        this.HomePage = new HomePage(this.page);
        this.NoiseComplaintFormPage = new NoiseComplaintFormPage(this.page);
        this.MyAccountPage = new MyAccountPage(this.page);
        this.ConfirmationPage = new ConfirmationPage(this.page);
    }

    getCommonPageObjects() {
        return this.CommonPageObjects;
    }

    getLoginPage() {
        return this.LoginPage;
    }

    getNoiseComplaintFormPage() {
        return this.NoiseComplaintFormPage;
    }

    getMyAccountPage() {
        return this.MyAccountPage;
    }

    getConfirmationPage() {
        return this.ConfirmationPage;
    }

    // ... other getters
}

export { POManager };
```

**Usage in Steps:**

```javascript
const noiseFormPage = this.poManager.getNoiseComplaintFormPage();
await noiseFormPage.fillPostcodeIfEmpty();
```

**When Adding New Page Object:**

1. Create page object class in `/pageobjects/` or `/pageobjects/qns/`
2. Import it in `POManager.js`
3. Instantiate in constructor
4. Add getter method
5. Access via `this.poManager.getPageName()` in steps

### 5. CustomWorld

**Location:** `/features/support/world.js`

**Purpose:** Shared context across scenario steps

**Properties:**

```javascript
import { World, setWorldConstructor } from '@cucumber/cucumber';

class CustomWorld extends World {
    constructor(options) {
        super(options);

        this.browser = null; // Singleton browser instance
        this.context = null; // Browser context
        this.page = null; // Current page
        this.poManager = null; // Page Object Manager
        this.apiContext = null; // API request context
        this.apiUtils = null; // API utilities
        this.accessibilityHelper = null; // Accessibility helper
        this.testName = null; // Current test name
        this.testDataUtils = null; // Test data loader
    }
}

setWorldConstructor(CustomWorld);
```

**Access in Steps:**

- `this.page` - Current page instance
- `this.poManager` - Access all page objects
- `this.apiUtils` - API testing utilities
- `this.accessibilityHelper` - Accessibility testing
- `this.testDataUtils` - Test data loader

### 6. Hooks

**Location:** `/features/support/hooks.js`

**BeforeAll Hook:**

- Initialize singleton browser instance
- Create execution info for reports (execution-info.json)
- Set up environment configuration

**Before Hook:**

- Create browser context with device emulation support
- Create new page
- Initialize POManager
- Initialize TestDataUtils
- Reset screenshot counter

**BeforeStep Hook:**

- Initialize APIUtils if needed
- Initialize AccessibilityHelper if needed
- Set test name for screenshots

**AfterStep Hook:**

- Capture per-step screenshots if enabled
- Handle step-level failures

**After Hook:**

- Capture scenario-level screenshot
- Handle video recording
- Close page and context
- Clean up resources

**AfterAll Hook:**

- Close singleton browser

**Device Emulation Support:**

The Before hook supports multiple device configurations:

```javascript
switch (browserType) {
    case 'mobile-chrome':
        this.context = await this.browser.newContext({
            ...devices['Pixel 7'],
            ...contextOptions,
        });
        break;

    case 'mobile-webkit':
        this.context = await this.browser.newContext({
            ...devices['iPhone 15'],
            ...contextOptions,
        });
        break;

    case 'tablet-ipad-webkit':
        this.context = await this.browser.newContext({
            ...devices['iPad Pro 11'],
            ...contextOptions,
        });
        break;

    case 'Galaxy-Tab-chrome':
        this.context = await this.browser.newContext({
            ...devices['Galaxy Tab S9'],
            ...contextOptions,
        });
        break;

    default:
        // Desktop viewport
        this.context = await this.browser.newContext({
            viewport: { width: 1280, height: 1080 },
            ...contextOptions,
        });
}
```

**Note:** Do NOT modify hooks.js unless you understand the complete browser lifecycle and reporting flow.

### 7. Test Data Management

#### UI Test Data (YAML)

**Location:** `/testData/uidata/{ENV}_env_test_data.yml`

**Supported Environments:** QA, SIT, UAT, PROD

**Format:**

```yaml
qnsHomePage: 'https://communities.qa.example.com'
TerminalFinder: 'https://heathrow.qa.lhr.aero/terminal-guides'
LeadTimeHours: 2
MaximumPassengers: 8
```

**Loading:**

```javascript
import { TestDataUtils } from '../utils/TestDataUtils.js';

const testDataUtils = new TestDataUtils();
const url = await testDataUtils.getData('qnsHomePage');
```

**Environment Selection:**

- `NODE_ENV=QA` → `QA_env_test_data.yml`
- `NODE_ENV=SIT` → `SIT_env_test_data.yml`
- `NODE_ENV=UAT` → `UAT_env_test_data.yml`
- `NODE_ENV=PROD` → `PROD_env_test_data.yml`

#### QNS Module Test Data (JSON)

**Location:** `/testData/qns/{test-name}-data.json`

**Format:**

```json
{
    "savedPersonalDetails": {
        "addressLine2": "123 Heathrow Road, London",
        "postcode": "TW6 1EW"
    },
    "firstSubmission": {
        "date": "2026-01-15",
        "time": "14:00",
        "type": "Aircraft noise",
        "details": "Test noise complaint for confirmation page validation"
    },
    "confirmationPage": {
        "expectedMessage": "Thank you for your submission",
        "submitNewQueryButtonText": "Submit new query"
    }
}
```

**Loading:**

```javascript
import fs from 'fs';
import path from 'path';

const testData = JSON.parse(fs.readFileSync(path.resolve('./testData/qns/submit-new-query-data.json'), 'utf8'));

const postcode = testData.savedPersonalDetails.postcode;
```

#### API Test Data (JSON)

**Location:** `/testData/apidata/{ENV}/{scenarioType}.json`

**Format:**

```json
{
    "url": "https://api.example.com/endpoint",
    "header": {
        "Content-Type": "application/json"
    },
    "data": {
        "key": "value"
    }
}
```

**Loading:**

```javascript
const apiUtils = new APiUtils();
await apiUtils.getCall('getUser');
```

### 8. Utilities

#### UIHelper.js

**Purpose:** Wrapper for common UI interactions

**Methods:**

- `enterTextForWebElement(webElement, inputText)` - Fill text
- `enterTextForWebElementWithClear(webElement, inputText)` - Clear and fill
- `clickOnWebElement(webElement)` - Click element
- `doubleClickOnWebElement(webElement)` - Double click
- `check(webElement)` - Check checkbox
- `getAllTextContentOfWebElement(webElement)` - Get all text
- `getTextContentOfWebElement(webElement)` - Get text
- `mouseHoverOnTheElement(webElement)` - Hover
- `selectDropDownMenuOption(webElement, option)` - Select dropdown
- `verifyElementIsVisible(webElement)` - Positive assertion (fails if not visible)
- `verifyElementIsNotVisible(webElement)` - Negative assertion (fails if visible)
- `checkElementVisibility(webElement, timeout)` - Returns boolean (no assertion)
- `clearWebElement(webElement)` - Clear input
- `scrollIntoView(webElement)` - Scroll into view
- `waitForPageLoad(state, timeout)` - Wait for page load state

**Usage:**

```javascript
this.UIHelper = new UIHelper(this.page);
await this.UIHelper.clickOnWebElement(this.elementName);
```

**Important Distinction:**

- Use `verifyElementIsVisible()` / `verifyElementIsNotVisible()` for **assertions** (fails scenario)
- Use `checkElementVisibility()` for **conditional logic** (returns true/false)

#### APiUtils.js

**Purpose:** API testing utilities

**Methods:**

- `postCall(scenarioType)` - POST request
- `getCall(scenarioType)` - GET request
- `putCall(scenarioType)` - PUT request
- `deleteCall(scenarioType)` - DELETE request
- `validateResponseStatusCode(expectedStatusCode)` - Status validation
- `validateData(jsonQuery, value)` - JSONPath validation

**Usage in Steps:**

```javascript
When('I request {string} get call', async function (scenarioType) {
    await this.apiUtils.getCall(scenarioType);
});

Then('I validate response status code as {string}', async function (statusCode) {
    await this.apiUtils.validateResponseStatusCode(statusCode);
});
```

#### AccessibilityHelper.js

**Purpose:** Axe-core accessibility testing

**Method:**

- `checkWCAG(page, testName, wcagTags)` - Run accessibility scan

**WCAG Tags:**

- `['wcag2a']` - WCAG 2.0 Level A
- `['wcag2aa']` - WCAG 2.0 Level AA
- `['wcag21a']` - WCAG 2.1 Level A
- `['wcag21aa']` - WCAG 2.1 Level AA

**Usage:**

```javascript
Then('the page should have no {string} accessibility violations', async function (wcagTag) {
    const reportPath = await this.accessibilityHelper.checkWCAG(this.page, `${wcagTag}_test`, [wcagTag]);

    if (reportPath) {
        this.attach(fs.readFileSync(reportPath, 'utf8'), 'application/json');
    }
});
```

#### ScreenshotHelper.js

**Purpose:** Screenshot capture management

**Methods:**

- `captureScreenshot(page, scenario, line, status, stepText, attachFn)` - Scenario screenshot
- `captureStepScreenshot(page, scenario, line, stepText, status, attachFn)` - Step screenshot
- `resetStepCounter()` - Reset step counter for new scenario

**Usage:**

Automatically used in hooks - no manual invocation needed.

#### VideoHelper.js

**Purpose:** Video recording management

**Methods:**

- `handleVideo(video, scenario, line, status, world)` - Process video recording

**Usage:**

Automatically used in After hook - no manual invocation needed.

### 9. Locator Strategies

**Preferred Order:**

1. **Data Attributes** - `page.locator("[data-locator='value']")`
2. **CSS Selectors** - `page.locator(".classname")`, `page.locator("#id")`
3. **XPath** - `page.locator("//button[@class='submit']")`
4. **Text Content** - `page.locator("text=Submit")`
5. **Role** - `page.getByRole('button', { name: 'Submit' })`

**Existing Patterns:**

```javascript
// Data attributes (preferred in this project)
this.NextBtn = page.locator("*[data-locator='chevron-right_icon']");
this.postcodeField = page.locator("[data-locator='postcode-input']");

// ID selectors
this.dateField = page.locator('#disturbance-date');

// CSS selectors
this.submitButton = page.locator("button[type='submit']");
this.element = page.locator('.card.mt-4.top-card');

// XPath
this.TextBox = page.locator("//span[text()='Text Box']");

// Attribute selectors
this.FullName = page.locator("[placeholder='Full Name']");

// Role-based
const button = page.getByRole('button', { name: 'Submit' });
```

**Convention:**

- Define locators in page object constructor
- Use descriptive variable names
- Group related locators with comments
- Avoid hardcoding locators in step definitions
- Prefer data-locator attributes for maintainability

---

## Configuration

### 1. cucumber.js

**Purpose:** Cucumber runner configuration

**Key Settings:**

```javascript
paths: ['features/**/*.feature'],
require: [
    'features/support/world.js',
    'features/support/hooks.js',
    'features/step_definitions/**/*-steps.js',
],
format: [
    'progress-bar',
    'html:reports/cucumber-report.html',
    'json:reports/cucumber_report.json',
    'junit:reports/junit-results.xml',
    '@serenity-js/cucumber',
    'allure-cucumberjs/reporter',
],
retry: Number(retryCount),      // Default: 0
parallel: Number(parallelThread) // Default: 1
```

**Profiles:**

- `default` - Main configuration
- `smoke` - Smoke tests (`@smoke` tag)
- `regression` - Regression tests (`@regression` tag)

### 2. playwright.config.js

**Purpose:** Playwright configuration for native tests and browser settings

**Note:** Cucumber BDD tests primarily use environment variables, not this config

**Key Settings:**

```javascript
testDir: './tests',              // Playwright native tests
retries: 0,
workers: 3,
timeout: 60 * 1000,
expect: {
    timeout: 30000,
    toHaveScreenshot: {
        maxDiffPixels: 100,
        threshold: 0.2
    }
},
snapshotDir: './visual-regression/baseline',
updateSnapshots: process.env.UPDATE_SNAPSHOTS === 'true' ? 'all' : 'missing'
```

### 3. Environment Variables

**Core Variables:**

| Variable          | Values                                                                                                       | Default    | Purpose                   |
| ----------------- | ------------------------------------------------------------------------------------------------------------ | ---------- | ------------------------- |
| `NODE_ENV`        | `QA`, `SIT`, `UAT`, `PROD`                                                                                   | `QA`       | Environment for test data |
| `BROWSER`         | `chromium`, `firefox`, `webkit`, `mobile-chrome`, `mobile-webkit`, `tablet-ipad-webkit`, `Galaxy-Tab-chrome` | `chromium` | Browser/device to launch  |
| `HEADLESS`        | `true`, `false`                                                                                              | `true`     | Headless mode             |
| `PARALLEL_THREAD` | `1`, `2`, `3`, etc.                                                                                          | `1`        | Parallel workers          |
| `RETRY_COUNT`     | `0`, `1`, `2`, etc.                                                                                          | `0`        | Retry failed scenarios    |

**Screenshot/Video Variables:**

| Variable                | Values                            | Default  | Purpose                |
| ----------------------- | --------------------------------- | -------- | ---------------------- |
| `RECORD_VIDEO`          | `true`, `false`                   | `false`  | Enable video recording |
| `CAPTURE_VIDEO_ON`      | `all`, `failed`, `passed`         | `failed` | When to keep videos    |
| `CAPTURE_SCREENSHOT_ON` | `all`, `failed`, `passed`, `none` | `failed` | When to capture        |
| `SCREENSHOT_PER_STEP`   | `true`, `false`                   | `false`  | Per-step screenshots   |

**BrowserStack Variables:**

| Variable                  | Example             | Required |
| ------------------------- | ------------------- | -------- |
| `BROWSERSTACK_USERNAME`   | `your_username`     | Yes      |
| `BROWSERSTACK_ACCESS_KEY` | `your_key`          | Yes      |
| `BROWSERSTACK_TEST_NAME`  | `PLAYWRIGHT_CHROME` | No       |
| `BROWSERSTACK_OS`         | `osx`, `Windows`    | No       |
| `BROWSERSTACK_OS_VERSION` | `Sequoia`, `11`     | No       |

**Project-Specific Variables:**

| Variable       | Example                | Purpose                |
| -------------- | ---------------------- | ---------------------- |
| `PROJECT_NAME` | `Heathrow Communities` | Project name in report |
| `RELEASE`      | `1.0.0`                | Release version        |
| `CYCLE`        | `Sprint 1`             | Test cycle/sprint      |
| `CI`           | `true`                 | CI environment flag    |
| `CI_PROVIDER`  | `Azure DevOps`         | CI provider name       |
| `GIT_BRANCH`   | `feature/qns-module`   | Git branch name        |
| `GIT_COMMIT`   | `abc123`               | Git commit hash        |

---

## Test Execution

### NPM Scripts

#### BDD UI Tests

```bash
# QA sanity tests with Chromium (parallel)
npm run sanity:qa
# Runs: NODE_ENV=QA BROWSER=chromium PARALLEL_THREAD=2 HEADLESS=true --tags '@sanity'

# SIT sanity tests
npm run sanity:sit

# UAT sanity tests
npm run sanity:uat

# Custom test execution
npm run test
# Runs: NODE_ENV=QA BROWSER=chromium HEADLESS=false --tags '@myTest123'

# Mobile device test with video
npm run testNew
# Runs: NODE_ENV=QA BROWSER=Galaxy-Tab-chrome RECORD_VIDEO=true --tags '@loginToWelcome'
```

#### API Tests

```bash
# QA API regression (parallel)
npm run QARegressionTestAPI
# Runs: NODE_ENV=QA PARALLEL_THREAD=2 --tags '@ApiRegression'

# STAGE API regression
npm run STAGERegressionTestAPI
```

#### Accessibility Tests

```bash
# STAGE accessibility with Chromium
npm run STAGEAccessibilityTestChromeBrowser
# Runs: NODE_ENV=STAGE BROWSER=chromium --tags '@accessibility'
```

#### BrowserStack Tests

```bash
# BrowserStack Chrome on macOS
npm run browserStackChromeTestMac
# Requires: BROWSERSTACK_USERNAME, BROWSERSTACK_ACCESS_KEY

# BrowserStack Firefox on Windows
npm run browserStackFirefoxTestWindows
```

#### Reporting

```bash
# Generate multiple Cucumber HTML reports
npm run generateMultipleCucumberHtmlReport
# Runs: node reporter.js

# Generate Allure report
npm run allure-generate
npm run allure-open
# Or: npm run allure-serve

# Generate Axe accessibility HTML reports
npm run generateAxehtmlReport

# Clean reports and artifacts
npm run clean
```

#### Code Quality

```bash
# Lint JavaScript files
npm run lint

# Lint and auto-fix
npm run lint:fix

# Format code with Prettier
npm run format

# Check formatting
npm run format:check
```

### Direct Cucumber Execution

```bash
# Run specific tag
npx cucumber-js --tags '@qns'

# Run specific feature file
npx cucumber-js features/qns/submit-new-query.feature

# Run with parallel threads
npx cucumber-js --parallel 2

# Run specific profile
npx cucumber-js -p smoke

# Dry run (validate feature files)
npx cucumber-js --dry-run

# Generate JSON report
npx cucumber-js --format json:reports/cucumber_report.json
```

### Environment Setup

```bash
# Windows PowerShell
$env:NODE_ENV="SIT"
$env:BROWSER="chromium"
npx cucumber-js --tags '@qns'

# macOS/Linux
export NODE_ENV=SIT
export BROWSER=chromium
npx cucumber-js --tags '@qns'

# Cross-platform (recommended)
cross-env NODE_ENV=SIT BROWSER=chromium npx cucumber-js --tags '@qns'
```

### Device Emulation

```bash
# Mobile Chrome (Pixel 7)
cross-env BROWSER=mobile-chrome npx cucumber-js --tags '@qns'

# Mobile Safari (iPhone 15)
cross-env BROWSER=mobile-webkit npx cucumber-js --tags '@qns'

# Tablet iPad (iPad Pro 11)
cross-env BROWSER=tablet-ipad-webkit npx cucumber-js --tags '@qns'

# Tablet Android (Galaxy Tab S9)
cross-env BROWSER=Galaxy-Tab-chrome npx cucumber-js --tags '@qns'
```

---

## Reporting

### 1. Cucumber HTML Report

**Single Report:**

- **Location:** `reports/cucumber-report.html`
- **Generated by:** Cucumber formatter (automatic)
- **Command:** Included in cucumber-js execution

**Multiple Reports:**

- **Location:** `reports/index.html`
- **Generated by:** `reporter.js` using `multiple-cucumber-html-reporter`
- **Command:** `npm run generateMultipleCucumberHtmlReport`
- **Features:** Metadata (browser, environment, platform), custom data (project, framework, language)

### 2. JUnit XML Report

**Location:** `reports/junit-results.xml`

**Purpose:** CI/CD integration (Azure DevOps, Jenkins)

**Generated by:** Cucumber JUnit formatter (automatic)

### 3. Allure Report

**Generation:**

```bash
npm run allure-generate  # Generate report from results
npm run allure-open      # Open generated report
# Or
npm run allure-serve     # Generate and open in one step
```

**Configuration:**

- Formatter: `allure-cucumberjs/reporter` (in cucumber.js)
- Results directory: `allure-results/`
- Report directory: `allure-report/`

### 4. Accessibility Reports

**JSON Reports:**

- **Location:** `reports/axe-reports/json_reports/`
- **Generated by:** AccessibilityHelper
- **Format:** Axe-core JSON output

**HTML Reports:**

- **Location:** `reports/axe-reports/html_reports/`
- **Generated by:** `generateAxeReport.js`
- **Command:** `npm run generateAxehtmlReport`

**Workflow:**

1. Run tests with `@accessibility` tag
2. AccessibilityHelper creates JSON reports
3. Run `npm run generateAxehtmlReport` to convert JSON to HTML
4. Open HTML reports in `reports/axe-reports/html_reports/`

### 5. Screenshots and Videos

**Screenshots:**

- **Location:** `test-results/screenshots/`
- **When:** Based on `CAPTURE_SCREENSHOT_ON` env variable
- **Per-step:** Set `SCREENSHOT_PER_STEP=true`

**Videos:**

- **Location:** `test-results/videos/`
- **When:** Based on `CAPTURE_VIDEO_ON` env variable
- **Enable:** Set `RECORD_VIDEO=true`

**Configuration:**

```bash
# Capture screenshots and videos on failure only
cross-env CAPTURE_SCREENSHOT_ON=failed CAPTURE_VIDEO_ON=failed RECORD_VIDEO=true npx cucumber-js

# Capture for all scenarios
cross-env CAPTURE_SCREENSHOT_ON=all CAPTURE_VIDEO_ON=all RECORD_VIDEO=true npx cucumber-js
```

### 6. Execution Info Report

**Location:** `report-data/execution-info.json`

**Generated:** BeforeAll hook (worker 0 only)

**Content:**

```json
{
    "projectName": "Heathrow Communities",
    "framework": "Playwright + Cucumber",
    "language": "JavaScript",
    "environment": "QA",
    "browser": "chromium",
    "nodeVersion": "v18.x.x",
    "platform": "win32",
    "operatingSystem": "Windows_NT",
    "osVersion": "10.0.xxxxx"
}
```

---

## Agent Guidance

### When Adding a New Test

1. **Inspect existing feature files** for similar scenarios
2. **Determine appropriate feature file:**
    - Add to existing if related (e.g., QNS module tests in `/features/qns/`)
    - Create new if different functional area
3. **Check existing step definitions:**
    - Reuse existing steps when possible
    - Create new steps only if needed
    - Place QNS steps in `/features/step_definitions/qns/`
4. **Identify required page objects:**
    - Reuse existing page objects
    - Extend existing page objects with new locators/methods
    - Create new page object only for new pages
    - Place QNS page objects in `/pageobjects/qns/`
5. **Add test data:**
    - UI data: Add to appropriate `{ENV}_env_test_data.yml` file (QA, SIT, UAT, PROD)
    - QNS data: Create JSON file in `/testData/qns/`
    - API data: Add to appropriate environment folder
    - Use descriptive keys
6. **Add appropriate tags:**
    - Module tags: `@qns`, `@Heathrow`
    - Test type tags: `@qns-sanity`, `@qns-regression`, `@accessibility`
    - Work item IDs: `@777291`, `@752885`

### When Adding a New Page Object

1. **Create page object class** in `/pageobjects/{PageName}.js` or `/pageobjects/qns/{PageName}.js`:

    ```javascript
    import { expect } from '@playwright/test';
    import UIHelper from '../utils/UIHelper.js';

    class PageName {
        constructor(page) {
            this.page = page;
            this.UIHelper = new UIHelper(this.page);
            // Define all locators here
        }

        async methodName() {
            // Implementation
        }
    }

    export default PageName;
    // Or: export { PageName };
    ```

2. **Register in POManager.js:**

    ```javascript
    // Import
    import PageName from './qns/PageName.js';

    // In constructor
    this.PageName = new PageName(this.page);

    // Add getter
    getPageName() {
        return this.PageName;
    }
    ```

3. **Use in step definitions:**
    ```javascript
    const pageName = this.poManager.getPageName();
    await pageName.methodName();
    ```

### When Adding a New Step Definition

1. **Check existing steps first** - avoid duplicates
2. **Determine appropriate file:**
    - `ui-steps.js` - Common UI steps
    - `login-steps.js` - Login-specific steps
    - `qns/{feature-name}-steps.js` - QNS module steps
    - `demo-test/api-steps.js` - API steps
3. **Follow pattern:**

    ```javascript
    import { Given, When, Then } from '@cucumber/cucumber';

    When('I fill the {string} field if it is empty', async function (fieldName) {
        const pageObject = this.poManager.getNoiseComplaintFormPage();
        await pageObject.fillFieldIfEmpty(fieldName);
    });
    ```

4. **Use parameters** for flexibility: `{string}`, `{int}`, `{float}`
5. **Access CustomWorld** via `this`
6. **Use async functions** (not arrow functions)

### When Modifying Test Data

1. **Identify correct file:**
    - UI data: `/testData/uidata/{ENV}_env_test_data.yml`
    - QNS data: `/testData/qns/{test-name}-data.json`
    - API data: `/testData/apidata/{ENV}/{scenarioType}.json`
2. **Use consistent naming:**
    - Descriptive keys
    - CamelCase for YAML keys
    - camelCase for JSON keys
3. **Update all environments** (QA, SIT, UAT, PROD) for YAML data
4. **Validate syntax:**
    - YAML: indentation matters
    - JSON: valid structure

### When Debugging Failures

1. **Check reports:**
    - `reports/cucumber-report.html` - Single HTML report
    - `reports/index.html` - Multiple reports
    - `reports/junit-results.xml` - JUnit XML
    - `allure-report/` - Allure report
2. **Check screenshots:**
    - `test-results/screenshots/` - Failure screenshots
3. **Check videos:**
    - `test-results/videos/` - Failure videos
4. **Check console output:**
    - `console.log()` statements in page objects and steps
5. **Enable per-step screenshots:**
    ```bash
    cross-env SCREENSHOT_PER_STEP=true npx cucumber-js
    ```
6. **Run in headed mode:**
    ```bash
    cross-env HEADLESS=false npx cucumber-js
    ```
7. **Increase timeouts:**
    - Check `setDefaultTimeout()` in hooks.js (default: 60000ms)
    - Add `{ timeout: 90000 }` to specific Playwright actions
8. **Test on specific device:**
    ```bash
    cross-env BROWSER=mobile-chrome HEADLESS=false npx cucumber-js
    ```

---

## Do Not

### Language and Syntax

❌ **Do NOT introduce TypeScript**

- No `.ts` files
- No type annotations
- No interfaces or types
- No TypeScript-specific syntax

❌ **Do NOT use CommonJS syntax**

- No `require()` - use `import`
- No `module.exports` - use `export`
- This is ES Modules (`"type": "module"`)

### Framework Patterns

❌ **Do NOT modify hooks.js without understanding the complete flow**

- Singleton browser pattern is critical
- CustomWorld lifecycle must be preserved
- Screenshot/video capture depends on hook timing
- Device emulation logic must be maintained

❌ **Do NOT hardcode URLs or test data in page objects or steps**

- Use `TestDataUtils.getData()` for UI data (YAML)
- Use JSON files for QNS module data
- Use environment-based YAML/JSON files
- Reference test data keys in feature files

❌ **Do NOT create duplicate page objects**

- Check existing page objects first
- Extend existing page objects when possible
- Reuse locators and methods

❌ **Do NOT define locators outside of constructor**

- All locators must be in page object constructor
- Avoid scattered locator definitions in methods

❌ **Do NOT bypass UIHelper for common actions**

- Use `UIHelper.clickOnWebElement()` instead of `element.click()`
- Use `UIHelper.enterTextForWebElement()` instead of `element.fill()`
- Follow established patterns

❌ **Do NOT access page objects directly in steps**

- Always use `this.poManager.getPageName()`
- Do not instantiate page objects in steps

❌ **Do NOT use arrow functions in step definitions**

- Use `async function` to preserve `this` context
- `this` is CustomWorld instance

❌ **Do NOT confuse assertion methods with conditional checks**

- Use `verifyElementIsVisible()` for **assertions** (fails scenario)
- Use `checkElementVisibility()` for **conditional logic** (returns boolean)
- Do not use assertion methods inside if/else statements

### Configuration and Reporting

❌ **Do NOT modify cucumber.js paths or require statements without verification**

- Paths are relative to project root
- Changing patterns may break step loading

❌ **Do NOT change reporter configuration without understanding the impact**

- Multiple reporters are configured
- Each has specific output format and location

❌ **Do NOT commit actual credentials or secrets**

- Use environment variables
- Use `.env` files (gitignored)
- Never hardcode credentials in test data
- Use `.env.example` as template

### Test Organization

❌ **Do NOT create feature files outside `/features` directory**

- All features must be in `/features`, `/features/qns`, or `/features/demo-tests`
- Cucumber is configured to find features in `features/**/*.feature`

❌ **Do NOT create step definitions with incorrect naming pattern**

- Must end with `-steps.js`
- Must be in `/features/step_definitions/` or appropriate subdirectory
- Pattern: `features/step_definitions/**/*-steps.js`

❌ **Do NOT mix Cucumber BDD and Playwright native test execution**

- Cucumber tests use `npx cucumber-js`
- Playwright native tests use `npx playwright test`
- Different execution models and configurations

---

## Dependencies

**Production:**

- `@cucumber/cucumber` ^13.0.0 - BDD framework
- `@playwright/test` ^1.61.1 - Browser automation
- `js-yaml` ^5.2.1 - YAML parsing for test data
- `jsonpath` ^1.3.0 - JSONPath for API validation
- `multiple-cucumber-html-reporter` ^4.1.0 - HTML reporting
- `config` 4.4.2 - Configuration management
- `fs-extra` ^11.3.6 - File system utilities
- `dotenv` ^17.4.2 - Environment variable management

**Development:**

- `@axe-core/playwright` ^4.12.1 - Accessibility testing
- `allure-cucumberjs` ^3.10.2 - Allure reporting
- `allure-commandline` ^2.43.0 - Allure CLI
- `allure-playwright` ^3.10.2 - Allure Playwright integration
- `chai` ^6.2.2 - Assertions
- `cross-env` ^10.1.0 - Cross-platform env variables
- `cucumber-html-reporter` ^5.0.2 - HTML reporter
- `axe-html-reporter` ^2.2.11 - Axe HTML reports
- `eslint` ^10.7.0 - Code linting
- `prettier` 3.9.5 - Code formatting
- `globals` ^17.7.0 - Global variables for ESLint

---

## CI/CD Integration

### Azure DevOps Pipelines

**Location:** `/pipeline/azure/*.yml`

**Available Pipelines:**

- `copado-post-deploy-sanity.yml` - Copado post-deployment sanity tests
- `cucumber-custom.yml` - Custom Cucumber test execution
- `cucumber-sanity.yml` - Sanity test suite
- `playwright-custom.yml` - Custom Playwright execution
- `playwright-visual-comparison.yml` - Visual regression tests

### Jenkins

**Location:** `Jenkinsfile`

**Integration:** Jenkins declarative pipeline

### Copado Integration

**Documentation:** `referece docs/COPADO-INTEGRATION.md`

**Purpose:** Post-deployment automated testing

---

## Summary

This framework uses **Cucumber.js + JavaScript + Playwright** with:

- **ES Modules** (not CommonJS, not TypeScript)
- **Page Object Model** with POManager factory
- **CustomWorld** for scenario isolation
- **Singleton Browser** for resource optimization
- **Environment-based test data** (YAML for UI, JSON for QNS module)
- **Device emulation** (Mobile Chrome, Mobile Safari, iPad, Galaxy Tab)
- **Multiple reporting** (Cucumber HTML, JUnit XML, Allure, Serenity, Axe)
- **Accessibility testing** with Axe-core
- **Configurable screenshots and videos**
- **BrowserStack integration**
- **CI/CD integration** (Azure DevOps, Jenkins, Copado)

**Key Principles:**

1. Inspect existing code before creating new code
2. Reuse page objects, utilities, and step definitions
3. Follow established patterns and naming conventions
4. Use environment variables for configuration
5. Reference test data from YAML/JSON files
6. Do not introduce TypeScript or change module system
7. Do not modify framework core (hooks, CustomWorld) without understanding impact
8. Use QNS-specific patterns for QNS features
9. Leverage device emulation for mobile/tablet testing
10. Use UIHelper methods consistently (understand assertion vs. conditional methods)

**When in doubt:**

- Check existing implementations
- Follow the patterns demonstrated in QNS module tests
- Reuse existing components
- Ask before making framework-level changes
- Review reference documentation in `referece docs/`
