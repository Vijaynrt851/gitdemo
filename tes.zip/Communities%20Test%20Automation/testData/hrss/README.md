# HRSS Valuation Report Test Data

This folder contains test data for HRSS Valuation Report automation tests.

## Files

### valuationReportData.json
Contains test data for 3 different valuation reports with different:
- Property types (Detached, Semi-Detached, Terraced)
- Locations (London, Manchester, Bristol)
- Users (Kumar Singh, Priya Sharma, David Chen)
- Market values and comparable sales data

**Structure:**
```json
{
  "testCaseId": "VR_001",
  "testCaseName": "Descriptive test case name",
  "deliverableId": "128",
  "reportDetails": {
    "reportPreparedBy": "Name",
    "purposeOfValuation": "Purpose",
    "inspectionDate": "Date",
    "valuationDate": "Date",
    "preparedByDate": "Date",
    "tenureType": "Freehold/Leasehold",
    "propertyType": "Detached/Semi-Detached/Terraced",
    "legalIssuesIdentified": "Yes/No"
  },
  "propertyDetails": {
    "reducedHeightArea": "120",
    "privateGarageArea": "140",
    "locationDescription": "Description",
    "propertyDescription": "Description",
    "accommodationDetails": "Details",
    "commentaryOnRepair": "Commentary",
    "townPlanningBuildingRegulations": "Info",
    "energyEnvironmental": "Info",
    "servicesAmenities": "Info",
    "tenure": "Info"
  },
  "comparableSales": [
    {
      "flatNumber": "101",
      "buildingName": "Building Name",
      "streetNumber": "45",
      "streetName": "Street Name",
      "postcode": "AL3 8LE",
      "saleDate": "Sep 03, 2026",
      "salePrice": "1400000",
      "grossInternalArea": "150",
      "bedrooms": "3",
      "description": "Description",
      "comparisonWithSubject": "Comparison notes"
    }
  ],
  "marketValueSection": {
    "marketValue": "1400000",
    "marketValueWords": "fourteen lakh pounds",
    "areasNotInspected": "All areas inspected",
    "approverName": "Name",
    "approverEmail": "email@domain.com"
  },
  "ricsDetails": {
    "valuerRICSQual": "MRICS",
    "valuerRICSNumber": "1050",
    "valuerJobTitle": "Job Title",
    "approverRICSQual": "MRICS",
    "approverRICSNumber": "1020",
    "approverJobTitle": "Job Title"
  }
}
```

### userCredentials.json
Contains user credentials for different valuation report submitters.

**Note:** Currently using credentials from `.env` file. This file can be used for future multi-user scenarios.

```json
{
  "userId": "user1",
  "username": "email@domain.com",
  "password": "password",
  "userRole": "Valuer"
}
```

## Usage

The test file [valuationreport.spec.js](../../tests/HRSS/valuationreport.spec.js) automatically loads all test cases from `valuationReportData.json` and executes them sequentially.

Each test case will:
1. Log in with credentials from `.env`
2. Search and open the deliverable using `deliverableId`
3. Fill the valuation report form with data from the test case
4. Complete the form submission

## Test Cases

### VR_001: Valuation Report - User 1 - Detached Property
- Location: North London
- Property Type: Detached (3 bedrooms)
- Market Value: £1,400,000
- Prepared by: Kumar Singh
- Approver: John Matthews (Manager)

### VR_002: Valuation Report - User 2 - Semi-Detached Property
- Location: Central Manchester
- Property Type: Semi-Detached (2 bedrooms)
- Market Value: £950,000
- Prepared by: Priya Sharma
- Approver: Sarah Wilson (Senior Manager)

### VR_003: Valuation Report - User 3 - Terraced Property
- Location: Bristol City Centre
- Property Type: Terraced (4 bedrooms)
- Market Value: £1,250,000
- Prepared by: David Chen
- Approver: Michael O'Brien (Director)

## Adding New Test Cases

To add a new valuation report test case:

1. Add a new object to `valuationReportData.json` array
2. Ensure all required fields are populated with realistic data
3. The test file will automatically pick up the new test case on next run

## Notes

- All dates in test data are in format: "Sep 03, 2026"
- Comparable Sales section contains 4 properties for each valuation
- All test data uses realistic UK property locations and pricing
- RICS qualifications default to "MRICS" for all users
