import fs from 'fs';
import path from 'path';
import * as yaml from 'js-yaml';

const UI_DATA_DIR = './testData/uidata';
const DEFAULT_ENV = 'QA';

class TestDataUtils {
    /**
     * Resolve the environment the run is targeting. Copado sets NODE_ENV via the
     * pipeline (QA | SIT | UAT | STAGE | PROD); anything unset falls back to QA.
     */
    getEnv() {
        return (process.env.NODE_ENV || DEFAULT_ENV).toUpperCase();
    }

    /**
     * Get the current timestamp in ISO 8601 format.
     * Centralized here so tests needing a unique timestamp (e.g. for
     * comments, query subjects/descriptions) reuse the same logic.
     * @returns {string} Current date/time as an ISO string
     */
    getCurrentTimestamp() {
        return new Date().toISOString();
    }

    async getData(data) {
        try {
            const env = this.getEnv();
            const envFile = path.join(UI_DATA_DIR, `${env}_env_test_data.yml`);

            // Deliberately no fallback to another environment's file. Falling back
            // means a run labelled SIT quietly exercises the QA org and reports a
            // green suite for an environment nobody tested.
            if (!fs.existsSync(envFile)) {
                throw new Error(`No test data file for environment ${env}. Expected ${envFile}.`);
            }

            const yamlFileContent = fs.readFileSync(envFile, 'utf8');
            const config = yaml.load(yamlFileContent);
            return config[data];
        } catch (err) {
            console.error('Error reading or parsing the Data YAML file:', err);
            throw err;
        }
    }

    /**
     * Credentials are supplied per environment as <ENV>_USERNAME / <ENV>_PASSWORD
     * pipeline secrets, so a new environment needs no code change here.
     */
    getUsernameAndPassword() {
        const env = this.getEnv();

        const username = process.env[`${env}_USERNAME`];
        const password = process.env[`${env}_PASSWORD`];

        if (!username || !password) {
            throw new Error(`Missing credentials for environment: ${env}. Set ${env}_USERNAME and ${env}_PASSWORD.`);
        }

        return { username, password };
    }

    /**
     * Get QNS form validation test data
     * @returns {Object} Validation test data including valid and invalid field values
     */
    getQNSValidationData() {
        try {
            const qnsDataFile = path.join('./testData/qns', 'form-validation-data.json');
            if (!fs.existsSync(qnsDataFile)) {
                throw new Error(`QNS validation test data file not found: ${qnsDataFile}`);
            }
            const fileContent = fs.readFileSync(qnsDataFile, 'utf8');
            return JSON.parse(fileContent);
        } catch (err) {
            console.error('Error reading QNS validation test data:', err);
            throw err;
        }
    }

    /**
     * Get QNS My Account test data
     * @returns {Object} My Account test data including expected field values
     */
    getQNSMyAccountData() {
        try {
            const qnsDataFile = path.join('./testData/qns', 'my-account-data.json');
            if (!fs.existsSync(qnsDataFile)) {
                throw new Error(`QNS My Account test data file not found: ${qnsDataFile}`);
            }
            const fileContent = fs.readFileSync(qnsDataFile, 'utf8');
            return JSON.parse(fileContent);
        } catch (err) {
            console.error('Error reading QNS My Account test data:', err);
            throw err;
        }
    }

    /**
     * Get QNS Save Personal Details test data (Story 777291)
     * @deprecated Use getQNSSubmitNewQueryData() instead
     * @returns {Object} Save personal details test data including saved details and submission data
     */
    getQNSSavePersonalDetailsData() {
        try {
            const qnsDataFile = path.join('./testData/qns', 'save-personal-details-data.json');
            if (!fs.existsSync(qnsDataFile)) {
                throw new Error(`QNS Save Personal Details test data file not found: ${qnsDataFile}`);
            }
            const fileContent = fs.readFileSync(qnsDataFile, 'utf8');
            return JSON.parse(fileContent);
        } catch (err) {
            console.error('Error reading QNS Save Personal Details test data:', err);
            throw err;
        }
    }

    /**
     * Get QNS Submit New Query test data (Story 777291)
     * @returns {Object} Submit new query test data including saved details, first and second submissions
     */
    getQNSSubmitNewQueryData() {
        try {
            const qnsDataFile = path.join('./testData/qns', 'submit-new-query-data.json');
            if (!fs.existsSync(qnsDataFile)) {
                throw new Error(`QNS Submit New Query test data file not found: ${qnsDataFile}`);
            }
            const fileContent = fs.readFileSync(qnsDataFile, 'utf8');
            return JSON.parse(fileContent);
        } catch (err) {
            console.error('Error reading QNS Submit New Query test data:', err);
            throw err;
        }
    }

    /**
     * Get QNS Home Page test data (Story 775514)
     * @returns {Object} Home page test data including Key Policies and Processes component data
     */
    getQNSHomePageData() {
        try {
            const qnsDataFile = path.join('./testData/qns', 'homePage-qns-data.json');
            if (!fs.existsSync(qnsDataFile)) {
                throw new Error(`QNS Home Page test data file not found: ${qnsDataFile}`);
            }
            const fileContent = fs.readFileSync(qnsDataFile, 'utf8');
            return JSON.parse(fileContent);
        } catch (err) {
            console.error('Error reading QNS Home Page test data:', err);
            throw err;
        }
    }
}
export { TestDataUtils };
