import base from '@playwright/test';

export const customtest = base.test.extend(
{
testDataForOrder :    {
    username : "test.in@gmail.com",
    password : "Password1234",
    productName:"ADIDAS ORIGINAL"
    }

}

)




