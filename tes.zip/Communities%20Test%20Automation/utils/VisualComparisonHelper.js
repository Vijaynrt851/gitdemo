/**
 * VisualComparisonHelper - Page preparation utility for visual comparison
 * 
 * This utility contains ONLY reusable page preparation logic to make screenshots deterministic.
 * It does NOT wrap Playwright's native visual comparison APIs.
 * 
 * Tests should call Playwright's native assertions directly:
 *   await expect(page).toHaveScreenshot(...);
 *   await expect(locator).toHaveScreenshot(...);
 */
class VisualComparisonHelper {
    /**
     * Wait for page to be stable before capturing screenshot
     * Ensures page is fully loaded and network activity has settled
     * @param {Page} page - Playwright page object
     */
    async waitForPageStability(page) {
        await page.waitForLoadState('load');
        // Below method is not recommended for salesforce application.
        /*
        await page.waitForLoadState('networkidle', { timeout: 50000 }).catch(() => {
            console.log('Network idle timeout - proceeding with screenshot');
        });
        */
    }

    /**
     * Hide dynamic elements that may cause false positives in visual comparison
     * @param {Page} page - Playwright page object
     * @param {Array<string>} selectors - Array of CSS selectors to hide
     */
    async hideDynamicElements(page, selectors = []) {
        for (const selector of selectors) {
            try {
                await page.locator(selector).evaluateAll(elements => {
                    elements.forEach(el => el.style.visibility = 'hidden');
                });
            } catch (error) {
                console.log(`Could not hide element: ${selector}`);
            }
        }
    }

    /**
     * Disable animations on the page to ensure consistent screenshots
     * @param {Page} page - Playwright page object
     */
    async disableAnimations(page) {
        await page.addStyleTag({
            content: `
                *,
                *::before,
                *::after {
                    animation-duration: 0s !important;
                    animation-delay: 0s !important;
                    transition-duration: 0s !important;
                    transition-delay: 0s !important;
                }
            `
        });
    }

    /**
     * Scroll to the top of the page
     * Ensures consistent viewport position for full-page screenshots
     * @param {Page} page - Playwright page object
     */
    async scrollToTop(page) {
       // await page.evaluate(() => window.scrollTo(0, 0));
    }

    /**
     * Prepare page for visual comparison
     * Combines common preparation steps: stability, animations, scroll position
     * @param {Page} page - Playwright page object
     * @param {Object} options - Preparation options
     * @param {Array<string>} options.hiddenSelectors - Selectors to hide
     * @param {boolean} options.disableAnimations - Whether to disable animations (default: true)
     * @param {boolean} options.scrollToTop - Whether to scroll to top (default: true)
     */
    async preparePage(page, options = {}) {
        const {
            hiddenSelectors = [],
            disableAnimations = true,
            scrollToTop = true
        } = options;

        // Wait for page stability
        await this.waitForPageStability(page);

        // Disable animations if requested
        if (disableAnimations) {
            await this.disableAnimations(page);
        }

        // Scroll to top if requested
        if (scrollToTop) {
            await this.scrollToTop(page);
        }

        // Hide dynamic elements if provided
        if (hiddenSelectors.length > 0) {
            await this.hideDynamicElements(page, hiddenSelectors);
        }
    }
}

export { VisualComparisonHelper };
