import fs from 'fs/promises';
import path from 'path';

class VideoHelper {
  constructor() {
    this.videoDir = './test-results/videos';
  }

  /**
   * Handle video recording following Playwright lifecycle
   * CRITICAL: Video must be accessed AFTER context.close()
   * 
   * @param {Video} video - Playwright video object (obtained BEFORE context.close())
   * @param {string} scenarioName - Scenario name
   * @param {number} line - Scenario line number
   * @param {string} status - Scenario status (passed/failed)
   * @param {Function} attachFn - Cucumber attach function
   * @returns {Promise<void>}
   */
  async handleVideo(video, scenarioName, line, status, attachFn = null) {
    if (!video) {
      console.warn('Video object is null, skipping video handling');
      return;
    }

    const recordVideo = process.env.RECORD_VIDEO === 'true';
    if (!recordVideo) {
      return;
    }

    const captureMode = process.env.CAPTURE_VIDEO_ON || 'failed';
    
    // Determine if video should be kept
    const shouldKeep = 
      captureMode === 'all' || 
      (captureMode === 'failed' && status === 'failed') ||
      (captureMode === 'passed' && status === 'passed');

    try {
      // IMPORTANT: Wait for video to be saved (happens after context close)
      // Playwright finalizes video after context.close()
      const videoPath = await video.path();
      
      if (!videoPath) {
        console.warn('Video path is null, video may not have been recorded');
        return;
      }

      console.log(`Video recorded at: ${videoPath}`);

      if (shouldKeep) {
        // Keep and rename video
        await this.saveVideo(videoPath, scenarioName, line, attachFn);
      } else {
        // Delete video to save space
        await this.deleteVideo(videoPath);
      }
    } catch (error) {
      console.error(`Failed to handle video: ${error.message}`);
    }
  }

  /**
   * Save and rename video
   * @param {string} videoPath - Original video path
   * @param {string} scenarioName - Scenario name
   * @param {number} line - Scenario line number
   * @param {Function} attachFn - Cucumber attach function
   * @returns {Promise<void>}
   */
  async saveVideo(videoPath, scenarioName, line, attachFn = null) {
    try {
      // Ensure video directory exists
      await this.ensureDirectoryExists(this.videoDir);

      // Generate safe filename
      const safeScenarioName = this.sanitizeFileName(scenarioName);
      const targetFilename = `${safeScenarioName}(${line}).webm`;
      const targetPath = path.join(this.videoDir, targetFilename);

      // Rename video
      await fs.rename(videoPath, targetPath);
      console.log(`Video saved: ${targetFilename}`);

      // Attach to Cucumber report if attach function provided
      if (attachFn && typeof attachFn === 'function') {
        const videoBuffer = await fs.readFile(targetPath);
        await this.attach(videoBuffer, {
    mediaType: "video/webm"
});
        console.log(`Video attached to report`);
      }
    } catch (error) {
      console.error(`Failed to save video: ${error.message}`);
      throw error;
    }
  }

  /**
   * Delete video file
   * @param {string} videoPath - Video file path
   * @returns {Promise<void>}
   */
  async deleteVideo(videoPath) {
    try {
      await fs.unlink(videoPath);
      console.log(`Video deleted: ${videoPath}`);
    } catch (error) {
      // File might not exist or already deleted
      if (error.code !== 'ENOENT') {
        console.error(`Failed to delete video: ${error.message}`);
      }
    }
  }

  /**
   * Sanitize filename to remove invalid characters
   * @param {string} name - Original name
   * @returns {string} - Sanitized name
   */
  sanitizeFileName(name) {
    return name.replace(/[<>:"/\\|?*]/g, '_').substring(0, 100);
  }

  /**
   * Ensure directory exists, create if not
   * @param {string} dirPath - Directory path
   * @returns {Promise<void>}
   */
  async ensureDirectoryExists(dirPath) {
    try {
      await fs.access(dirPath);
    } catch {
      await fs.mkdir(dirPath, { recursive: true });
    }
  }
}

export { VideoHelper };
