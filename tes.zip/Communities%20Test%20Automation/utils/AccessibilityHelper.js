import { AxeBuilder } from '@axe-core/playwright';
import fs from 'fs';
import path from 'path';

class AccessibilityHelper {
    /**
     * Runs an accessibility scan based on the selected WCAG tag.
     * @param {object} page - Playwright page object.
     * @param {string} testName - Name of the test for reporting.
     * @param {Array} wcagTags - WCAG tags to apply (A or AA).
     * @returns {Promise<string|null>} - Path to the report file if violations exist.
     */
    async checkWCAG(page, testName, wcagTags) {
        console.log(`🔍 Running accessibility scan for: ${testName} with tags: ${wcagTags.join(', ')}`);

        const results = await new AxeBuilder({ page })
            .withTags(wcagTags)
            .analyze();

        console.error(`❌ Accessibility Violations Found: ${results.violations.length}`);

        if (results.violations.length > 0) {
            console.error(`❌ Accessibility Violations Found: ${results.violations.length}`);

            const reportsDir = './reports/axe-reports/json_reports';
            if (!fs.existsSync(reportsDir)) {
                fs.mkdirSync(reportsDir, { recursive: true });
            }
            const filePath = path.join(reportsDir, `axe_${testName}.json`);
            fs.writeFileSync(filePath, JSON.stringify(results, null, 2));

            console.log(`📄 Accessibility report saved at: ${filePath}`);
            return filePath;
        } else {
            console.log('✅ No accessibility violations found!');
            return null;
        }
    }
}

export { AccessibilityHelper };
