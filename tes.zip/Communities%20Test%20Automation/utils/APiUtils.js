import fsexe from 'fs-extra';
import { expect, request } from '@playwright/test';
import jp from 'jsonpath';
import { assert } from 'chai';

let response;

class APiUtils {
    async postCall(scenarioType) {
        let apiContext = await request.newContext();
        var data = await fsexe.readFileSync('testData/apidata/' + process.env.NODE_ENV + '/' + scenarioType + '.json', 'utf8');
        var apiData = JSON.parse(data);
        response = await apiContext.post(apiData.url, {
            data: apiData.data,
            headers: apiData.header,
        });
        console.log('Response body ', await response.json());
    }

    async putCall(scenarioType) {
        let apiContext = await request.newContext();
        var data = await fsexe.readFileSync('testData/apidata/' + process.env.NODE_ENV + '/' + scenarioType + '.json', 'utf8');
        var apiData = JSON.parse(data);
        console.log("Input request payload body ", apiData.data);
        response = await apiContext.put(apiData.url, {
            data: apiData.data,
            headers: apiData.header,
        });
        console.log('Response body ', await response.json());
    }

    async getCall(scenarioType) {
        let apiContext = await request.newContext();
        var data = await fsexe.readFileSync('testData/apidata/' + process.env.NODE_ENV + '/' + scenarioType + '.json', 'utf8');
        var apiData = JSON.parse(data);
        response = await apiContext.get(apiData.url, {
            headers: apiData.header,
        });
        console.log('Response body ', await response.json());
    }

    async deleteCall(scenarioType) {
        let apiContext = await request.newContext();
        var data = await fsexe.readFileSync('testData/apidata/' + process.env.NODE_ENV + '/' + scenarioType + '.json', 'utf8');
        var apiData = JSON.parse(data);
        response = await apiContext.delete(apiData.url, {
            headers: apiData.header,
        });
    }

    async validateResponseStatusCode(expectedStatusCode) {
        expect(response.status()).toBe(Number(expectedStatusCode));
    }

    async validateData(jsonQuery, value) {
        console.log('Json Query ', jsonQuery);
        const apiResponse = await response.json();
        var actualValue = await jp.query(apiResponse, jsonQuery);
        console.log('Actual Value : ', actualValue);
        await assert.equal(value, actualValue);
    }
}

export { APiUtils };
