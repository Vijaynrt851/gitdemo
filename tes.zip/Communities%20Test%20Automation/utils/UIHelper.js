import { test, expect } from '@playwright/test';

class UIHelper {
    constructor(page) {
        this.page = page;
    }

    async enterTextForWebElement(webElement, inputText) {
        console.log(`Onto method :: inputTextForWebElement`);
        await webElement.type(inputText);
    }

    async enterTextForWebElementWithClear(webElement, inputText) {
        console.log(`Onto method :: inputTextForWebElementWithClear`);
        await webElement.fill(''); // Clear the input field
        await webElement.type(inputText);
    }

    async clickOnWebElement(webElement) {
        console.log(`Onto method :: clickOnWebElement`);
        await webElement.click();
    }

    async doubleClickOnWebElement(webElement) {
        console.log(`Onto method :: doubleClickOnWebElement`);
        await webElement.dblclick();
    }

    async check(webElement) {
        console.log(`Onto method :: check box`);
        await webElement.check();
    }

    async getAllTextContentOfWebElement(webElement) {
        console.log(`Onto method :: getTextContentOfWebElement`);
        return webElement.allTextContents();
    }

    async getTextContentOfWebElement(webElement) {
        console.log(`Onto method :: getTextContentOfWebElement`);
        return webElement.textContent();
    }

    async mouseHoverOnTheElement(webElement) {
        console.log(`Onto method :: mouseHoverOnTheElement`);
        return webElement.hover();
    }

    async selectDropDownMenuOption(webElement, option) {
        console.log(`Onto method :: Select dropdown menu`);
        await webElement.selectOption(option);
    }

    /**
     * Positive assertion.
     * Fails the scenario if the element is not visible.
     * Does not return a boolean.
     */
    async verifyElementIsVisible(webElement) {
        console.log(`Onto method :: verifyElementIsVisible`);
        this.page.waitForLoadState('load');

        await expect(webElement).toBeVisible({
            timeout: 20000,
        });
    }

    /**
     * Negative assertion.
     * Fails the scenario if the element becomes/remains visible.
     * Does not return a boolean.
     */
    async verifyElementIsNotVisible(webElement) {
        console.log(`Onto method :: verifyElementIsNotVisible`);
        this.page.waitForLoadState('load');
        await expect(webElement).not.toBeVisible({
            timeout: 20000,
        });
    }

    async clearWebElement(webElement) {
        console.log('Onto method :: clearWebElement');
        await webElement.clear();
    }

    async scrollIntoView(webElement) {
        console.log('Onto method :: scrollIntoView');
        await webElement.scrollIntoViewIfNeeded();
    }

    async waitForPageLoad(state = 'domcontentloaded', timeout = 20000) {
        console.log(`Onto method :: waitForPageLoad with state: ${state}`);
        await this.page.waitForLoadState(state, { timeout });
    }

    /**
     * Conditional visibility status check.
     * Returns true or false without failing the scenario.
     * Use this only when the Page Object needs an if/else decision.
     */
    async checkElementVisibility(webElement, timeout = 5000) {
        console.log('Onto method :: checkElementVisibility');
        try {
            await webElement.waitFor({ state: 'visible', timeout });
            return true;
        } catch {
            return false;
        }
    }
}

export default UIHelper;
