import { chromium, firefox, webkit } from '@playwright/test';
import { BrowserConstants } from '../constants/BrowserConstants.js';
import { threadId, isMainThread } from "node:worker_threads";

const browserConstants = new BrowserConstants();

const browserOptions = {
    slowMo: 50,
    args: ['--start-maximized', '--disable-extensions', '--disable-plugins'],
    headless: process.env.HEADLESS !== "false"
};

let browser;
let browserPromise;

class BrowserUtils {

async getBrowser() {
    if (browser?.isConnected()) {
        console.log(
    `Returning browser ${browser ? "existing" : "new"}`
);
        return browser;      
    }

    if (!browserPromise) {
        browserPromise = this.createBrowser().then((b) => {
            browser = b;
            return b;
        });
    }

    return browserPromise;
}

// async closeBrowser() {
//     if (browser?.isConnected()) {
//         await browser.close();
//     }

//     browser = undefined;
//     browserPromise = undefined;
// }

async closeBrowser() {
    console.log(`Closing browser. thread=${threadId}`);

    if (browser?.isConnected()) {
        await browser.close();
        console.log(`Browser closed. thread=${threadId}`);
    }
    browser = undefined;
    browserPromise = undefined;
}

    async createBrowser() {
        const browserType = process.env.BROWSER || "chromium";
        const isBrowserStack =
            process.env.BROWSERSTACK_USERNAME &&
            process.env.BROWSERSTACK_ACCESS_KEY;
        
        console.log(
    `Creating browser. PID=${process.pid}, browserType=${browserType}`
);

console.log({
    pid: process.pid,
    threadId,
    isMainThread
});

        if (isBrowserStack) {
            const wsEndpoint = this.getBrowserStackWSEndpoint(browserType);
            return this.connectToBrowserStack(wsEndpoint, browserType);
        }

        return this.launchLocalBrowser(browserType);
    }

    // async launchBrowser() {
    //     console.log("Launching Browser");
    //     const browserType = process.env.BROWSER;
    //     const isBrowserStack = process.env.BROWSERSTACK_USERNAME && process.env.BROWSERSTACK_ACCESS_KEY;
    //     if (isBrowserStack) {
    //         const wsEndpoint = this.getBrowserStackWSEndpoint(browserType);
    //         browser = await this.connectToBrowserStack(wsEndpoint, browserType);
    //     } else {
    //         browser = await this.launchLocalBrowser(browserType);
    //     }

    //     return browser;
    // }

    async launchLocalBrowser(browserType) {
    switch (browserType?.toLowerCase()) {
        case browserConstants.getFirefox():
            console.log("Launching Firefox");
            return await firefox.launch(browserOptions);

        case browserConstants.getWebkit():
            console.log("Launching WebKit");
            return await webkit.launch(browserOptions);

        case browserConstants.getEdge():
            console.log("Launching Microsoft Edge");
            return await chromium.launch({
                ...browserOptions,
                channel: "msedge"
            });

        case browserConstants.getMobileChrome():
           console.log("Launching Chromium for Mobile Chrome");
           return await chromium.launch(browserOptions);

        case browserConstants.getMobileWebkit():
           console.log("Launching WebKit for Mobile Safari");
           return await webkit.launch(browserOptions);

        case browserConstants.getGalaxyTabChrome():
           console.log("Launching Chromium for Galaxy Tab");
           return await chromium.launch(browserOptions);

        case browserConstants.getTabletIpadWebkit():
           console.log("Launching WebKit for iPad");
           return await webkit.launch(browserOptions);

        case browserConstants.getChromium():
        default:
            console.log("Launching Chromium");
            return await chromium.launch(browserOptions);
    }
}

    async connectToBrowserStack(wsEndpoint, browserType) {
        if (browserConstants.getFirefox() === browserType) {
            return await firefox.connect({ wsEndpoint });
        } else if (browserConstants.getWebkit() === browserType) {
            console.log("Connecting to WebKit");
            return await webkit.connect({ wsEndpoint });
        } else {
            return await chromium.connect({ wsEndpoint });
        }
    }

    getBrowserStackWSEndpoint(browserType) {
        const caps = {
            'browserstack.username': process.env.BROWSERSTACK_USERNAME,
            'browserstack.accessKey': process.env.BROWSERSTACK_ACCESS_KEY,
            'name': process.env.BROWSERSTACK_TEST_NAME || 'Playwright Test',
            'build': process.env.BROWSERSTACK_BUILD || 'Playwright Build',
            'os': process.env.BROWSERSTACK_OS || 'osx',
            'os_version': process.env.BROWSERSTACK_OS_VERSION || 'Sequoia'
        };

        if (browserConstants.getFirefox() === browserType) {
            caps.browser = 'playwright-firefox';
            caps.browser_version = 'latest';
        } else if (browserConstants.getWebkit() === browserType) {
            caps.browser = 'playwright-webkit';
            caps.browser_version = 'latest';
        } else {
            caps.browser = 'playwright-chromium';
            caps.browser_version = 'latest';
        }

        return `wss://cdp.browserstack.com/playwright?caps=${encodeURIComponent(JSON.stringify(caps))}`;
    }
}

export { BrowserUtils };
