import fs from 'fs/promises';
import path from 'path';

class ScreenshotHelper {
  constructor() {
    this.screenshotDir = './test-results/screenshots';
    this.stepCounter = 0;
  }

  /**
   * Capture screenshot based on configuration
   * @param {Page} page - Playwright page object
   * @param {string} scenarioName - Scenario name
   * @param {number} line - Scenario line number
   * @param {string} status - Scenario/step status (passed/failed)
   * @param {string} stepName - Optional step name for per-step screenshots
   * @param {Function} attachFn - Cucumber attach function
   * @returns {Promise<void>}
   */
  async captureScreenshot(page, scenarioName, line, status, stepName = null, attachFn = null) {
    if (!page) {
      console.warn('Page object is null, skipping screenshot');
      return;
    }

    const captureMode = process.env.CAPTURE_SCREENSHOT_ON || 'failed';
    
    // Determine if screenshot should be captured
    const shouldCapture = 
      captureMode === 'all' || 
      (captureMode === 'failed' && status === 'failed') ||
      (captureMode === 'passed' && status === 'passed');

    if (!shouldCapture && captureMode !== 'none') {
      return;
    }

    if (captureMode === 'none') {
      return;
    }

    try {
      // Ensure screenshot directory exists
      await this.ensureDirectoryExists(this.screenshotDir);

      // Generate filename
      const safeScenarioName = this.sanitizeFileName(scenarioName);
      let filename;
      
      if (stepName) {
        const safeStepName = this.sanitizeFileName(stepName);
        filename = `${safeScenarioName}_step${this.stepCounter}_${safeStepName}(${line}).png`;
      } else {
        filename = `${safeScenarioName}(${line}).png`;
      }

      const screenshotPath = path.join(this.screenshotDir, filename);

      // Capture screenshot
      const image = await page.screenshot({ 
        path: screenshotPath, 
        fullPage: true 
      });

      // Attach to Cucumber report if attach function provided
     if (attachFn) {
    await attachFn(image, {
        mediaType: "image/png"
    });
}

      console.log(`Screenshot captured: ${filename}`);
    } catch (error) {
      console.error(`Failed to capture screenshot: ${error.message}`);
    }
  }

  /**
   * Capture screenshot after each step
   * @param {Page} page - Playwright page object
   * @param {string} scenarioName - Scenario name
   * @param {number} line - Scenario line number
   * @param {string} stepText - Step text
   * @param {string} status - Step status
   * @param {Function} attachFn - Cucumber attach function
   * @returns {Promise<void>}
   */
  async captureStepScreenshot(page, scenarioName, line, stepText, status, attachFn = null) {
    const capturePerStep = process.env.SCREENSHOT_PER_STEP === 'true';
    
    if (!capturePerStep) {
      return;
    }

    this.stepCounter++;
    await this.captureScreenshot(page, scenarioName, line, status, stepText, attachFn);
  }

  /**
   * Reset step counter for new scenario
   */
  resetStepCounter() {
    this.stepCounter = 0;
  }

  /**
   * Sanitize filename to remove invalid characters
   * @param {string} name - Original name
   * @returns {string} - Sanitized name
   */
  sanitizeFileName(name) {
    return name.replace(/[<>:"/\\|?*]/g, '_').substring(0, 100);
  }

  /**
   * Ensure directory exists, create if not
   * @param {string} dirPath - Directory path
   * @returns {Promise<void>}
   */
  async ensureDirectoryExists(dirPath) {
    try {
      await fs.access(dirPath);
    } catch {
      await fs.mkdir(dirPath, { recursive: true });
    }
  }
}

export { ScreenshotHelper };
