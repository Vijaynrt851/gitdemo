import { When, Then, Given } from '@cucumber/cucumber';
//import { POManager } from '../../pageobjects/POManager.js';
import { expect } from '@playwright/test';

When('I scroll to the FAQ section', async function () {
    await this.poManager.getFaqPage().scrollToFaqSection();
});

Then('I verify the FAQ section first accordion is expanded by default', async function () {
    await this.poManager.getFaqPage().verifyFirstAccordionExpandedByDefault();
});

When('I expand any other accordion', async function () {
    await this.poManager.getFaqPage().expandOtherAccordion();
});

Then('the other gets collapsed immediately', async function () {
    await this.poManager.getFaqPage().verifyOtherAccordionCollapsed();
});
