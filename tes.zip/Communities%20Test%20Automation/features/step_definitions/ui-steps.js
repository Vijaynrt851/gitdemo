import { When, Then, Given } from '@cucumber/cucumber';
//import { POManager } from '../../pageobjects/POManager.js';
import { expect } from '@playwright/test';
import fs from 'fs';

const WCAG_TAGS = {
    'wcag2a': ['wcag2a'],
    'wcag2aa': ['wcag2aa'],
    'wcag21a': ['wcag21a'],
    'wcag21aa': ['wcag21aa']
};

Given('I have launched the {string}', async function (url) {
    const commonPageObjects = this.poManager.getCommonPageObjects();
    await commonPageObjects.launchUrl(url);
});

When('I click on {string} category', async function (category) {
    //const demoPage = this.poManager.getDemoQAPage();
    //await demoPage.clickOnCategory(category);
    console.log(`Clicked on category: ${category}`);
});

When('I enter text {string} in the text Box', async function (text) {
    const demoQAElementPage = this.poManager.getDemoQAElementPage();
    await demoQAElementPage.enterTextInTextBox(text);
});

When('I check the checkbox', async function () {
    const demoQAElementPage = this.poManager.getDemoQAElementPage();
    await demoQAElementPage.checkBox();
});

When('I click on radio button', async function () {
    const demoQAElementPage = this.poManager.getDemoQAElementPage();
    await demoQAElementPage.radioButton();
});

When('I double click on button', async function () {
    const demoQAElementPage = this.poManager.getDemoQAElementPage();
    await demoQAElementPage.doubleClickButton();
});

Then('I verify the {string} is displayed', async function (message) {
    const demoQAElementPage = this.poManager.getDemoQAElementPage();
    await demoQAElementPage.verifyDoubleClickMessage(message);
});

/**
 * Cucumber step to test accessibility for different WCAG tags.
 */
Then('the page should have no {string} accessibility violations', async function (wcagTag) {
    if (!WCAG_TAGS[wcagTag]) {
        throw new Error(`🚨 Invalid WCAG tag provided: ${wcagTag}`);
    }

    const reportPath = await this.accessibilityHelper.checkWCAG(this.page, `${wcagTag}_test`, WCAG_TAGS[wcagTag]);

    if (reportPath) {
        this.attach(fs.readFileSync(reportPath, 'utf8'), 'application/json');
    }
});
