import { Then } from '@cucumber/cucumber';

Then('verify the Hero component is displayed successfully', async function () {
    await this.poManager.getHomePage().verifyHeroComponentDisplayed();
});

Then('verify the Video component is displayed successfully', async function () {
    await this.poManager.getHomePage().verifyVideoComponentDisplayed();
});

Then('verify the video carousel is displayed successfully', async function () {
    await this.poManager.getHomePage().verifyVideoCarouselDisplayed();
});

Then('verify the video carousel is functional', async function () {
    await this.poManager.getHomePage().verifyVideoCarouselFunctional();
});

Then('verify the video player is functional', async function () {
    await this.poManager.getHomePage().verifyVideoPlayerFunctional();
});
