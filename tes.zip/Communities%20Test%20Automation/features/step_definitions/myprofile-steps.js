import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

When('I click on profile icon', async function () {
    await this.poManager.getMyProfilePage().clickOnProfileIcon();
});

Then('I verify the my profile page is displayed successfully', async function () {
    await this.poManager.getMyProfilePage().verifyMyProfilePageDisplayed();
});

Then('I verify my details are displayed correctly', async function () {
    await this.poManager.getMyProfilePage().verifyMyDetailsDisplayed();
});

When('I click on the edit button', async function () {
    await this.poManager.getMyProfilePage().clickOnEditButton();
});

Then('I verify the edit profile page is displayed successfully', async function () {
    await this.poManager.getMyProfilePage().verifyEditProfilePageDisplayed();
});