import { When, Then } from '@cucumber/cucumber';
//import { APiUtils } from '../../utils/APiUtils.js';

When('I request {string} post call', async function (scenarioType) {
    await this.apiUtils.postCall(scenarioType);
});

When('I request {string} get call', async function (scenarioType) {
    await this.apiUtils.getCall(scenarioType);
});

When('I request {string} delete call', async function (scenarioType) {
    await this.apiUtils.deleteCall(scenarioType);
});

Then('I validate response status code as {string}', async function (responseStatusCode) {
    await this.apiUtils.validateResponseStatusCode(responseStatusCode);
});

When('I validate {string} field data as {string}', async function (path, value) {
    await this.apiUtils.validateData(path, value);
});

When('I request {string} put call', async function (scenarioType) {
    await this.apiUtils.putCall(scenarioType);
});
