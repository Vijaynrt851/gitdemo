import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Given('I have previously saved my personal details in My Account', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    const testData = this.testDataUtils.getQNSMyAccountData();
    
    await myAccountPage.openMyAccount();
    await myAccountPage.verifyMyAccountPageDisplayed();
    const savedData = await myAccountPage.ensurePersonalDetailsExist(testData.noiseComplaintSubmission);
    this.savedAddressLine1 = savedData.addressLine1;
    this.savedAddressLine2 = savedData.addressLine2;
    this.savedPostcode = savedData.postcode;
});

Then('the consent checkbox should not be displayed', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifySaveContactCheckboxNotDisplayed();
});

When('I fill the address line 1 and postcode fields if it is empty', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.fillAddressLine1IfEmpty();
    await qnsFormPage.fillPostcodeIfEmpty();
});

Then('the confirmation page is displayed', async function () {
    const confirmationPage = this.poManager.getConfirmationPage();
    await confirmationPage.verifyConfirmationPageDisplayed();
});

Then('the confirmation page should include a {string} button', async function (buttonText) {
    const confirmationPage = this.poManager.getConfirmationPage();
    await confirmationPage.verifySubmitNewQueryButtonDisplayed();
});

When('I click the {string} button to go to noise complaint form', async function (buttonText) {
    const confirmationPage = this.poManager.getConfirmationPage();
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    
    await confirmationPage.clickSubmitNewQuery();
    await qnsFormPage.navigateToForm();
});

Then('I should be able to refill all required disturbance fields', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSSubmitNewQueryData();
    
    await qnsFormPage.fillDisturbanceDate(testData.secondSubmission.date);
    await qnsFormPage.fillDisturbanceTime(testData.secondSubmission.time);
    await qnsFormPage.selectDisturbanceType(testData.secondSubmission.type);
    await qnsFormPage.fillDisturbanceDetails(testData.secondSubmission.details);
});
