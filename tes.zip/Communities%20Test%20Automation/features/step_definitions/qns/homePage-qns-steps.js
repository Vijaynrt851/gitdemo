import { When, Then, Given } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

When ('I see the following Key Policies and Processes components',async function (dataTable) {
    const HomePageQns = this.poManager.getHomePageQns();
    const components = dataTable.hashes();
    for (const component of components) {
        await HomePageQns.verifyKeyPoliciesComponentDisplayed(component['Component Type'],component['Component Name']);
    }
});

Then('I should expand, view content, and collapse the following accordions', async function (dataTable) {
    const HomePageQns = this.poManager.getHomePageQns();
    const accordions = dataTable.raw().slice(1);
    for (const [accordionName] of accordions) {
        await HomePageQns.verifyKeyPoliciesAccordionExpandCollapse(accordionName);
    }
});

Then('I should be able to navigate through external links from {string}',async function (accordionName, dataTable) {
    const HomePageQns = this.poManager.getHomePageQns();
    const testData = this.testDataUtils.getQNSHomePageData();
    const rows = dataTable.hashes();
    for (const row of rows) {
        await HomePageQns.clickKeyPoliciesAccordionHeader(row['Accordion Header']);
        const newPage = await HomePageQns.clickKeyPoliciesExternalLink(row['Link Name']);
        const expectedUrl = await this.testDataUtils.getData(testData.keyPoliciesAndProcesses.externalLinks[row['Url Key']]);
        await HomePageQns.verifyExternalTabOpened(newPage, expectedUrl);
        const homePageUrl = await this.testDataUtils.getData('homePage');
        await this.page.goto(homePageUrl,{waitUntil: 'domcontentloaded'});
    }
});


