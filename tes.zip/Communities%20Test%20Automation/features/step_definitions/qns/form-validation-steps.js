import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

/**
 * QNS Form Validation - Story 752892
 * Step Definitions for validating form completeness before submission
 */

// Navigation Steps
Given('user click on the {string} link on the navigation bar', async function (linkText) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.clickNavigationLink(linkText);
});

Given('I navigate to {string}', async function (pageKey) {
    const qnsUrl = await this.testDataUtils.getData(pageKey);
    await this.page.goto(qnsUrl, { waitUntil: 'domcontentloaded' });
});

When ('I navigate back to {string}', async function (pageKey) {
    const qnsUrl = await this.testDataUtils.getData(pageKey);
    await this.page.goto(qnsUrl, { waitUntil: 'domcontentloaded' });
});

Given('I navigate to the noise complaint form', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.navigateToForm();
});

Given('I am logged in to the QNS application', async function () {
    const loginPage = this.poManager.getLoginPage();
    await loginPage.enterUsernameAndPassword();
    await loginPage.clickLoginButton();
    await this.page.waitForTimeout(3000); // Wait for login to complete
});

Given('I go to the noise complaint form', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.goToNoiseComplaintForm();
});

// Form Submission Steps
When('I attempt to submit the form without filling any fields', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.clearAllFormFields();
    await qnsFormPage.submitForm();
});

When('I attempt to submit the form', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.submitForm();
});

When('I submit the form', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.submitForm();
});

When('I leave the {string} field empty', async function (fieldName) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSValidationData();
    
    // Fill all fields except the specified one
    if (fieldName !== 'date of disturbance') {
        await qnsFormPage.fillDisturbanceDate(testData.valid.date);
    }
    if (fieldName !== 'disturbance time') {
        await qnsFormPage.fillDisturbanceTime(testData.valid.time);
    }
    if (fieldName !== 'disturbance type') {
        await qnsFormPage.selectDisturbanceType(testData.valid.type);
    }
    if (fieldName !== 'disturbance details') {
        await qnsFormPage.fillDisturbanceDetails(testData.valid.details);
    }
});

When('I fill only disturbance information fields', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSValidationData();
    
    await qnsFormPage.fillDisturbanceDate(testData.valid.date);
    await qnsFormPage.fillDisturbanceTime(testData.valid.time);
    await qnsFormPage.selectDisturbanceType(testData.valid.type);
    await qnsFormPage.fillDisturbanceDetails(testData.valid.details);
});

When('I leave all personal detail fields empty', async function () {
    // In QNS, personal details are pre-populated from user profile
    // This step is informational - no action needed
    console.log('Personal details are pre-populated from logged-in user profile');
});

When('I fill only personal detail fields', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    // Verify pre-populated address fields
    await qnsFormPage.verifyAddressFields();
});

When('I leave all disturbance information fields empty', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.clearAllFormFields();
});

When('I fill all required personal detail fields', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    // Personal details are auto-populated - just verify
    await qnsFormPage.verifyAddressFields();
});

When('I fill all required disturbance information fields', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSValidationData();
    
    await qnsFormPage.fillDisturbanceDate(testData.valid.date);
    await qnsFormPage.fillDisturbanceTime(testData.valid.time);
    await qnsFormPage.selectDisturbanceType(testData.valid.type);
    await qnsFormPage.fillDisturbanceDetails(testData.valid.details);
});

// Verification Steps
Then('the system must prevent form submission', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyFormNotSubmitted();
});

Then('I should see validation errors for all required fields', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyAllRequiredFieldErrors();
});

Then('all validation messages should be displayed in red', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyAllErrorsAreRed();
});

Then('I should see a validation error for {string} in red', async function (fieldName) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyValidationErrorFor(fieldName);
    await qnsFormPage.verifyErrorIsRed(fieldName);
});

Then('the validation message should identify the missing field clearly', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    // Error summary already provides clear field identification
    await expect(qnsFormPage.errorSummary).toBeVisible();
});

Then('I should see validation errors for personal detail fields in red', async function () {
    // In QNS, personal details are pre-populated, no validation errors expected
    console.log('Personal details are pre-populated - no validation errors for these fields');
});

Then('I should see validation errors for disturbance information fields in red', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyAllRequiredFieldErrors();
    await qnsFormPage.verifyAllErrorsAreRed();
});

Then('the form should submit successfully', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyFormSubmitted();
});

Then('no validation errors should be displayed', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyNoValidationErrors();
});

// ========== Story 752889: Date and Time Capture Steps ==========

When('I verify the date field is an HTML5 date input', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyDateFieldIsDateInput();
});

When('I select date {string} using the date picker', async function (date) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.fillDisturbanceDate(date);
});

Then('the selected date should be captured in the date field', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const dateValue = await qnsFormPage.getDateFieldValue();
    expect(dateValue).not.toBe('');
    expect(dateValue).toBe('2026-08-25');
});

When('I verify the time dropdown has 15-minute increment options', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyTimeOptionsAre15MinuteIncrements();
});

When('I verify all time options are in 24-hour format', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyTimeOptionsAre24HourFormat();
});

When('I select time {string} from the time dropdown', async function (time) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.fillDisturbanceTime(time);
});

Then('the selected time should be captured in the time field', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const timeValue = await qnsFormPage.getTimeFieldValue();
    expect(timeValue).not.toBe('');
    expect(timeValue).toBe('23:45');
});

// ========== Story 752890: Disturbance Type and Details Steps ==========

When('I open the disturbance type dropdown', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.openDisturbanceTypeDropdown();
});

Then('the dropdown should contain all expected disturbance types', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSValidationData();
    const expectedOptions = testData.disturbanceTypes;
    await qnsFormPage.verifyDisturbanceTypeOptions(expectedOptions);
});

When('I enter disturbance details from test data', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSValidationData();
    const details = testData.noiseComplaint.disturbanceDetails;
    await qnsFormPage.fillDisturbanceDetails(details);
});

Then('the disturbance details field should contain the entered text', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSValidationData();
    const expectedDetails = testData.noiseComplaint.disturbanceDetails;
    const actualDetails = await qnsFormPage.getDisturbanceDetailsValue();
    expect(actualDetails).toBe(expectedDetails);
});

// ========== Story 752893: Email Copy Checkbox Steps ==========

Then('the email copy checkbox should be visible', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyEmailCopyCheckboxVisible();
});

Then('the email copy checkbox should be unchecked by default', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyEmailCopyCheckboxUnchecked();
});

When('I select the email copy checkbox', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.toggleEmailCopy(true);
});

When('I unselect the email copy checkbox', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.toggleEmailCopy(false);
});

Then('the email copy checkbox should be checked', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyEmailCopyCheckboxChecked();
});

Then('the email copy checkbox should be unchecked', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.verifyEmailCopyCheckboxUnchecked();
});
