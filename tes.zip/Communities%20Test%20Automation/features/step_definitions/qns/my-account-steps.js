import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

When('I open My Account', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.openMyAccount();
});


Then('I should see my {string} on the account page', async function (fieldName) {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.verifyFieldIsVisible(fieldName);
});

Then('I should see the following optional fields if supplied', async function (dataTable) {
    const myAccountPage = this.poManager.getMyAccountPage();
    const fields = dataTable.raw().slice(1);
    for (const [fieldName] of fields) {
        await myAccountPage.verifyFieldIfSupplied(fieldName);
    }
});

When('I fill {string}, {string} and {string} fields', async function (field1, field2, field3) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSMyAccountData();
    
    this.submittedAddressLine1 = testData.noiseComplaintSubmission.addressLine1;
    this.submittedAddressLine2 = testData.noiseComplaintSubmission.addressLine2;
    this.submittedPostcode = testData.noiseComplaintSubmission.postcode;
    
    const isAddressLine1Readonly = await qnsFormPage.isAddressLine1NonEditable().catch(() => false);
    const isAddressLine2Readonly = await qnsFormPage.isAddressLine2NonEditable().catch(() => false);
    const isPostcodeReadonly = await qnsFormPage.isPostcodeNonEditable().catch(() => false);
    
    if (!isAddressLine1Readonly && !isAddressLine2Readonly && !isPostcodeReadonly) {
        await qnsFormPage.fillAddressLine1(this.submittedAddressLine1).catch(() => {});
        await qnsFormPage.fillAddressLine2(this.submittedAddressLine2).catch(() => {});
        await qnsFormPage.fillPostcode(this.submittedPostcode).catch(() => {});
    }
});

When('I check the checkbox to save my personal details', async function () {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    await qnsFormPage.checkSaveContactInformation();
});

Then('the {string}, {string} and {string} fields should be displayed in My Account as I entered when submitting form', async function (field1, field2, field3) {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.clickEditButton();
    const addressLine1Value = await myAccountPage.getFieldValue('address line 1 myacc');
    const addressLine2Value = await myAccountPage.getFieldValue('address line 2 myacc');
    const postcodeValue = await myAccountPage.getFieldValue('postcode myacc');
    
    expect(addressLine1Value).toContain(this.submittedAddressLine1);
    expect(addressLine2Value).toContain(this.submittedAddressLine2);
    expect(postcodeValue).toBe(this.submittedPostcode);
    await myAccountPage.clickSaveChanges();
});

When('I fill {string}, {string} and {string} fields without checking save option', async function (field1, field2, field3) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const testData = this.testDataUtils.getQNSMyAccountData();
    
    this.submittedAddressLine1 = testData.noiseComplaintSubmission.addressLine1;
    this.submittedAddressLine2 = testData.noiseComplaintSubmission.addressLine2;
    this.submittedPostcode = testData.noiseComplaintSubmission.postcode;
    
    const isAddressLine1Readonly = await qnsFormPage.isAddressLine1NonEditable().catch(() => false);
    const isAddressLine2Readonly = await qnsFormPage.isAddressLine2NonEditable().catch(() => false);
    const isPostcodeReadonly = await qnsFormPage.isPostcodeNonEditable().catch(() => false);
    
    if (!isAddressLine1Readonly && !isAddressLine2Readonly && !isPostcodeReadonly) {
        await qnsFormPage.fillAddressLine1(this.submittedAddressLine1).catch(() => {});
        await qnsFormPage.fillAddressLine2(this.submittedAddressLine2).catch(() => {});
        await qnsFormPage.fillPostcode(this.submittedPostcode).catch(() => {});
    }
});

Then('the {string}, {string} and {string} fields should be displayed empty in My Account', async function (field1, field2, field3s) {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.clickEditButton();
    const addressLine1Value = await myAccountPage.getFieldValue('address line 1 myacc');
    const addressLine2Value = await myAccountPage.getFieldValue('address line 2 myacc');
    const postcodeValue = await myAccountPage.getFieldValue('postcode myacc');
    
    expect(addressLine1Value || '').toBe('');
    expect(addressLine2Value || '').toBe('');
    expect(postcodeValue || '').toBe('');
    await myAccountPage.clickSaveChanges();
});

Then('the {string}, {string} and {string} fields should be displayed empty in noise complaint form', async function (field1, field2, field3) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const addressLine1Value = await qnsFormPage.getAddressLine1Value();
    const addressLine2Value = await qnsFormPage.getAddressLine2Value();
    const postcodeValue = await qnsFormPage.getPostcodeValue();
    
    expect(addressLine1Value || '').toBe('');
    expect(addressLine2Value || '').toBe('');
    expect(postcodeValue || '').toBe('');
});

Then('I clear {string}, {string} and {string} fields if it is not empty', async function (field1, field2, field3) {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.clickEditButton();
    await myAccountPage.clearFieldIfNotEmpty('addressLine1MyAcc');
    await myAccountPage.clearFieldIfNotEmpty('addressLine2MyAcc');
    await myAccountPage.clearFieldIfNotEmpty('postcodeMyAcc');
    await myAccountPage.clickSaveChanges();
});

When('I click on Edit button', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.clickEditButton();
});

When('I clear all editable fields in My Account', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.clearAllEditableFields();
});

When('I attempt to save My Account', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.clickSaveChanges();
});

Then('system should display error to restrict saving personal details', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.verifySaveButtonDisabledOrValidationDisplayed();
});

Then('all pre-populated fields {string}, {string} and {string} should be non-editable', async function (field1, field2, field3) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    const fields = [field1, field2, field3];
    await qnsFormPage.verifyAllPrePopulatedFieldsNonEditable(fields);
});

When('I enter only mandatory fields in My Account', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    const testData = this.testDataUtils.getQNSMyAccountData();
    
    this.savedMandatoryData = testData.mandatoryFieldsData;
    await myAccountPage.fillMandatoryFieldsOnly(this.savedMandatoryData);
});

When('I save My Account changes', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.clickSaveChanges();
    await this.page.waitForLoadState('load');
});

Then('mandatory fields should be saved successfully', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.verifyMandatoryFieldsSaved(this.savedMandatoryData);
});

When('I enter all personal details in My Account', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    const testData = this.testDataUtils.getQNSMyAccountData();
    
    this.savedCompleteData = testData.completePersonalDetails;
    await myAccountPage.fillCompletePersonalDetails(this.savedCompleteData);
});

Then('all personal details should be saved successfully', async function () {
    const myAccountPage = this.poManager.getMyAccountPage();
    await myAccountPage.verifyAllPersonalDetailsSaved(this.savedCompleteData);
});

Then('the {string}, {string} and {string} fields should be pre-populated with my saved details', async function (field1, field2, field3) {
    const qnsFormPage = this.poManager.getNoiseComplaintFormPage();
    
    if (this.savedCompleteData) {
        const addressLine1Value = await qnsFormPage.getAddressLine1Value();
        const addressLine2Value = await qnsFormPage.getAddressLine2Value();
        const postcodeValue = await qnsFormPage.getPostcodeValue();
        
        if (addressLine1Value && addressLine1Value.trim() !== '') {
            expect(addressLine1Value).toContain(this.savedCompleteData.addressLine1);
        } else {
            expect(addressLine1Value).toContain(this.savedCompleteData.addressLine1);
        }
        
        if (addressLine2Value && addressLine2Value.trim() !== '') {
            expect(addressLine2Value).toContain(this.savedCompleteData.addressLine2);
        } else {
            expect(addressLine2Value).toContain(this.savedCompleteData.addressLine2);
        }
        
        if (postcodeValue && postcodeValue.trim() !== '') {
            expect(postcodeValue).toBe(this.savedCompleteData.postcode);
        } else {
            expect(postcodeValue).toBe(this.savedCompleteData.postcode);
        }
    }
});
