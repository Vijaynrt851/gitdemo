import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

When('I click on the submit button without entering any data', async function () {
    await this.poManager.getSubmitQueryPage().clickSubmitButtonWithoutData();
});

Then('I verify the error message is displayed for all required fields', async function () {
    await this.poManager.getSubmitQueryPage().verifyErrorMessagesForAllRequiredFields();
});

When('I enter all the required fields and click on submit button', async function () {
    await this.poManager.getSubmitQueryPage().enterAllRequiredFieldsAndSubmit();
});

Then('I verify the success message is displayed after submitting the query', async function () {
    await this.poManager.getSubmitQueryPage().verifySuccessMessageDisplayed();
});

Then('I sort the case list by date', async function () {
    await this.poManager.getSubmitQueryPage().sortCaseListByDate();
});

Then('I click on the first case in the list', async function () {
    await this.poManager.getSubmitQueryPage().clickOnFirstCaseInList();
});

Then('I verify the case details are displayed successfully', async function () {
    await this.poManager.getSubmitQueryPage().verifyCaseDetailsDisplayed();
});

When('I enter a comment and click on submit button', async function () {
    await this.poManager.getSubmitQueryPage().enterCommentAndClickSubmit();
});

Then('I verify the comment is added successfully to the case', async function () {
    await this.poManager.getSubmitQueryPage().verifyCommentAddedSuccessfully();
});
