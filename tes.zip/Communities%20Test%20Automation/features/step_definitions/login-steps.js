import { When, Then, Before } from '@cucumber/cucumber';
//import { POManager } from '../../pageobjects/POManager.js';
import { expect } from '@playwright/test';

Then('verify the title', async function () {
    const title = await this.page.title();
    console.log(`Page title is: ${title}`);
    expect(title).toBe('Login');
});

Then('I enter the username and password', async function () {
    await this.poManager.getLoginPage().enterUsernameAndPassword();
});

Then('I click on the login button', async function () {
    await this.poManager.getLoginPage().clickLoginButton();
});

Then('I verify the user is logged in successfully', async function () {
    await this.poManager.getLoginPage().verifySuccessfulLogin();
});

When('I click on the need help link', async function () {
    await this.poManager.getLoginPage().clickOnLink('needHelpLink');
});

Then('I verify the case list section is displayed successfully', async function () {
    await this.poManager.getLoginPage().verifyCaseListPageDisplayed();
});

Then('I verify the submit query section is displayed successfully', async function () {
    await this.poManager.getLoginPage().verifySubmitQueryPageDisplayed();
});

Then('I verify the complaints section is displayed successfully', async function () {
    await this.poManager.getLoginPage().verifyComplaintsPageDisplayed();
});

Then('I click on the {string} link', async function (linkName) {
    await this.poManager.getLoginPage().clickOnLink(linkName);
});

Then('I verify the common question section is displayed successfully', async function () {
    await this.poManager.getLoginPage().verifyCommonQuestionsSectionDisplayed();
});
