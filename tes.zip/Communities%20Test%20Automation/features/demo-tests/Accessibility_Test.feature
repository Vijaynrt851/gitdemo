@accessibility
Feature: Accessibility Testing

  Scenario Outline: Verify WCAG 2.0 A, WCAG 2.0 AA, WCAG 2.1 A and WCAG 2.1 AA compliance
    Given I have launched the "demoUrl"
    When I click on "elements" catagory
    When I enter text "Good Morning" in the text Box
    When I check the checkbox
    When I double click on button
    Then the page should have no "<WCAG_Tags>" accessibility violations
    Examples:
        | WCAG_Tags | 
        | wcag2a  |
        | wcag2aa |
        | wcag21a |
        | wcag21aa |