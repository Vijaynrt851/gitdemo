@ApiRegression @Regression
Feature: Post API sample test feature

  @PostAPITest
  Scenario: API sample test for post call
    When I request "createUser" post call
    Then I validate response status code as "201"
    Then I validate "$.name" field data as "morpheus"


    


 