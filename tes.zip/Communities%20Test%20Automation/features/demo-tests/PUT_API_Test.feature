@ApiRegression @Regression
Feature: PUT API sample test feature

  @PutAPITest
  Scenario: API sample test for put call
    When I request "updateUser" put call
    Then I validate response status code as "200"
    Then I validate "$.name" field data as "morpheus"