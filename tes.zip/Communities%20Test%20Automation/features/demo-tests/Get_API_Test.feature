@ApiRegression @Regression
Feature: Get API sample test feature

  @GetAPITest
  Scenario: API sample test for get call
    When I request "getUser" get call
    Then I validate response status code as "200"
    Then I validate "$..id" field data as "2"