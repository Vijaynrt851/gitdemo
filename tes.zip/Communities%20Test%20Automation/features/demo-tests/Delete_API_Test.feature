@ApiRegression @Regression
Feature: Delete API sample test feature

  @DeleteAPITest
  Scenario: API sample test for delete call
    When I request "deleteUser" delete call
    Then I validate response status code as "204"

    


 