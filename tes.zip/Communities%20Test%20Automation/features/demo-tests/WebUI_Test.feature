@demoTestU
Feature: WEB UI QA test

  Scenario: Web test for demoQA A
    Given I have launched the "demoUrl"
    Then verify the title

  Scenario: Web test for demoQA B
  Given I have launched the "demoUrl"
    When I click on "elements" category
    Then verify the title
    #Then close the browser

  Scenario: Web test for new page B
    Given I have launched the "flightUrl"
    Then verify the title
    #Then close the browser

    #When I click on "elements" catagory
    #When I enter text "Good Morning" in the text Box
    #When I check the checkbox
    #When I double click on button
    #Then I verify the "You have done a double click" is displayed


