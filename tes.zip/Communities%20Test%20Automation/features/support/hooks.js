import { APiUtils } from '../../utils/APiUtils.js';
import { POManager } from '../../pageobjects/POManager.js';
import { BrowserUtils } from '../../utils/BrowserUtils.js';
import { TestDataUtils } from '../../utils/TestDataUtils.js';
import {BeforeAll, Before, After, BeforeStep, AfterStep, AfterAll, Status, setDefaultTimeout, formatterHelpers } from '@cucumber/cucumber';
import { AccessibilityHelper } from '../../utils/AccessibilityHelper.js';
import { ScreenshotHelper } from '../../utils/ScreenshotHelper.js';
import { VideoHelper } from '../../utils/VideoHelper.js';
import fs from 'fs/promises';
import path from 'path';
import { devices } from "@playwright/test";
import os from 'os';
import { threadId, isMainThread } from "node:worker_threads";
import dotenv from 'dotenv';

const browserUtils = new BrowserUtils();
const screenshotHelper = new ScreenshotHelper();
const videoHelper = new VideoHelper();


setDefaultTimeout(60000);

BeforeAll(async function () {
    dotenv.config();
    console.log("Executing @BeforeAll_Hook");
    console.log(`BeforeAll - PID: ${process.pid}`);
    console.log({
    pid: process.pid,
    threadId,
    isMainThread
});
    await browserUtils.getBrowser();

if (process.env.CUCUMBER_WORKER_ID === "0") {
    const reportsDir = path.resolve("report-data");
    const executionInfoPath = path.join(reportsDir, "execution-info.json");

    await fs.mkdir(reportsDir, { recursive: true });

    // Delete previous execution info if present
    try {
        await fs.unlink(executionInfoPath);
        console.log("Previous execution-info.json deleted.");
    } catch {
        console.log("No previous execution-info.json found, proceeding to create a new one.");
    }

    const executionInfo = {
        // Project
        projectName: process.env.PROJECT_NAME || "Heathrow Playwright Cucumber",
        framework: "Playwright + Cucumber",
        language: "JavaScript",

        // Execution
        environment: process.env.NODE_ENV || "QA",
        browser: process.env.BROWSER || "chromium",
        browserChannel: process.env.BROWSER_CHANNEL || "",
        browserVersion: "",
        headless: process.env.HEADLESS === "true",
        parallelThreads: Number(process.env.PARALLEL_THREAD || 1),
        retryCount: Number(process.env.RETRY_COUNT || 0),

        // System
        nodeVersion: process.version,
        platform: os.platform(),
        operatingSystem: os.type(),
        osVersion: os.release(),
        architecture: os.arch(),
        cpuCount: os.cpus().length,
        hostname: os.hostname(),
        username: os.userInfo().username,

        // CI (optional)
        ci: process.env.CI === "true",
        ciProvider: process.env.CI_PROVIDER || "",
        gitBranch: process.env.GIT_BRANCH || "",
        gitCommit: process.env.GIT_COMMIT || "",

        // Build Information
        release: process.env.RELEASE || "1.0.0",
        cycle: process.env.CYCLE || "N/A"
    };

    await fs.writeFile(
        executionInfoPath,
        JSON.stringify(executionInfo, null, 2),
        "utf8"
    );

    console.log("Execution context created.");
}
});

Before({ timeout: 20000 }, async function () {
    console.log("Executing @Before_Scenario_Hook");

    // Reset screenshot counter for new scenario
    screenshotHelper.resetStepCounter();

    this.browser = await browserUtils.getBrowser();

    console.log(`Browser instance obtained. PID=${process.pid}`);

    const browserType = (process.env.BROWSER || "chromium").toLowerCase();

    const contextOptions = {
        ignoreHTTPSErrors: true,
        acceptDownloads: true,
        recordVideo: process.env.RECORD_VIDEO === "true"
            ? { dir: "./test-results/videos" }
            : undefined
    };

    //console.log(`Available devices: ${Object.keys(devices).join(", ")}`);

    switch (browserType) {

        case "mobile-chrome":
            this.context = await this.browser.newContext({
                ...devices["Pixel 7"],
                ...contextOptions
            });
            break;

        case "mobile-webkit":
            this.context = await this.browser.newContext({
                ...devices["iPhone 15"],
                ...contextOptions
            });
            break;

        case "tablet-ipad-webkit":
            this.context = await this.browser.newContext({
                ...devices["iPad Pro 11"],
                ...contextOptions
            });
            break;

        case "Galaxy-Tab-chrome":
            this.context = await this.browser.newContext({
                ...devices["Galaxy Tab S9"],
                ...contextOptions
            });
            break;

        default:
            this.context = await this.browser.newContext({
                viewport: {
                    width: 1280,
                    height: 1080
                },
                ...contextOptions
            });
    }

    console.log(`Browser context created. PID=${process.pid}`);

    this.page = await this.context.newPage();

    this.poManager = new POManager(this.page);
    this.testDataUtils = new TestDataUtils();

    console.log(`Page Object Manager initialized. PID=${process.pid}`);
});

/* 14 July - Removing the current implementation to handle mobile devices,
Before({ timeout: 20000 }, async function () {
    console.log("Executing @Before_Scenario_Hook");
    
    // Reset screenshot counter for new scenario
    screenshotHelper.resetStepCounter();
    this.browser = await browserUtils.getBrowser();
    console.log(`Browser instance obtained for PID: ${process.pid}`);



    this.context = await this.browser.newContext({
        viewport: {
            width: 1280,
            height: 1080
        },
        ignoreHTTPSErrors: true,
        acceptDownloads: true,
        recordVideo: process.env.RECORD_VIDEO === "true" ? { dir: './test-results/videos' } : undefined
    });
    console.log(`Browser instance obtained for PID: context ${process.pid}`);
    this.page = await this.context.newPage();
    this.poManager = new POManager(this.page);
console.log(`Browser instance obtained for PID: poManager ${process.pid}`);
});
*/

BeforeStep(function (scenario) {
    console.log(`Executing @BeforeStep_Hook for scenario: ${scenario.pickle.name}`);
    this.apiUtils = new APiUtils();
    this.accessibilityHelper = new AccessibilityHelper();
    this.testName = scenario.pickle.name.replace(/\s+/g, '_');
});

After(async function ({ result, pickle, gherkinDocument }) {
    const { line } = formatterHelpers.PickleParser.getPickleLocation({ gherkinDocument, pickle });
    const status = result.status === Status.PASSED ? 'passed' : 'failed';
    const scenario = pickle.name;
    
    // CRITICAL: Get video reference BEFORE closing context
    const video = this.page?.video();

    try {
        // Capture scenario-level screenshot using ScreenshotHelper
        await screenshotHelper.captureScreenshot(
            this.page,
            scenario,
            line,
            status,
            null,
            this.attach.bind(this)
        );

        if (status === 'failed') {
            console.log(`${scenario}: ${line} - FAILED\n${result.message}`);
        }

        console.log(`${scenario}: ${line} - ${status.toUpperCase()}`);
    } catch (error) {
        console.error(`Error capturing screenshot: ${error.message}`);
    } finally {
        // Close context first (this finalizes the video)
        if (this.context) {
            await this.context.close();
        }

        // Handle video AFTER context close (Playwright best practice)
        if (video) {
            await videoHelper.handleVideo(
                video,
                scenario,
                line,
                status,
                this
            );
        }
    }
});

AfterStep(async function ({ result, pickle, gherkinDocument }) {
    console.log("Executing @AfterStep_Hook");

    if (!this.page) {
        return;
    }

    const stepStatus =
        result.status === Status.PASSED ? "passed" : "failed";

    if (
        process.env.SCREENSHOT_PER_STEP !== "true" &&
        stepStatus !== "failed"
    ) {
        return;
    }

    const { line } =
        formatterHelpers.PickleParser.getPickleLocation({
            gherkinDocument,
            pickle
        });

    const stepText =
        pickle.steps[screenshotHelper.stepCounter]?.text ??
        `step_${screenshotHelper.stepCounter}`;

    try {
        await screenshotHelper.captureStepScreenshot(
            this.page,
            pickle.name,
            line,
            stepText,
            stepStatus,
            this.attach.bind(this)
        );
    } catch (error) {
        console.error(`Step screenshot failed: ${error.message}`);
    }
});

AfterAll(async function () {
    console.log("Executing @AfterAll_Hook");
// Close browser
console.log(`AfterAll - PID: ${process.pid}`);
console.log({
    pid: process.pid,
    threadId,
    isMainThread
});
browserUtils.closeBrowser();
console.log(`Browser closed successfully PID: ${process.pid}`);

});