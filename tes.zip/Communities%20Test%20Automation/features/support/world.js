import { World, setWorldConstructor } from '@cucumber/cucumber';

class CustomWorld extends World {
  constructor(options) {
    super(options);
    
    this.browser = null;
    this.context = null;
    this.page = null;
    this.poManager = null;
    this.apiContext = null;
    this.apiUtils = null;
    this.accessibilityHelper = null;
    this.testName = null;
    console.log("CustomWorld initialized with options:");
  }
}

setWorldConstructor(CustomWorld);

export { CustomWorld };
