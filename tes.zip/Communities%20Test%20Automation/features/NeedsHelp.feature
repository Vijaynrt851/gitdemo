@sanity
Feature: Verify Need Helps page

  Background:
    Given I have launched the "homePage"
    Then verify the title
    Then I enter the username and password
    Then I click on the login button
    Then I verify the user is logged in successfully
    When I click on the need help link

  Scenario: Verify the need help page is displayed successfully
    Then I verify the case list section is displayed successfully
    Then I verify the submit query section is displayed successfully
    Then I verify the complaints section is displayed successfully
    Then I verify the common question section is displayed successfully
