Feature: QNS - Prepopulate saved details and Submit New Query
  As a registered resident
  I want to be pre-populated my personal details on noise complaint form when its saved before
  And I want to submit new query from confirmation page

   Background:
    Given I navigate to "qnsHomePage"
    And I am logged in to the QNS application

  @qns @qns-regression @qns-sanity @777291 @752885 @752887
  Scenario: Pre-populated fields when personal details are saved
    Given I have previously saved my personal details in My Account
    When I go to the noise complaint form
    Then the "Address Line 1", "Address Line 2" and "Postcode" fields should be pre-populated with my saved details
    And all pre-populated fields "Address Line 1", "Address Line 2" and "Postcode" should be non-editable
    And the consent checkbox should not be displayed

  @qns @qns-sanity @777291 @752885
  Scenario: Submit new query from confirmation page
    Given I go to the noise complaint form
    When I fill the address line 1 and postcode fields if it is empty
    And I fill all required disturbance information fields
    And I submit the form
    Then the confirmation page is displayed
    And the confirmation page should include a "Submit new query" button
    When I click the "Submit new query" button to go to noise complaint form
    When I fill the address line 1 and postcode fields if it is empty
    And I should be able to refill all required disturbance fields
    And I submit the form
    Then the confirmation page is displayed