@qns @qns-regression
Feature: QNS - View MyAccount Details and Option to save personal details
  As a registered resident
  I want to view my account details
  So that I can confirm what personal information the portal holds about me 
  And I want to be offered with the option to save my personal details in noise complaint form

  Background:
    Given I navigate to "qnsHomePage"
    And I am logged in to the QNS application

  @qns @qns-sanity @752866
  Scenario: Verify mandatory fields are always displayed
    When I open My Account
    Then I should see my "full name" on the account page

  @qns @752866
  Scenario: Verify optional fields are displayed when available
    When I open My Account
    Then I should see the following optional fields if supplied
        | Field Name        |
        | mobile phone      |
        | home phone        |
        | email             |
        | mailing city      |
        | mailing state     |
        | mailing country   |
        | address line 1    |
        | address line 2    |
        | postcode          |

  @qns @777291
  Scenario: Verify Personal Details Are Not Saved to My Account When Unchecked
    When I open My Account
    Then I clear "Address Line 1", "Address Line 2" and "Postcode" fields if it is not empty
    Then I go to the noise complaint form
    When I fill "Address Line 1", "Address Line 2" and "Postcode" fields without checking save option
    When I fill all required disturbance information fields
    And I submit the form
    Then the form should submit successfully
    When I open My Account
    Then the "Address Line 1", "Address Line 2" and "Postcode" fields should be displayed empty in My Account
    When I go to the noise complaint form
    Then the "Address Line 1", "Address Line 2" and "Postcode" fields should be displayed empty in noise complaint form
    
  @qns @qns-sanity @777291 @752887
  Scenario: Verify Personal Details Are Saved to My Account When Checked
    When I open My Account
    Then I clear "Address Line 1", "Address Line 2" and "Postcode" fields if it is not empty
    Then I go to the noise complaint form
    When I fill "Address Line 1", "Address Line 2" and "Postcode" fields
    When I fill all required disturbance information fields
    And I check the checkbox to save my personal details
    Then I submit the form
    Then the form should submit successfully
    When I open My Account
    Then the "Address Line 1", "Address Line 2" and "Postcode" fields should be displayed in My Account as I entered when submitting form

  @qns @752867
  Scenario: Verify mandatory fields validation when attempting to save My Account
    When I open My Account
    And I click on Edit button
    And I clear all editable fields in My Account
    When I attempt to save My Account
    Then system should display error to restrict saving personal details

  @qns @752867
  Scenario: Verify successful save to My Account with mandatory fields only
    When I open My Account
    And I click on Edit button
    And I clear all editable fields in My Account
    And I enter only mandatory fields in My Account
    And I save My Account changes
    Then mandatory fields should be saved successfully

  @qns @qns-sanity @752867
  Scenario: Verify full personal details update in My Account and pre-population in Noise complaint form
    When I open My Account
    And I click on Edit button
    And I clear all editable fields in My Account
    And I enter all personal details in My Account
    And I save My Account changes
    Then all personal details should be saved successfully
    When I go to the noise complaint form
    Then the "Address Line 1", "Address Line 2" and "Postcode" fields should be pre-populated with my saved details
    And all pre-populated fields "Address Line 1", "Address Line 2" and "Postcode" should be non-editable