@qns @qns-regression
Feature: QNS - Key Policies and Processes Component on Portal Landing Page
  As a Product owner
  I want to see a section on the portal landing page presenting key policies and processes
  So that registered users can access relevant programme information directly from the portal without navigating away to a separate site

  Background:
    Given I navigate to "homePage"
    And I am logged in to the QNS application
  
  @qns @qns-sanity @775514
  Scenario: Verify Key Policies and Processes components Expand, Content and Collapse functionality
  When I see the following Key Policies and Processes components
     | Component Type   | Component Name                                |
     | Section Heading  | Staying informed                              |
     | Main Heading     | Key Policies and Processes                    |
     | Description      | Key Policies Description                      |
     | Accordion Header | Complaints policy                             |
     | Accordion Header | Contacting other organisations                |
     | Accordion Header | Monitoring and improving aircraft performance |
     | Accordion Header | Restrictions on night flights                 |

  Then I should expand, view content, and collapse the following accordions
     | Accordion Name                                |
     | Complaints policy                             |
     | Contacting other organisations                |
     | Monitoring and improving aircraft performance |
     | Restrictions on night flights                 |

@qns @qns-regression @775514
Scenario: Verify Key Policies and Processes component links navigation
When I should be able to navigate through external links from "Complaints policy"
| Accordion Header               | Link Name           | Url Key                      |
| Complaints policy              | Complaints Policy   | complaintsPolicyPDF          |
Then I should be able to navigate through external links from "Contacting other organisations"
| Accordion Header               | Link Name           | Url Key                      |
| Contacting other organisations | CAA                 | caaContactPage               |
| Contacting other organisations | DfT                 | dftContactPage               |
| Contacting other organisations | NATS                | natsContactPage              |
Then I should be able to navigate through external links from "Contacting other organisations"
| Accordion Header               | Link Name           | Url Key                      |
| Contacting other organisations | Gatwick Airport     | gatwickAirportPage           |
| Contacting other organisations | London City Airport | londonCityAirportPage        |
| Contacting other organisations | Luton Airport       | lutonAirportPage             |
Then I should be able to navigate through external links from "Restrictions on night flights"
| Accordion Header               | Link Name           | Url Key                      |
| Restrictions on night flights  | Night Flights       | nightFlightsRestrictionsPage |
