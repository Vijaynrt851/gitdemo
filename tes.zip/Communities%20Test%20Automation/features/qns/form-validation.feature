@qns @qns-regression
Feature: QNS Form Validation - Validate Form Completeness Before Submission
  As a resident
  I want the form to prevent submission if any required fields are missing and highlight them
  So that I know what I need to complete

  Background:
    Given I navigate to "qnsHomePage"
    And I am logged in to the QNS application

  @qns-sanity @752892 @test
  Scenario: Prevent submission when all required fields are empty
    Given I navigate to the noise complaint form
    When I attempt to submit the form without filling any fields
    Then the system must prevent form submission
    And I should see validation errors for all required fields
    And all validation messages should be displayed in red

  @752892
  Scenario Outline: Verify individual required field validation
    Given I navigate to the noise complaint form
    When I leave the "<field_name>" field empty
    And I attempt to submit the form
    Then the system must prevent form submission
    And I should see a validation error for "<field_name>" in red
    And the validation message should identify the missing field clearly

    Examples:
      | field_name             |
      | date of disturbance    |
      | disturbance time       |
      | disturbance type       |
      | disturbance details    |

  @752892
  Scenario: Verify all disturbance information fields are required
    Given I navigate to the noise complaint form
    When I leave all disturbance information fields empty
    And I attempt to submit the form
    Then the system must prevent form submission
    And I should see validation errors for disturbance information fields in red

  @752892
  Scenario: Verify form submission succeeds when all required fields are filled
    Given I navigate to the noise complaint form
    When I fill all required disturbance information fields
    And I submit the form
    Then the form should submit successfully
    And no validation errors should be displayed

  @qns-sanity @752889
  Scenario: Verify date selection using HTML5 date picker
    Given I navigate to the noise complaint form
    When I verify the date field is an HTML5 date input
    And I select date "2026-08-25" using the date picker
    Then the selected date should be captured in the date field

  @752889
  Scenario: Verify time selection using 24-hour dropdown with 15-minute increments
    Given I navigate to the noise complaint form
    When I verify the time dropdown has 15-minute increment options
    And I verify all time options are in 24-hour format
    And I select time "23:45" from the time dropdown
    Then the selected time should be captured in the time field

  @qns-sanity @752890
  Scenario: Verify disturbance type dropdown contains all required options
    Given I navigate to the noise complaint form
    When I open the disturbance type dropdown
    Then the dropdown should contain all expected disturbance types

  @752890
  Scenario: Verify disturbance details text box accepts free-text input
    Given I navigate to the noise complaint form
    When I enter disturbance details from test data
    Then the disturbance details field should contain the entered text

  @qns-sanity @752893
  Scenario: Verify email copy checkbox is displayed on the form
    Given I navigate to the noise complaint form
    Then the email copy checkbox should be visible
    And the email copy checkbox should be unchecked by default

  @752893
  Scenario: Verify user can select email copy option
    Given I navigate to the noise complaint form
    When I select the email copy checkbox
    Then the email copy checkbox should be checked
    When I unselect the email copy checkbox
    Then the email copy checkbox should be unchecked

  @qns-sanity @752893 @qns-e2e
  Scenario: Submit noise complaint with email copy option selected
    Given I navigate to the noise complaint form
    When I fill all required disturbance information fields
    And I select the email copy checkbox
    Then the email copy checkbox should be checked
    And I submit the form
