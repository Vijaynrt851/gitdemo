@sanity
Feature: Verify FAQs on the Home page

  Background:
    Given I have launched the "homePage"
    Then verify the title
    Then I enter the username and password
    Then I click on the login button
    Then I verify the user is logged in successfully

  Scenario: Verify the FAQ on the home page
    When I scroll to the FAQ section
    Then I verify the FAQ section first accordion is expanded by default
    When I expand any other accordion
    Then the other gets collapsed immediately
