@sanity
Feature: Home page and Video component functionality

  Background:
    Given I have launched the "homePage"
    Then verify the title
    Then I enter the username and password
    Then I click on the login button
    Then I verify the user is logged in successfully
    Then verify the Hero component is displayed successfully

  Scenario: Verify the Video component is displayed successfully
    Then verify the Video component is displayed successfully
    Then verify the video carousel is displayed successfully
    Then verify the video carousel is functional
    Then verify the video player is functional
