@regression
Feature: View MyAccount Details and Option to save personal details

  Background:
    Given I navigate to "homePage"
    Then I enter the username and password
    Then I click on the login button
    Then I verify the user is logged in successfully

  Scenario: View all account details on My Account page
    When I open My Account
    Then 
