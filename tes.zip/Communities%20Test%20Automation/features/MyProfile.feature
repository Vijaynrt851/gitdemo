Feature: View MyAccount Details and Option to save personal details

  Background:
    Given I navigate to "homePage"
    Then I enter the username and password
    Then I click on the login button
    Then I verify the user is logged in successfully

  Scenario: View all account details on My Account page
    When I open My Account
    Then the system must display my current stored details:
      | Field Name     |
      | full name      |
      | email          |
      | mobile number  |
      | address line 2 |
      | postcode       |

  Scenario: Verify mandatory fields are always displayed
    When I open My Account
    Then I should see my "full name" on the account page
    And I should see my "email" on the account page

  Scenario: Verify optional fields are displayed when available
    When I open My Account
    Then I should see my "mobile number" if supplied
    And I should see my "address line 2" if supplied
    And I should see my "postcode" if supplied
