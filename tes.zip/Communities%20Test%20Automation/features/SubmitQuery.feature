@sanity
Feature: Verify the Submit Query, case comments and case detail functionality on Need Helps page

  Background:
    Given I have launched the "homePage"
    Then verify the title
    Then I enter the username and password
    Then I click on the login button
    Then I verify the user is logged in successfully
    Then I click on the "needHelpLink" link

  Scenario: Verify the required fields on submit query page
    Then I verify the submit query section is displayed successfully
    When I click on the submit button without entering any data
    Then I verify the error message is displayed for all required fields

  Scenario: Verify the submit query functionality
    Then I verify the submit query section is displayed successfully
    When I enter all the required fields and click on submit button
    Then I verify the success message is displayed after submitting the query

  Scenario: Verify the case comment functionality
    Then I verify the case list section is displayed successfully
    Then I sort the case list by date
    Then I click on the first case in the list
    Then I verify the case details are displayed successfully
    When I enter a comment and click on submit button
    Then I verify the comment is added successfully to the case
