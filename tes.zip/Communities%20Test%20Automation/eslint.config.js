import js from '@eslint/js';
import globals from 'globals';

export default [
    js.configs.recommended,

    {
        ignores: [
            'node_modules/**',
            'playwright-report/**',
            'allure-report/**',
            'allure-results/**',
            'reports/**',
            'coverage/**',
            'test-results/**',
            'dist/**',
            'build/**',
            'screenshots/**',
            'videos/**',
            'traces/**',
            '.vscode/**',
        ],
        files: ['**/*.js'],

        languageOptions: {
            ecmaVersion: 'latest',
            sourceType: 'module',

            globals: {
                ...globals.node,
            },
        },

        rules: {
            // Variables
            'no-undef': 'error',
            'no-unused-vars': 'warn',
            'no-use-before-define': 'error',

            // Imports
            'no-duplicate-imports': 'error',

            // Common bugs
            'no-unreachable': 'error',
            'no-unreachable-loop': 'error',
            'no-constant-condition': 'error',
            'no-empty': 'warn',
            'no-empty-function': 'warn',

            // Equality
            eqeqeq: 'error',

            // Async
            'require-await': 'warn',

            // Misc
            'no-console': 'off',
        },
    },
];
