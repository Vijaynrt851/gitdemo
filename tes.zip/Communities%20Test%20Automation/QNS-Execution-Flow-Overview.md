QNS Execution Flow Overview

1. Purpose of the QNS module
The QNS (Quality and Noise Service / Noise Complaint / QNS portal) automation is organized around Cucumber feature files, step definitions, page objects, and JSON test data. It follows the Playwright + Cucumber framework pattern used across the project.

The execution flow is:
- Feature file is read by Cucumber
- Matching step definition file is executed
- Step definition calls methods from page object classes
- Page object performs Playwright actions on the UI
- Test data is loaded from JSON/YAML files
- Hooks initialize browser and page before each scenario

2. Main QNS folders and files

2.1 Features folder
Folder: `features/qns`
Contains the business-readable scenarios for QNS.

Files:
- `homePage-qns.feature`
  Purpose: validates the home page section "Key Policies and Processes".
  Includes:
  - section heading visibility
  - main heading visibility
  - description validation
  - accordion expand/collapse behavior
  - external links validation

- `form-validation.feature`
  Purpose: validates form completeness and validation checks before submission.
  Includes tests for:
  - empty required fields
  - missing disturbance information
  - personal details validation
  - successful submission when fields are valid

- `my-account.feature`
  Purpose: tests the My Account page and saved user profile values.

- `submit-new-query.feature`
  Purpose: tests the new query submission flow.

2.2 Step definitions folder
Folder: `features/step_definitions/qns`
Contains the glue code that maps Gherkin steps to automation logic.

Files:
- `homePage-qns-steps.js`
  Handles steps for the QNS home page such as:
  - navigating to the page
  - checking section visibility
  - expanding/collapsing accordions
  - verifying external links open correct URLs

- `form-validation-steps.js`
  Handles steps for form validation, for example:
  - navigate to QNS form
  - login to application
  - leave fields empty
  - submit the form
  - validate required field errors

- `my-account-steps.js`
  Handles My Account page flow and assertions.

- `submit-new-query-steps.js`
  Handles new query submission flow and validations.

2.3 Page object folder
Folder: `pageobjects/qns`
Contains UI interactions for each QNS page/component.

Files:
- `HomePageQns.js`
  Methods include:
  - `verifyKeyPoliciesComponentDisplayed()`
  - `verifyKeyPoliciesAccordionHeaderDisplayed()`
  - `verifyKeyPoliciesAccordionExpandCollapse()`
  - `clickKeyPoliciesAccordionHeader()`
  - `clickKeyPoliciesExternalLink()`
  - `verifyExternalTabOpened()`
  Purpose: manages the QNS landing page content and accordions.

- `NoiseComplaintFormPage.js`
  Handles the noise complaint form.
  Methods include:
  - navigation to the form
  - filling disturbance details
  - submitting the form
  - clearing form fields
  - validating required fields

- `MyAccountPage.js`
  Handles personal details and account settings page actions.

- `ConfirmationPage.js`
  Handles confirmation screens after form/submission success.

2.4 Test Data folder
Folder: `testData/qns`
Contains JSON test data used for QNS scenarios.

Files:
- `homePage-qns-data.json`
  Contains expected URL and text/config values for the home page section.

- `form-validation-data.json`
  Contains valid and invalid values for disturbance fields and expected validation behavior.

- `my-account-data.json`
  Contains expected values for account information and profile checks.

- `submit-new-query-data.json`
  Contains data used to submit a new complaint/query including form values and expected results.

3. Common execution flow for QNS features
The general runtime flow is as follows:

Step 1: Cucumber loads the feature file
Example: `features/qns/homePage-qns.feature`
This file contains the scenario steps in plain English/Gherkin.

Step 2: Hooks initialize the browser and page
File: `features/support/hooks.js`
This file contains:
- `BeforeAll` hook
  - loads environment variables
  - initializes browser/session-level configuration
- `Before` hook
  - creates browser context
  - creates a page
  - creates `this.poManager`
  - creates `this.testDataUtils`

Step 3: Background or Given step runs
Example from `homePage-qns.feature`:
- `Given I navigate to "homePage"`
- `And I am logged in to the QNS application`

This calls:
- `Given('I navigate to {string}', ...)` in `features/step_definitions/qns/form-validation-steps.js`
  - reads the URL from `TestDataUtils`
  - calls `page.goto(url)`

- `Given('I am logged in to the QNS application', ...)`
  - calls `LoginPage.enterUsernameAndPassword()`
  - calls `LoginPage.clickLoginButton()`

Step 4: Page objects execute UI interactions
For example, `HomePageQns.js` does the actual UI work:
- verifies headings are visible
- clicks accordion headers
- checks `aria-expanded` state
- opens external links in a new tab
- validates the destination URL

Step 5: Assertions happen
The step definitions use Playwright `expect` statements to verify the result.
Examples:
- visible text contains expected wording
- accordion expands
- new tab URL contains the correct URL
- form submission shows validation errors or success

Step 6: After hook runs
File: `features/support/hooks.js`
The `After` hook:
- captures screenshot
- records test result
- attaches video if configured
- closes browser/context
- finalizes execution logs

4. Example: Home Page QNS execution flow
Feature file: `features/qns/homePage-qns.feature`

Background:
- Navigate to `homePage`
- Login to the QNS app

Scenario 1: Verify Key Policies and Processes components Expand, Content and Collapse functionality
- Step definition: `homePage-qns-steps.js`
- Calls `HomePageQns.verifyKeyPoliciesComponentDisplayed()` for each row in the data table
- Then calls `verifyKeyPoliciesAccordionExpandCollapse()` for each accordion
- Validates that the main section, headings, descriptions, and accordions appear and toggle correctly

Scenario 2: Verify Key Policies and Processes component links navigation
- Step definition: `homePage-qns-steps.js`
- Reads configured URLs from `testData/qns/homePage-qns-data.json`
- Opens each external link from the accordion section
- Checks the opened page URL matches the expected URL
- Returns to the original homepage for the next link

5. Execution path summary
A simplified path:

Feature file
  -> Step definition file
  -> Page object class
  -> Playwright locator/actions
  -> Assertions
  -> Test data JSON
  -> Browser hooks
  -> Screenshot/video/reporting

6. Important configuration files involved
Files outside QNS folder that drive the execution:
- `features/support/hooks.js`
  Initializes browser and all scenario setup.

- `pageobjects/POManager.js`
  Creates and exposes page objects for the application, including QNS page objects.

- `utils/TestDataUtils.js`
  Reads environment and test data, and resolves `USERNAME` and `PASSWORD` values.

- `cucumber.js`
  Configures Cucumber execution behavior.

- `playwright.config.js`
  Controls Playwright browser and test settings.

7. Conclusion
The QNS automation is organized in a clean layered architecture:
- `features/qns`: business scenarios written in Gherkin
- `features/step_definitions/qns`: scenario implementations
- `pageobjects/qns`: UI interactions and assertions
- `testData/qns`: input data and expected values
- `features/support/hooks.js`: browser lifecycle and setup

This structure allows each QNS feature to be executed end-to-end with a clear separation between test intent, test logic, and page behavior.

8. Quick reference
If a QNS test fails, start here:
- Feature file: `features/qns/*.feature`
- Matching step file: `features/step_definitions/qns/*.js`
- Page logic: `pageobjects/qns/*.js`
- Data: `testData/qns/*.json`
- Browser hooks: `features/support/hooks.js`

This file documents the QNS execution flow in the same structure used by the project.
