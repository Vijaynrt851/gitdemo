import fs from "fs/promises";
import path from "path";

const folders = [
    "reports",
    "allure-results",
    "report-data",
    "playwright-report",
    "allure-report",
    "test-results/screenshots",
    "test-results/videos",

];

function getTimestamp() {
    const now = new Date();

    return now
        .toISOString()
        .replace(/:/g, "-")
        .replace(/\..+/, "");
}

(async () => {

    const historyRoot = "history";
    const backupRoot = path.join(historyRoot, getTimestamp());

    await fs.mkdir(backupRoot, { recursive: true });

    for (const folder of folders) {

        try {

            const exists = await fs
                .access(folder)
                .then(() => true)
                .catch(() => false);

            if (exists) {

                const destination = path.join(backupRoot, folder);

                await fs.mkdir(path.dirname(destination), {
                    recursive: true
                });

                await fs.rename(folder, destination);

                console.log(`✓ Backed up ${folder}`);
            }

            await fs.mkdir(folder, {
                recursive: true
            });

            console.log(`✓ Ready ${folder}`);

        }
        catch (err) {

            console.error(`Failed processing ${folder}`, err);

        }
    }

    console.log(`\nBackup stored in ${backupRoot}`);

})();