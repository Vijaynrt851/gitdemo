const parallelThread = process.env.PARALLEL_THREAD || 1;
const retryCount = process.env.RETRY_COUNT || 0;

export default function () {
    return {
        default: {
            paths: ['features/**/*.feature'],
            require: [
                'features/support/world.js',
                'features/support/hooks.js',
                'features/step_definitions/**/*-steps.js',
            ],
            format: [
                'progress-bar',
                'html:reports/cucumber-report.html',
                'json:reports/cucumber_report.json',
                'junit:reports/junit-results.xml',
                '@serenity-js/cucumber',
                'allure-cucumberjs/reporter',
            ],
            retry: Number(retryCount),
            parallel: Number(parallelThread),
        },

        smoke: {
            tags: '@smoke',
        },

        regression: {
            tags: '@regression',
        },
    };
}

// export default {
//   paths: ["features/**/*.feature"],

//   require: [
//     "features/support/world.js",
//     "features/support/hooks.js",
//     "features/step_definitions/**/*-steps.js"
//   ],

//   format: [
//     "@serenity-js/cucumber",
//     "json:reports/cucumber_report.json",
//     "progress-bar",
//     "allure-cucumberjs/reporter"
//   ],

//   retry: Number(process.env.RETRY_COUNT || 0),
//   parallel: Number(process.env.PARALLEL_THREAD || 1)
// };
