# Hooks File - Detailed Explanation

File: `features/support/hooks.js`

This file contains all the lifecycle hooks for the Cucumber + Playwright automation framework. Each hook runs at specific points in the test execution.

---

## 1. BeforeAll Hook

**Location:** Lines 24-96

**When it runs:** Once, before all scenarios in the entire test suite

**Purpose:** Global setup that happens only once

**Method signature:**
```javascript
BeforeAll(async function () { ... })
```

### Explanation line-by-line:

#### 1.1 `dotenv.config();`
- Loads environment variables from the `.env` file
- This makes all variables like `QA_USERNAME`, `QA_PASSWORD` available to the test
- If `.env` file does not exist, it simply skips loading

#### 1.2 `console.log("Executing @BeforeAll_Hook");`
- Logs that the BeforeAll hook is starting
- Useful for debugging

#### 1.3 `console.log(\`BeforeAll - PID: ${process.pid}\`);`
- Logs the Process ID
- Helpful when running parallel tests to identify which process is running

#### 1.4 `console.log({ pid: process.pid, threadId, isMainThread });`
- Prints detailed execution metadata:
  - `pid`: Process ID
  - `threadId`: Worker thread ID (useful in parallel execution)
  - `isMainThread`: Whether this is the main thread

#### 1.5 `await browserUtils.getBrowser();`
- Initializes the Playwright browser instance
- This is a shared browser that will be reused by scenarios
- `browserUtils` is a utility class defined at the top of the file

#### 1.6 `if (process.env.CUCUMBER_WORKER_ID === "0")`
- Checks if this is the first worker process
- Important in parallel test execution
- Ensures only one worker writes the shared execution info file
- If running 4 parallel threads, this condition is true only for worker 0

#### 1.7 `const reportsDir = path.resolve("report-data");`
- Creates a path to the `report-data` folder
- This folder stores execution metadata

#### 1.8 `const executionInfoPath = path.join(reportsDir, "execution-info.json");`
- Creates the full path to the execution info file

#### 1.9 `await fs.mkdir(reportsDir, { recursive: true });`
- Creates the `report-data` folder if it does not exist
- `recursive: true` means it creates parent folders if needed

#### 1.10 `await fs.unlink(executionInfoPath);`
- Deletes the old `execution-info.json` file if it exists
- This ensures a fresh start for each test run

#### 1.11 `const executionInfo = { ... }`
- Creates an object with execution metadata:

**Project info:**
- `projectName`: Name of the project (default: "Heathrow Playwright Cucumber")
- `framework`: "Playwright + Cucumber"
- `language`: "JavaScript"

**Execution info:**
- `environment`: Environment being tested (QA, SIT, UAT, STAGE, PROD) - read from `NODE_ENV`
- `browser`: Which browser (chromium, firefox, webkit, mobile, etc.)
- `browserChannel`: Browser channel if specified
- `browserVersion`: Browser version
- `headless`: Whether running headless (true) or headed (false)
- `parallelThreads`: Number of parallel threads running (default 1)
- `retryCount`: How many times to retry failed tests

**System info:**
- `nodeVersion`: Node.js version (`process.version`)
- `platform`: OS platform (win32, linux, darwin)
- `operatingSystem`: OS type (Windows_NT, Linux, Darwin)
- `osVersion`: OS version
- `architecture`: CPU architecture (x64, arm64, etc.)
- `cpuCount`: Number of CPU cores
- `hostname`: Computer name
- `username`: User running the tests

**CI info (if running in CI/CD):**
- `ci`: Whether running in CI
- `ciProvider`: CI provider name (Jenkins, GitHub Actions, Azure Pipelines, etc.)
- `gitBranch`: Git branch being tested
- `gitCommit`: Git commit hash

**Build info:**
- `release`: Release version (default 1.0.0)
- `cycle`: Test cycle name

#### 1.12 `await fs.writeFile(executionInfoPath, JSON.stringify(executionInfo, null, 2), "utf8");`
- Writes the execution info object to a JSON file
- `JSON.stringify(..., null, 2)` makes it human-readable with indentation
- `"utf8"` specifies the file encoding
- This file is later used for reporting

#### 1.13 `console.log("Execution context created.");`
- Logs that the execution info file was created

**Summary of BeforeAll:**
- Sets up the environment by loading variables
- Initializes the shared browser instance
- Creates and saves execution metadata
- Happens only once for the entire test suite

---

## 2. Before Hook

**Location:** Lines 98-167

**When it runs:** Before each scenario

**Purpose:** Set up a fresh environment for each test case

**Method signature:**
```javascript
Before({ timeout: 20000 }, async function () { ... })
```

**`timeout: 20000`** means this hook has 20 seconds to complete. If it takes longer, it times out.

### Explanation line-by-line:

#### 2.1 `console.log("Executing @Before_Scenario_Hook");`
- Logs that the Before hook for a scenario is starting

#### 2.2 `screenshotHelper.resetStepCounter();`
- Resets the step counter to 0 for the new scenario
- This ensures screenshots are numbered starting from step 1 for each new scenario
- Without this, all screenshots would use one continuous counter

#### 2.3 `this.browser = await browserUtils.getBrowser();`
- Gets the browser instance
- `this.browser` is now available in step definitions
- Uses the shared browser created in BeforeAll

#### 2.4 `console.log(\`Browser instance obtained. PID=${process.pid}\`);`
- Logs that the browser is ready

#### 2.5 `const browserType = (process.env.BROWSER || "chromium").toLowerCase();`
- Reads the browser type from environment variable `BROWSER`
- Default is "chromium" if not specified
- Converts to lowercase for consistency
- Examples: chromium, firefox, webkit, mobile-chrome, mobile-webkit, Galaxy-Tab-chrome

#### 2.6 `const contextOptions = { ... }`
- Creates options for the browser context:

```javascript
{
    ignoreHTTPSErrors: true,          // ignore SSL certificate errors
    acceptDownloads: true,            // allow file downloads
    recordVideo: process.env.RECORD_VIDEO === "true"
        ? { dir: "./test-results/videos" }  // save videos here if enabled
        : undefined                   // don't record if not enabled
}
```

#### 2.7 `switch (browserType) { ... }`
- Creates different browser contexts based on device type:

**Case: `mobile-chrome`**
```javascript
this.context = await this.browser.newContext({
    ...devices["Pixel 7"],      // Uses Pixel 7 mobile device settings
    ...contextOptions
});
```
- Pixel 7 has specific viewport size, user agent, touch settings

**Case: `mobile-webkit`**
```javascript
this.context = await this.browser.newContext({
    ...devices["iPhone 15"],    // Uses iPhone 15 settings
    ...contextOptions
});
```

**Case: `tablet-ipad-webkit`**
```javascript
this.context = await this.browser.newContext({
    ...devices["iPad Pro 11"],  // Uses iPad Pro 11 settings
    ...contextOptions
});
```

**Case: `Galaxy-Tab-chrome`**
```javascript
this.context = await this.browser.newContext({
    ...devices["Galaxy Tab S9"], // Uses Galaxy Tab S9 settings
    ...contextOptions
});
```

**Default case (desktop):**
```javascript
this.context = await this.browser.newContext({
    viewport: {
        width: 1280,
        height: 1080            // Desktop viewport size
    },
    ...contextOptions
});
```

#### 2.8 `console.log(\`Browser context created. PID=${process.pid}\`);`
- Logs that the context is ready

#### 2.9 `this.page = await this.context.newPage();`
- Creates a new blank page in the context
- `this.page` is the webpage where the automation happens
- Every scenario gets a fresh page

#### 2.10 `this.poManager = new POManager(this.page);`
- Creates a Page Object Manager
- POManager holds all page objects for the application:
  - LoginPage
  - HomePage
  - FaqPage
  - MyProfilePage
  - HomePageQns (for QNS feature)
  - etc.
- `this.poManager` is now available in step definitions
- Example: `this.poManager.getLoginPage()` returns the LoginPage instance

#### 2.11 `this.testDataUtils = new TestDataUtils();`
- Creates a test data utility object
- This is used to:
  - Read environment-specific test data
  - Get login credentials from environment variables
  - Load JSON/YAML test data files
- `this.testDataUtils` is now available in step definitions
- Example: `this.testDataUtils.getUsernameAndPassword()` returns login credentials

#### 2.12 `console.log(\`Page Object Manager initialized. PID=${process.pid}\`);`
- Logs that everything is ready

**Summary of Before:**
- Runs before each scenario
- Gets a fresh browser and page
- Initializes POManager and TestDataUtils
- Makes `this.page`, `this.poManager`, `this.testDataUtils` available to steps
- This is the most critical hook for test setup

---

## 3. BeforeStep Hook

**Location:** Lines 175-181

**When it runs:** Before each individual step (Given/When/Then)

**Purpose:** Initialize step-level utilities

**Method signature:**
```javascript
BeforeStep(function (scenario) { ... })
```

**Note:** This is synchronous (no `async`), so it must complete instantly

### Explanation line-by-line:

#### 3.1 `console.log(\`Executing @BeforeStep_Hook for scenario: ${scenario.pickle.name}\`);`
- Logs which scenario's step is about to run
- `scenario.pickle.name` is the scenario name from the feature file

#### 3.2 `this.apiUtils = new APiUtils();`
- Creates API utilities
- Used if a step needs to make API calls
- Example: testing REST endpoints
- `this.apiUtils` is now available in step definitions

#### 3.3 `this.accessibilityHelper = new AccessibilityHelper();`
- Creates accessibility testing utilities
- Used if a step needs to check accessibility issues
- Runs Axe accessibility tests
- `this.accessibilityHelper` is now available in step definitions

#### 3.4 `this.testName = scenario.pickle.name.replace(/\s+/g, '_');`
- Takes the scenario name
- Replaces all whitespace with underscores
- Example: "Verify Login functionality" → "Verify_Login_functionality"
- Used for naming screenshots and reports

**Summary of BeforeStep:**
- Runs before each step
- Initializes API and accessibility helpers
- Creates a clean test name for reporting
- Makes utilities available to each step

---

## 4. After Hook

**Location:** Lines 183-226

**When it runs:** After each scenario (regardless of pass/fail)

**Purpose:** Capture results and cleanup

**Method signature:**
```javascript
After(async function ({ result, pickle, gherkinDocument }) { ... })
```

**Parameters:**
- `result`: Scenario result (passed/failed)
- `pickle`: Scenario data from feature file
- `gherkinDocument`: The entire feature file

### Explanation line-by-line:

#### 4.1 `const { line } = formatterHelpers.PickleParser.getPickleLocation({ gherkinDocument, pickle });`
- Extracts the exact line number where the scenario is defined in the feature file
- Example: Scenario starts at line 42 of homePage-qns.feature
- Used in reports to link scenario to feature file

#### 4.2 `const status = result.status === Status.PASSED ? 'passed' : 'failed';`
- Converts scenario status to a string
- `Status.PASSED` is an enum from Cucumber
- Result: "passed" or "failed"

#### 4.3 `const scenario = pickle.name;`
- Gets the scenario name
- Example: "Verify Key Policies and Processes components"

#### 4.4 `const video = this.page?.video();`
- Gets the video object if recording is enabled
- `?.` means only get if `this.page` exists
- Must be done before closing the context
- Video file will be saved later

#### 4.5 `try { ... } catch { ... } finally { ... }`
- Uses error handling to ensure cleanup happens even if something fails

#### 4.6 Inside try block:

`await screenshotHelper.captureScreenshot(this.page, scenario, line, status, null, this.attach.bind(this));`
- Captures a screenshot of the page after scenario completion
- Parameters:
  - `this.page`: The page to screenshot
  - `scenario`: Scenario name
  - `line`: Line number in feature file
  - `status`: passed or failed
  - `null`: no specific context
  - `this.attach.bind(this)`: Attaches to report

#### 4.7 `if (status === 'failed') { console.log(\`${scenario}: ${line} - FAILED\n${result.message}\`); }`
- If scenario failed, logs the failure message
- `result.message` contains the assertion error

#### 4.8 `console.log(\`${scenario}: ${line} - ${status.toUpperCase()}\`);`
- Logs final scenario status
- Example: "Verify Login: 42 - PASSED"

#### 4.9 Inside finally block (cleanup):

`if (this.context) { await this.context.close(); }`
- Closes the browser context
- This cleans up the page and frees browser resources
- Must happen before video handling

#### 4.10 `if (video) { await videoHelper.handleVideo(video, scenario, line, status, this); }`
- Processes and saves the video recording
- Done after context closes (Playwright best practice)
- Parameters: video object, scenario name, line, status, test context

**Summary of After:**
- Runs after each scenario
- Captures scenario-level screenshot
- Closes the browser context
- Handles video recording
- This is critical for cleanup and result collection

---

## 5. AfterStep Hook

**Location:** Lines 228-260

**When it runs:** After each individual step

**Purpose:** Capture per-step screenshots and reports

**Method signature:**
```javascript
AfterStep(async function ({ result, pickle, gherkinDocument }) { ... })
```

### Explanation line-by-line:

#### 5.1 `console.log("Executing @AfterStep_Hook");`
- Logs that the AfterStep hook is running

#### 5.2 `if (!this.page) { return; }`
- If there is no page object, exit early
- Prevents errors if page does not exist

#### 5.3 `const stepStatus = result.status === Status.PASSED ? "passed" : "failed";`
- Converts step status to string

#### 5.4 `if (process.env.SCREENSHOT_PER_STEP !== "true" && stepStatus !== "failed") { return; }`
- Only takes step screenshots if:
  - `SCREENSHOT_PER_STEP` environment variable is set to "true", OR
  - The step failed
- This optimizes performance by not taking screenshots for every step by default
- Failed steps always get screenshots

#### 5.5 `const { line } = formatterHelpers.PickleParser.getPickleLocation({ gherkinDocument, pickle });`
- Gets the line number of the step

#### 5.6 `const stepText = pickle.steps[screenshotHelper.stepCounter]?.text ?? \`step_${screenshotHelper.stepCounter}\`;`
- Gets the step text
- Example: "Given I navigate to homePage"
- `??` means if not found, use default name
- `screenshotHelper.stepCounter` tracks which step we are on

#### 5.7 `await screenshotHelper.captureStepScreenshot(this.page, pickle.name, line, stepText, stepStatus, this.attach.bind(this));`
- Captures a screenshot for this specific step
- Parameters:
  - `this.page`: Page to screenshot
  - `pickle.name`: Scenario name
  - `line`: Line number
  - `stepText`: The step text
  - `stepStatus`: passed or failed
  - `this.attach.bind(this)`: Attach to report

**Summary of AfterStep:**
- Runs after each step
- Only takes screenshots if enabled or step failed
- Useful for debugging which step failed

---

## 6. AfterAll Hook

**Location:** Lines 262-274

**When it runs:** Once, after all scenarios complete

**Purpose:** Final cleanup of the browser

**Method signature:**
```javascript
AfterAll(async function () { ... })
```

### Explanation line-by-line:

#### 6.1 `console.log("Executing @AfterAll_Hook");`
- Logs that AfterAll is running

#### 6.2 `console.log(\`AfterAll - PID: ${process.pid}\`);`
- Logs the process ID

#### 6.3 `console.log({ pid: process.pid, threadId, isMainThread });`
- Logs thread info

#### 6.4 `browserUtils.closeBrowser();`
- Closes the Playwright browser instance
- Frees all resources
- This is the final cleanup

#### 6.5 `console.log(\`Browser closed successfully PID: ${process.pid}\`);`
- Confirms browser is closed

**Summary of AfterAll:**
- Runs once after all tests complete
- Closes the shared browser instance
- Final resource cleanup

---

## Complete Lifecycle Summary

For one scenario with 3 steps:

```
BeforeAll (once for entire suite)
  ↓
Before (for this scenario)
  ├─ Reset screenshot counter
  ├─ Get browser
  ├─ Create context
  ├─ Create page
  ├─ Initialize POManager
  └─ Initialize TestDataUtils
  ↓
BeforeStep (for Step 1)
  ├─ Initialize API utils
  ├─ Initialize Accessibility helper
  └─ Set test name
  ↓
Step 1 executes (Given I navigate to homePage)
  ↓
AfterStep (for Step 1)
  └─ Take screenshot if failed or enabled
  ↓
BeforeStep (for Step 2)
  ├─ Initialize API utils
  ├─ Initialize Accessibility helper
  └─ Set test name
  ↓
Step 2 executes (When I see components)
  ↓
AfterStep (for Step 2)
  └─ Take screenshot if failed or enabled
  ↓
BeforeStep (for Step 3)
  ├─ Initialize API utils
  ├─ Initialize Accessibility helper
  └─ Set test name
  ↓
Step 3 executes (Then I should expand accordions)
  ↓
AfterStep (for Step 3)
  └─ Take screenshot if failed or enabled
  ↓
After (for this scenario)
  ├─ Capture final screenshot
  ├─ Close context
  └─ Handle video
  ↓
Next scenario repeats from Before
  ↓
AfterAll (once, after all scenarios)
  └─ Close browser
```

---

## Key Points

1. **BeforeAll & AfterAll** = Suite-level setup/cleanup (once)

2. **Before & After** = Scenario-level setup/cleanup (per scenario)

3. **BeforeStep & AfterStep** = Step-level setup/cleanup (per step)

4. **Three critical objects created in Before:**
   - `this.page`: Playwright page for UI automation
   - `this.poManager`: Access to all page objects
   - `this.testDataUtils`: Access to test data and credentials

5. **Why hooks matter:**
   - Eliminate duplication
   - Automatic setup/cleanup
   - Consistent environment for all tests
   - Easy result collection (screenshots, videos)

6. **Environment variables used:**
   - `BROWSER`: Which browser to use
   - `RECORD_VIDEO`: Record videos
   - `SCREENSHOT_PER_STEP`: Take step-level screenshots
   - `NODE_ENV`: Environment (QA, SIT, UAT)
   - `CUCUMBER_WORKER_ID`: Worker ID in parallel execution
