import UIHelper from '../utils/UIHelper.js';

class HomePage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        // TODO: Replace with actual locators
        this.heroComponent = this.page.locator('//h1[@class="hero-title"]');
        this.videoComponent = this.page.locator('//c-hrss-video-collection');
        this.videoCarousel = this.page.locator('//div[contains(@class,"carousel-controls")]');
        this.carouselActiveSlide = this.page.locator(
            '//div[contains(@class,"carousel-controls")]//button[contains(@class,"active")]'
        );
        this.carouselNextButton = this.page.locator(
            '(//div[contains(@class,"carousel-controls")]//button[not(contains(@class,"active"))])[1]'
        );
        this.carouselPreviousButton = this.page.locator('//button[@data-index="0" and not(contains(@class,"active"))]');
        this.videoPlayer = this.page.locator(
            '//div[contains(@class,"Player")]//button[contains(@aria-label,"player")]'
        );
        this.videoPlayButton = this.page.locator('(//div//video-cover)');
    }

    async verifyHeroComponentDisplayed() {
        await this.page.waitForLoadState('load');
        await this.UIHelper.verifyElementIsVisible(this.heroComponent);
    }

    async verifyVideoComponentDisplayed() {
        await this.UIHelper.scrollIntoView(this.videoComponent);
        await this.UIHelper.verifyElementIsVisible(this.videoComponent);
    }

    async verifyVideoCarouselDisplayed() {
        await this.UIHelper.scrollIntoView(this.videoCarousel);
        await this.UIHelper.verifyElementIsVisible(this.videoCarousel);
    }

    async verifyVideoCarouselFunctional() {
        await this.page.waitForLoadState('load');
        await this.UIHelper.verifyElementIsVisible(this.carouselActiveSlide);
        await this.UIHelper.clickOnWebElement(this.carouselNextButton);
        await this.UIHelper.verifyElementIsVisible(this.carouselPreviousButton);
    }

    async verifyVideoPlayerFunctional() {
        await this.page.waitForLoadState('load');
        //TBD
        // await this.UIHelper.clickOnWebElement(this.videoPlayButton);

        // const isPlaying = await this.videoPlayer.evaluate(
        //     (video) => !video.paused && !video.ended && video.currentTime > 0
        // );
        // expect(isPlaying).toBeTruthy();
    }
}

export { HomePage };
