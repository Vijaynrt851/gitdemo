import { test, expect } from '@playwright/test';
import UIHelper from '../utils/UIHelper.js';
import { TestDataUtils } from '../utils/TestDataUtils.js';

const testDataUtils = new TestDataUtils();

class FaqPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        // TODO: Replace with actual locators
        this.faqSection = this.page.locator('//div[contains(@class,"faq")]');
        this.firstAccordion = this.page.locator('(//div[contains(@class,"faq")]//button)[1]');
        this.firstAccordionExpanded = this.page.locator(
            '(//div[contains(@class,"faq")]//button)[1][@aria-expanded="true"]'
        );
        this.secondAccordion = this.page.locator('(//div[contains(@class,"faq")]//button)[2]');
        this.secondAccordionExpanded = this.page.locator(
            '(//div[contains(@class,"faq")]//button)[2][@aria-expanded="true"]'
        );
    }

    async scrollToFaqSection() {
        await this.page.waitForLoadState('load');
        await this.faqSection.scrollIntoViewIfNeeded();
    }

    async verifyFirstAccordionExpandedByDefault() {
        await this.UIHelper.verifyElementIsVisible(this.firstAccordionExpanded);
    }

    async expandOtherAccordion() {
        await this.page.waitForLoadState('load');
        await this.UIHelper.clickOnWebElement(this.secondAccordion);
    }

    async verifyOtherAccordionCollapsed() {
        await this.UIHelper.verifyElementIsNotVisible(this.firstAccordionExpanded);
        await this.UIHelper.verifyElementIsVisible(this.secondAccordionExpanded);
    }
}

export { FaqPage };
