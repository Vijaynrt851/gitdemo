import { test, expect } from '@playwright/test';
import UIHelper from '../utils/UIHelper.js';
import { AxeBuilder } from '@axe-core/playwright';

class DemoQAElementPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        this.TextBox = page.locator("//span[text()='Text Box']");
        this.CheckBox = page.locator("//span[text()='Check Box']");
        this.homeCB = page.locator(".rct-checkbox");
        this.RadioButton = page.locator("//span[text()='Radio Button']");
        this.yesRadio = page.locator("//input[@type='radio']").nth(1);
        this.Button = page.locator("//span[text()='Buttons']");
        this.DoubleClient = page.locator("#doubleClickBtn");
        this.Link = page.locator("//span[text()='Links']");
        this.FullName = page.locator("[placeholder='Full Name']");
        this.verifyMessage = page.locator("#doubleClickMessage");
    }

    async clickOnText(catagory) {
        if (catagory === 'elements') {
            await this.UIHelper.clickOnWebElement(this.elements);
        }
    }

    async checkBox() {
        await this.UIHelper.clickOnWebElement(this.CheckBox);
        await this.UIHelper.check(this.homeCB);
        await this.page.waitForTimeout(2000);
    }

    async radioButton() {
        await this.UIHelper.clickOnWebElement(this.RadioButton);
        await this.UIHelper.clickOnWebElement(this.yesRadio);
        await this.page.waitForTimeout(2000);
    }

    async doubleClickButton() {
        await this.UIHelper.clickOnWebElement(this.Button);
        await this.UIHelper.doubleClickOnWebElement(this.DoubleClient);
        await this.page.waitForTimeout(2000);
    }

    async enterTextInTextBox(text) {
        await this.UIHelper.clickOnWebElement(this.TextBox);
        await this.UIHelper.enterTextForWebElement(this.FullName, text);
        await this.page.waitForTimeout(2000);
    }

    async verifyDoubleClickMessage(message) {
        await expect(this.verifyMessage).toHaveText(message);
    }
}

export { DemoQAElementPage };
