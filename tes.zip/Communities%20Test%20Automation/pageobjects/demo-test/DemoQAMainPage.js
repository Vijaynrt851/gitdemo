import { test, expect } from '@playwright/test';
import UIHelper from '../utils/UIHelper.js';
import { TestDataUtils } from '../utils/TestDataUtils.js';

const testDataUtils = new TestDataUtils();

class DemoQAPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        this.elements = page.locator("div.card.mt-4.top-card").first();
    }

    async clickOnCatagory(catagory) {
        if (catagory === 'elements') {
            await this.UIHelper.clickOnWebElement(this.elements);
        }
    }
}

export { DemoQAPage };
