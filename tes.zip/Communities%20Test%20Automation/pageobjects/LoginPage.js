import { test, expect } from '@playwright/test';
import UIHelper from '../utils/UIHelper.js';
import { TestDataUtils } from '../utils/TestDataUtils.js';

const testDataUtils = new TestDataUtils();

class LoginPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        this.usernameInput = this.page.getByLabel('Username');
        this.passwordInput = this.page.getByLabel('Password');
        this.loginButton = this.page.locator('[data-submitbtn]');
        this.needHelpLink = this.page.getByRole('link', { name: /Need help\?/i });
        this.caseListTabTitle = this.page.locator(
            '//div[contains(@class,"guideSection")]//h1[contains(text(),"Cases")]'
        );
        this.submitQueryTabTitle = this.page.locator(
            '//div[contains(@class,"guideSection")]//h1[contains(text(),"query")]'
        );
        this.complaintsTabDownloadLink = this.page.locator('//a//span[contains(text(),"Download")]');
        this.successMessage = this.page.getByText(/Welcome/i).first();
        const { username, password } = testDataUtils.getUsernameAndPassword();
        this.username = username;
        this.password = password;
        this.commonQuestionsSection = this.page.locator('//div[contains(@class,"faq")]');
    }

    async enterUsernameAndPassword() {
        const username = await this.username;
        const password = await this.password;
        await this.UIHelper.enterTextForWebElementWithClear(this.usernameInput, username);
        await this.UIHelper.enterTextForWebElementWithClear(this.passwordInput, password);
    }

    async clickLoginButton() {
        await this.UIHelper.clickOnWebElement(this.loginButton);
    }

    async verifySuccessfulLogin() {
        await this.UIHelper.verifyElementIsVisible(this.successMessage);
    }

    async verifyCaseListPageDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.caseListTabTitle);
    }

    async verifySubmitQueryPageDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.submitQueryTabTitle);
    }

    async verifyComplaintsPageDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.complaintsTabDownloadLink);
    }

    async verifyCommonQuestionsSectionDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.commonQuestionsSection);
    }

    async clickOnLink(linkName) {
        const locator = this[linkName];

        if (!locator) {
            throw new Error(`Locator '${linkName}' not found in ${this.constructor.name}`);
        }
        await this.page.waitForLoadState('load');
        await this.UIHelper.clickOnWebElement(locator);
    }
}

export { LoginPage };
