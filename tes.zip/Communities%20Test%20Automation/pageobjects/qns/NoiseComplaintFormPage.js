import { expect } from '@playwright/test';
import UIHelper from '../../utils/UIHelper.js';
 
class NoiseComplaintFormPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
 
        this.dateInput = this.page.locator('input[id^="qns-date"]');
        this.timeSelect = this.page.locator('select[id^="qns-time"]');
        this.typeSelect = this.page.locator('select[id^="qns-type"]');
        this.detailsTextarea = this.page.getByPlaceholder('Describe the disturbance..');
        this.emailCopyCheckbox = this.page.locator('input[id^="qns-email-copy"]');
        this.saveContactInfoCheckbox = this.page.locator('input[id*="save-contact-information"], input[id*="save"][id*="contact"], input[type="checkbox"][id*="save"]').first();
        this.submitButton = this.page.getByRole('button', {
            name: 'Submit noise complaint' });
 
        // Pre-populated address fields (read-only)
        this.addressLine1 = this.page.getByPlaceholder('Enter address line 1');
        this.addressLine2 = this.page.getByPlaceholder('Enter address line 2');
        this.postcode = this.page.getByPlaceholder('Enter postcode');
 
 
        // Validation error message locators - VERIFIED IN QA
        this.errorSummary = this.page.locator('.qns-error-summary[role="alert"]');
        this.errorSummaryTitle = this.page.locator('.qns-error-summary-title');
        
 
        this.dateFieldInvalid = this.page.locator('input[id^="qns-date"][aria-invalid="true"]');
        this.timeFieldInvalid = this.page.locator('select[id^="qns-time"][aria-invalid="true"]');
        this.typeFieldInvalid = this.page.locator('select[id^="qns-type"][aria-invalid="true"]');
        this.detailsFieldInvalid = this.page.locator('textarea[id^="qns-details"][aria-invalid="true"]');
 
        this.invalidFields = this.page.locator('[aria-invalid="true"]');
        this.anyDateInput = this.page.locator('input[type="date"]...').first();
    }
 
    /**
     * Click a navigation link from the top navigation bar
     * @param {string} linkText - Text of the navigation link to click
     */
    // async clickNavigationLink(linkText) {
    //     const navLink = this.page.locator(`a:has-text("${linkText}")`);
    //     await navLink.waitFor({ state: 'visible', timeout: 10000 });
    //     await navLink.click();
        
    //     // Wait for navigation to complete
    //     await this.page.waitForLoadState('domcontentloaded');
        
    //     // Verify URL changed to QNS home page
    //     await this.page.waitForURL('**/qns-home-page**', { timeout: 10000 });
    // }
 
    async clickNavigationLink(linkText) {
    const navLink = this.page.locator('a[href="/qns-home-page"]');
 
    await navLink.waitFor({
        state: 'visible',
        timeout: 10000
    });
 
    await navLink.click();
 
    await this.page.waitForLoadState('domcontentloaded');
    }
 
    /**
     * Navigate to the noise complaint form
     * Assumes user is already on QNS Home Page
     */
    async navigateToForm() {
        // Verify we're on QNS home page
        const currentUrl = this.page.url();
        if (!currentUrl.includes('qns-home-page')) {
            throw new Error(`Expected to be on QNS home page, but current URL is: ${currentUrl}`);
        }
        
        // Wait for the form to be visible (it should already be on this page)
        await this.dateInput.waitFor({ state: 'visible', timeout: 30000 });
        
        // Verify all key form elements are present
        await expect(this.timeSelect).toBeVisible();
        await expect(this.typeSelect).toBeVisible();
        await expect(this.detailsTextarea).toBeVisible();
        await expect(this.submitButton).toBeVisible();
    }
 
    async verifyAddressFields() {
        await expect(this.addressLine1).toBeVisible();
        await expect(this.addressLine2).toBeVisible();
        await expect(this.postcode).toBeVisible();
    }
 
    async fillDisturbanceDate(date) {
        await this.dateInput.fill(date);
    }
 
    async fillDisturbanceTime(time) {
        await this.timeSelect.selectOption(time);
    }
 
    async selectDisturbanceType(type) {
        await this.typeSelect.selectOption({ label: type });
    }
 
    async fillDisturbanceDetails(details) {
        await this.detailsTextarea.fill(details);
    }
 
    async toggleEmailCopy(checked = true) {
        if (checked) {
            await this.emailCopyCheckbox.check();
        } else {
            await this.emailCopyCheckbox.uncheck();
        }
    }

    async isAddressLine1NonEditable() {
        const isReadonly = await this.addressLine1.getAttribute('readonly');
        const isDisabled = await this.addressLine1.getAttribute('disabled');
        const className = await this.addressLine1.getAttribute('class');
        const hasReadonlyClass = className && className.includes('readonly');
        const isEditable = await this.addressLine1.isEditable().catch(() => false);

        return isReadonly !== null || isDisabled !== null || hasReadonlyClass ||!isEditable;
    }

    async isAddressLine2NonEditable() {
        const isReadonly = await this.addressLine2.getAttribute('readonly');
        const isDisabled = await this.addressLine2.getAttribute('disabled');
        const className = await this.addressLine2.getAttribute('class');
        const hasReadonlyClass = className && className.includes('readonly');
        const isEditable = await this.addressLine2.isEditable().catch(() => false);

        return isReadonly !== null || isDisabled !== null || hasReadonlyClass ||!isEditable;
    }

    async isPostcodeNonEditable() {
        const isReadonly = await this.postcode.getAttribute('readonly');
        const isDisabled = await this.postcode.getAttribute('disabled');
        const className = await this.postcode.getAttribute('class');
        const hasReadonlyClass = className && className.includes('readonly');
        const isEditable = await this.postcode.isEditable().catch(() => false);
        
        return isReadonly !== null || isDisabled !== null || hasReadonlyClass || !isEditable;
    }

    async verifySaveContactCheckboxNotDisplayed() {
        await this.UIHelper.verifyElementIsNotVisible(this.saveContactInfoCheckbox);
    }

    async fillAddressLine1(address1) {
        await this.UIHelper.enterTextForWebElementWithClear(this.addressLine1, address1);
    }

    async fillAddressLine2(address2) {
        await this.UIHelper.enterTextForWebElementWithClear(this.addressLine2, address2);
    }

    async fillPostcode(postcode) {
        await this.UIHelper.verifyElementIsVisible(this.postcode);
        await this.UIHelper.enterTextForWebElementWithClear(this.postcode, postcode);
        await this.page.waitForLoadState('load');
    }
    
    async checkSaveContactInformation() {
        await this.UIHelper.verifyElementIsVisible(this.saveContactInfoCheckbox);
        await this.UIHelper.check(this.saveContactInfoCheckbox);
    }

     /**
     * Go to the noise complaint form
     * This will not Assumes/ asserts user is already on QNS Home Page
     * This will take the user to noise complaint form first
     * And then confirms that the user is on correct page
     */
    async goToNoiseComplaintForm() {
        await this.page.waitForLoadState('load');
        const testDataUtils = await import('../../utils/TestDataUtils.js').then(m => new m.TestDataUtils());
        const qnsUrl = await testDataUtils.getData('qnsHomePage');
        await this.page.goto(qnsUrl, { waitUntil: 'domcontentloaded' });
        await this.page.waitForLoadState('load');
        const isFormVisible = await this.UIHelper.checkElementVisibility(this.dateInput);
            if (isFormVisible) {
                return;
            }
        
        await this.UIHelper.scrollIntoView(this.dateInput);
        await this.page.waitForLoadState('load');
        
        if(await this.UIHelper.verifyElementIsVisible(this.dateInput)){
            return;
        }
        
       await this.UIHelper.verifyElementIsVisible(this.anyDateInput);
    }

    async submitForm() {
        await this.submitButton.click();
        await this.page.waitForTimeout(2000);
    }
 
    async clearField(fieldName) {
        const fieldMap = {
            'date of disturbance': this.dateInput,
            'disturbance time': this.timeSelect,
            'disturbance type': this.typeSelect,
            'disturbance details': this.detailsTextarea
        };
 
        const field = fieldMap[fieldName.toLowerCase()];
        if (field) {
            await field.clear();
            
        }
    }
 
    async clearAllFormFields() {
        await this.dateInput.clear();
        await this.timeSelect.selectOption('');
        await this.typeSelect.selectOption('');
        await this.detailsTextarea.clear();
    }
 
    async verifyValidationErrorFor(fieldName) {
        await this.UIHelper.verifyElementIsVisible(this.errorSummary);
        
        const expectedMessages = {
            'date of disturbance': 'Date of disturbance is required.',
            'disturbance time': 'Disturbance time is required.',
            'disturbance type': 'Disturbance type is required.',
            'disturbance details': 'Disturbance details are required.'
        };
        
        const expectedMessage = expectedMessages[fieldName.toLowerCase()];
        if (expectedMessage) {
            await expect(this.errorSummary).toContainText(expectedMessage);
        }
        
        const fieldMap = {
            'date of disturbance': this.dateFieldInvalid,
            'disturbance time': this.timeFieldInvalid,
            'disturbance type': this.typeFieldInvalid,
            'disturbance details': this.detailsFieldInvalid
        };
        
        const invalidField = fieldMap[fieldName.toLowerCase()];
        if (invalidField) {
            await expect(invalidField).toBeVisible();
        }
    }
 
    async verifyErrorIsRed(fieldName) {
        const color = await this.errorSummaryTitle.evaluate(el =>
            window.getComputedStyle(el).color
        );
        expect(color).toMatch(/rgb\(\s*2[0-9]{2}\s*,\s*[0-9]{1,2}\s*,\s*[0-9]{1,2}\s*\)/);
    }
 
    async verifyAllRequiredFieldErrors() {
        await this.UIHelper.verifyElementIsVisible(this.errorSummary);
        
        // Only verify the 4 editable disturbance fields are marked as invalid
        // (Address fields are read-only and should not have validation errors)
        await expect(this.dateFieldInvalid).toBeVisible();
        await expect(this.timeFieldInvalid).toBeVisible();
        await expect(this.typeFieldInvalid).toBeVisible();
        await expect(this.detailsFieldInvalid).toBeVisible();
        
        // Verify error messages for the 4 required editable fields
        await expect(this.errorSummary).toContainText('Date of disturbance is required');
        await expect(this.errorSummary).toContainText('Disturbance time is required');
        await expect(this.errorSummary).toContainText('Disturbance type is required');
        await expect(this.errorSummary).toContainText('Disturbance details are required');
    }
 
    async verifyAllErrorsAreRed() {
        const titleColor = await this.errorSummaryTitle.evaluate(el =>
            window.getComputedStyle(el).color
        );
        expect(titleColor).toContain('rgb(218, 45, 33)');
        
        const bgColor = await this.errorSummary.evaluate(el =>
            window.getComputedStyle(el).backgroundColor
        );
        expect(bgColor).toContain('rgb(253, 242, 241)');
    }
 
    async verifyNoValidationErrors() {
        await expect(this.errorSummary).not.toBeVisible();
        const invalidFieldCount = await this.invalidFields.count();
        expect(invalidFieldCount).toBe(0);
    }
 
    async verifyFormNotSubmitted() {
        await expect(this.submitButton).toBeVisible();
        const currentUrl = this.page.url();
        expect(currentUrl).toContain('qns-home-page');
    }
 
    async verifyFormSubmitted() {
        await this.page.waitForTimeout(3000);
        const formStillVisible = await this.submitButton.isVisible().catch(() => false);
        if (formStillVisible) {
            const hasErrors = await this.errorSummary.isVisible().catch(() => false);
            expect(hasErrors).toBe(false);
        }
    }
    async getAddressLine1Value() {
        return await this.addressLine1.inputValue();
    }
 
    async getAddressLine2Value() {
        return await this.addressLine2.inputValue();
    }
 
    async getPostcodeValue() {
        return await this.postcode.inputValue();
    }
 
   
   

    // ========== Story 752889: Date and Time Capture Methods ==========

    async verifyDateFieldIsDateInput() {
        const inputType = await this.dateInput.getAttribute('type');
        expect(inputType).toBe('date');
    }

    async getTimeOptions() {
        const options = await this.timeSelect.locator('option').allTextContents();
        return options.filter(opt => {
            const trimmed = opt.trim();
            return trimmed !== '' && trimmed.match(/^\d{1,2}:\d{2}$/);
        });
    }

    async verifyTimeOptionsAre15MinuteIncrements() {
        const options = await this.getTimeOptions();
        expect(options.length).toBeGreaterThan(0);
        const validMinutes = ['00', '15', '30', '45'];
        for (const option of options) {
            const parts = option.split(':');
            if (parts.length === 2) {
                const minutes = parts[1];
                expect(validMinutes.includes(minutes)).toBeTruthy();
            }
        }
    }

    async verifyTimeOptionsAre24HourFormat() {
        const options = await this.getTimeOptions();
        for (const option of options) {
            expect(option.toLowerCase()).not.toContain('am');
            expect(option.toLowerCase()).not.toContain('pm');
            expect(option).toMatch(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/);
        }
    }

    async getDateFieldValue() {
        return await this.dateInput.inputValue();
    }

    async getTimeFieldValue() {
        return await this.timeSelect.inputValue();
    }

    // ========== Story 752890: Disturbance Type and Details Methods ==========

    async openDisturbanceTypeDropdown() {
        await this.typeSelect.click();
        await this.page.waitForTimeout(500); // Wait for dropdown to expand
    }

    async getDisturbanceTypeOptions() {
        const options = await this.typeSelect.locator('option').allTextContents();
        // Filter out empty options and placeholder text
        return options.filter(opt => {
            const trimmed = opt.trim();
            return trimmed !== '' && trimmed !== 'Type';
        });
    }

    async verifyDisturbanceTypeOptions(expectedOptions) {
        const actualOptions = await this.getDisturbanceTypeOptions();
        
        // Verify we have all expected options
        expect(actualOptions.length).toBeGreaterThanOrEqual(expectedOptions.length);
        
        // Verify each expected option exists
        for (const expectedOption of expectedOptions) {
            expect(actualOptions).toContain(expectedOption);
        }
    }

    async fillAddressLine1IfEmpty()
    {
        const testDataUtils = await import('../../utils/TestDataUtils.js').then(m => new m.TestDataUtils());
        const testData = await testDataUtils.getQNSMyAccountData();
        const currentAddressLine1 = await this.getAddressLine1Value();
        const isAddressLine1Readonly = await this.isAddressLine1NonEditable();
        if (isAddressLine1Readonly) {
            return;
        }
       
        if (!currentAddressLine1 || currentAddressLine1.trim() === '') {
            const testAddressLine1 = testData.noiseComplaintSubmission.addressLine1;
            await this.fillAddressLine1(testAddressLine1);
            this.submittedAddressLine1 = testAddressLine1;
        } else {
            this.submittedAddressLine1 = currentAddressLine1;
        }
    }

    async fillPostcodeIfEmpty()
    {
        const testDataUtils = await import('../../utils/TestDataUtils.js').then(m => new m.TestDataUtils());
        const testData = await testDataUtils.getQNSMyAccountData();
        const currentPostcode = await this.getPostcodeValue();
        const isPostcodeReadonly = await this.isPostcodeNonEditable();
        if (isPostcodeReadonly) {
            return;
        }
       
        if (!currentPostcode || currentPostcode.trim() === '') {
            const testPostcode = testData.noiseComplaintSubmission.postcode;
            await this.fillPostcode(testPostcode);
            this.submittedPostcode = testPostcode;
        } else {
            this.submittedPostcode = currentPostcode;
        }
    }
    

    async verifyFieldsPrePopulatedWithSavedData(expectedAddressLine1, expectedAddressLine2, expectedPostcode) {
        if (expectedAddressLine1 && expectedAddressLine1.trim() !== '') {
            const actualAddressLine1 = await this.getAddressLine1Value();
            if (actualAddressLine1 && actualAddressLine1.trim() !== '') {
                expect(actualAddressLine1).toContain(expectedAddressLine1);
            } 
        }
        
        if (expectedAddressLine2 && expectedAddressLine2.trim() !== '') {
            const actualAddressLine2 = await this.getAddressLine2Value();
            if (actualAddressLine2 && actualAddressLine2.trim() !== '') {
                expect(actualAddressLine2).toContain(expectedAddressLine2);
            } 
        }
        
        if (expectedPostcode && expectedPostcode.trim() !== '') {
            const actualPostcode = await this.getPostcodeValue();
            if (actualPostcode && actualPostcode.trim() !== '') {
                expect(actualPostcode).toBe(expectedPostcode);
            } 
        }
    }

    async verifyAllPrePopulatedFieldsNonEditable(fields) {
        for (const fieldName of fields) {
            let isNonEditable = false;
            
            if (fieldName.toLowerCase().includes('address line 1')) {
                isNonEditable = await this.isAddressLine1NonEditable();
                expect(isNonEditable).toBe(true);
            } else if (fieldName.toLowerCase().includes('address line 2')) {
                isNonEditable = await this.isAddressLine2NonEditable();
                expect(isNonEditable).toBe(true);
            } else if (fieldName.toLowerCase().includes('postcode')) {
                isNonEditable = await this.isPostcodeNonEditable();
                expect(isNonEditable).toBe(true);
            }
        }
    }

    async getDisturbanceDetailsValue() {
        return await this.detailsTextarea.inputValue();
    }

    // ========== Story 752893: Email Copy Checkbox Methods ==========

    async verifyEmailCopyCheckboxVisible() {
        await expect(this.emailCopyCheckbox).toBeVisible();
    }

    async verifyEmailCopyCheckboxUnchecked() {
        await expect(this.emailCopyCheckbox).not.toBeChecked();
    }

    async verifyEmailCopyCheckboxChecked() {
        await expect(this.emailCopyCheckbox).toBeChecked();
    }
}
 
export default NoiseComplaintFormPage;
