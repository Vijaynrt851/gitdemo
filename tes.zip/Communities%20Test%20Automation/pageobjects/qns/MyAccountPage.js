import { expect } from '@playwright/test';
import UIHelper from '../../utils/UIHelper.js';

class MyAccountPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);

        this.userMenuButton = this.page.locator('button:has(span.slds-assistive-text:has-text("User Menu"))');
        this.myProfileLink = this.page.getByText('My Profile', { exact: true });
        this.myAccountPageTitle = this.page.getByRole('heading', { name: 'My Account' });

        this.fullNameField = this.page.getByText('Full Name').locator('..').locator('input, span, div').last();
        this.emailField = this.page.getByText('Email').locator('..').locator('input, span, div').last();

        this.addressLine1Field = this.page.getByText('Address Line 1').locator('..').locator('input, span, div').last();
        this.addressLine2Field = this.page.getByText('Address Line 2').locator('..').locator('input, span, div').last();
        this.postcodeField = this.page.getByText('Mailing Zip/Postal Code').locator('..').locator('input, span, div').last();

        this.editButton = this.page.getByRole('button', { name: 'Edit' }).or(this.page.locator('button.slds-button_brand[type="button"]:has-text("Edit")')); 
        this.firstNameMyAcc = this.page.getByLabel('First Name', { exact: false }).or(this.page.locator('input[name="FirstName"]'));
        this.lastNameMyAcc = this.page.getByLabel('Last Name', { exact: false }).or(this.page.locator('input[name="LastName"]'));
        this.emailMyAcc = this.page.getByLabel('Email', { exact: false }).or(this.page.locator('input[name="Email"]'));
        this.mobilePhoneMyAcc = this.page.getByLabel(/Mobile.*Phone/i).or(this.page.locator('input[name="MobilePhone"]'));
        this.homePhoneMyAcc = this.page.getByLabel(/Home.*Phone/i).or(this.page.locator('input[name="HomePhone"]'));
        this.addressLine1MyAcc = this.page.locator('textarea[name="MailingStreet"]');
        this.addressLine2MyAcc = this.page.getByLabel(/Address.*Line.*2/i).or(this.page.locator('textarea[name="QNS_AddressLine2__c"]'));
        this.mailingCityMyAcc = this.page.getByLabel(/Mailing.*City/i).or(this.page.locator('input[name="MailingCity"]'));
        this.mailingStateMyAcc = this.page.getByLabel(/Mailing.*State/i).or(this.page.locator('input[name="MailingState"]'));
        this.mailingCountryMyAcc = this.page.getByLabel(/Mailing.*Country/i).or(this.page.locator('input[name="MailingCountry"]'));
        this.postcodeMyAcc = this.page.getByLabel(/Mailing.*Zip.*Postal.*Code/i).or(this.page.locator('input[name="MailingPostalCode"]'));
        this.saveChangesButton = this.page.getByRole('button', { name: /Save.*changes/i }).or(this.page.locator('button.slds-button_brand[type="submit"]:has-text("Save changes")'));

        this.accountDetailsContainer = this.page.locator('.account-details, .my-account-details, [data-component="account-details"]');
    }

    async openMyAccount() {
       await this.UIHelper.clickOnWebElement(this.userMenuButton);
       await this.page.waitForLoadState('load');
       await this.UIHelper.clickOnWebElement(this.myProfileLink);
       await this.page.waitForLoadState('domcontentloaded');
    }

    async verifyMyAccountPageDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.myAccountPageTitle);
    }

    async getFieldValue(fieldName) {
        const fieldMap = {
            'full name': this.fullNameField,
            'email': this.emailField,
            'mobile phone': this.mobilePhoneMyAcc,
            'address line 1': this.addressLine1Field,
            'address line 2': this.addressLine2Field,
            'postcode': this.postcodeField,
            'address line 1 myacc': this.addressLine1MyAcc,
            'address line 2 myacc': this.addressLine2MyAcc,
            'postcode myacc': this.postcodeMyAcc,
            'edit button': this.editButton,
            'save changes button': this.saveChangesButton
        };

        const field = fieldMap[fieldName.toLowerCase()];
        if (!field) {
            throw new Error(`Field '${fieldName}' not found in field map`);
        }

        const tagName = await field.evaluate(el => el.tagName.toLowerCase());
        if (tagName === 'input' || tagName === 'textarea') {
            return await field.inputValue();
        }
        return await this.UIHelper.getTextContentOfWebElement(field);
    }

    async verifyFieldIsVisible(fieldName) {
        const fieldMap = {
            'full name': this.fullNameField,
            'email': this.emailField,
            'mobile phone': this.mobilePhoneMyAcc,
            'address line 1': this.addressLine1Field,
            'address line 2': this.addressLine2Field,
            'postcode': this.postcodeField,
            'address line 2 myacc': this.addressLine2MyAcc,
            'postcode myacc': this.postcodeMyAcc,
            'edit button': this.editButton,
            'save changes button': this.saveChangesButton
        };

        const field = fieldMap[fieldName.toLowerCase()];
        if (!field) {
            throw new Error(`Field '${fieldName}' not found in field map`);
        }

        await this.UIHelper.verifyElementIsVisible(field);
    }

    async verifyFieldIfSupplied(fieldName) {
        const fieldMap = {
            'mobile phone': this.mobilePhoneMyAcc,
            'home phone': this.homePhoneMyAcc,
            'email': this.emailMyAcc,
            'address line 1': this.addressLine1Field,
            'mailing city': this.mailingCityMyAcc,
            'mailing state': this.mailingStateMyAcc,
            'mailing country': this.mailingCountryMyAcc,
            'address line 2': this.addressLine2Field,
            'postcode': this.postcodeField
        };

        const field = fieldMap[fieldName.toLowerCase()];
        if (!field) {
            throw new Error(`Field '${fieldName}' not found in optional field map`);
        }

       const isVisible = await this.UIHelper.checkElementVisibility(field);
       if (isVisible) {
            const value = await this.getFieldValue(fieldName);
            if (!value || value.trim().length === 0) {
            }
        }
    }
    

    async verifyAllAccountDetailsDisplayed(fieldNames) {
        for (const fieldData of fieldNames) {
            const fieldName = fieldData['Field Name'];
            
            if (['full name', 'email'].includes(fieldName.toLowerCase())) {
                await this.verifyFieldIsVisible(fieldName);
            } else {
                await this.verifyFieldIfSupplied(fieldName);
            }
        }
    }

    async clickEditButton() {
      await this.UIHelper.clickOnWebElement(this.editButton);
    }

    async clearFieldIfNotEmpty(field) {
        let element;
        if (field === 'addressLine1MyAcc') {
            element = this.addressLine1MyAcc;
        } else if (field === 'addressLine2MyAcc') {
            element = this.addressLine2MyAcc;
        } else if (field === 'postcodeMyAcc') {
            element = this.postcodeMyAcc;
        } else {
            throw new Error(`Unknown field: ${field}`);
        }   
        
        await this.UIHelper.verifyElementIsVisible(element);
        
        const value = await element.inputValue();
        if (value && value.trim() !== '') {
            await this.UIHelper.clearWebElement(element);
        }
    }

    async clickSaveChanges() {
        await this.UIHelper.verifyElementIsVisible(this.saveChangesButton);
        await this.UIHelper.scrollIntoView(this.saveChangesButton);
        
        // Save button responds reliably to keyboard activation
        await this.saveChangesButton.focus();
        await this.saveChangesButton.press('Enter');
        await this.page.waitForLoadState('domcontentloaded');
    }

    async ensurePersonalDetailsExist(testData) {
        await this.clickEditButton();
        let addressLine1 = await this.getFieldValue('address line 1 myacc');
        let addressLine2 = await this.getFieldValue('address line 2 myacc');
        let postcode = await this.getFieldValue('postcode myacc');
        let changesMade = false;
        if (!addressLine1 || addressLine1.trim() === '') {
            await this.UIHelper.enterTextForWebElementWithClear(this.addressLine1MyAcc,testData.addressLine1);
            addressLine1 = testData.addressLine1;
            changesMade = true;
        }
        if (!addressLine2 || addressLine2.trim() === '') {
            await this.UIHelper.enterTextForWebElementWithClear(this.addressLine2MyAcc,testData.addressLine2);
            addressLine2 = testData.addressLine2;
            changesMade = true;
        }
        if (!postcode || postcode.trim() === '') {
            await this.UIHelper.enterTextForWebElementWithClear(this.postcodeMyAcc,testData.postcode);
            postcode = testData.postcode;
            changesMade = true;
        }
        if (changesMade) {
            await this.clickSaveChanges();
            await this.verifyMyAccountPageDisplayed();
        } else {
            await this.clickSaveChanges();
        }
        return {
            addressLine1,
            addressLine2,
            postcode
        };
    }

    async clearAllEditableFields() {
        await this.UIHelper.verifyElementIsVisible(this.firstNameMyAcc);
        
        const fieldsArray = [
            this.firstNameMyAcc,
            this.lastNameMyAcc,
            this.emailMyAcc,
            this.mobilePhoneMyAcc,
            this.homePhoneMyAcc,
            this.addressLine1MyAcc,
            this.addressLine2MyAcc,
            this.mailingCityMyAcc,
            this.mailingStateMyAcc,
            this.mailingCountryMyAcc,
            this.postcodeMyAcc
        ];
        
        for (const field of fieldsArray) {
            const isVisible = await this.UIHelper.checkElementVisibility(field);
            if (isVisible) {
                await this.UIHelper.clearWebElement(field);
            }
        }
    }

    async fillMandatoryFieldsOnly(testData) {
        await this.UIHelper.verifyElementIsVisible(this.lastNameMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.lastNameMyAcc, testData.lastName);
    }

    async fillCompletePersonalDetails(testData) {
        await this.UIHelper.verifyElementIsVisible(this.firstNameMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.firstNameMyAcc, testData.firstName);
        
        await this.UIHelper.verifyElementIsVisible(this.lastNameMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.lastNameMyAcc, testData.lastName);
        
        await this.UIHelper.verifyElementIsVisible(this.emailMyAcc);
        await this.UIHelper.enterTextForWebElement(this.emailMyAcc, testData.email);
        
        await this.UIHelper.verifyElementIsVisible(this.mobilePhoneMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.mobilePhoneMyAcc, testData.mobilePhone);
        
        await this.UIHelper.verifyElementIsVisible(this.homePhoneMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.homePhoneMyAcc, testData.homePhone);
        
        await this.UIHelper.verifyElementIsVisible(this.addressLine1MyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.addressLine1MyAcc, testData.addressLine1);
        
        await this.UIHelper.verifyElementIsVisible(this.addressLine2MyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.addressLine2MyAcc, testData.addressLine2);
        
        await this.UIHelper.verifyElementIsVisible(this.mailingCityMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.mailingCityMyAcc, testData.mailingCity);
        
        await this.UIHelper.verifyElementIsVisible(this.mailingStateMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.mailingStateMyAcc, testData.mailingState);
        
        await this.UIHelper.verifyElementIsVisible(this.mailingCountryMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.mailingCountryMyAcc, testData.mailingCountry);
        
        await this.UIHelper.verifyElementIsVisible(this.postcodeMyAcc);
        await this.UIHelper.enterTextForWebElementWithClear(this.postcodeMyAcc, testData.postcode);
    }

    async verifySaveButtonDisabledOrValidationDisplayed() {
        const isSaveButtonDisabled = await this.saveChangesButton.isDisabled().catch(() => false);
        
        if (!isSaveButtonDisabled) {
            await this.UIHelper.clickOnWebElement(this.saveChangesButton);
            await this.page.waitForLoadState('load');
            
            const validationMessage = this.page.getByText('Complete this field.');
            const hasValidation = await this.UIHelper.checkElementVisibility(validationMessage);
            
            if (!hasValidation) {
                const currentUrl = this.page.url();
                const stillOnEditMode = currentUrl.includes('edit') || await this.UIHelper.checkElementVisibility(this.saveChangesButton);
                
                if (stillOnEditMode) {
                    expect(stillOnEditMode).toBe(true);
                } else {
                    expect(hasValidation).toBe(true);
                }
            } else {
                expect(hasValidation).toBe(true);
            }
        }
    }

    async getFieldValueFromMyAccount(fieldName) {
        const fieldMap = {
            'first name': this.firstNameMyAcc,
            'last name': this.lastNameMyAcc,
            'email': this.emailMyAcc,
            'mobile phone': this.mobilePhoneMyAcc,
            'home phone': this.homePhoneMyAcc,
            'address line 1': this.addressLine1MyAcc,
            'address line 2': this.addressLine2MyAcc,
            'mailing city': this.mailingCityMyAcc,
            'mailing state': this.mailingStateMyAcc,
            'mailing country': this.mailingCountryMyAcc,
            'postcode': this.postcodeMyAcc
        };

        const field = fieldMap[fieldName.toLowerCase()];
        if (!field) {
            throw new Error(`Field '${fieldName}' not found in field map`);
        }

        const tagName = await field.evaluate(el => el.tagName.toLowerCase());
        if (tagName === 'input' || tagName === 'textarea') {
            return await field.inputValue();
        }
        return await this.UIHelper.getTextContentOfWebElement(field);
    }

    async verifyMandatoryFieldsSaved(testData) {
        await this.verifyMyAccountPageDisplayed();
        await this.clickEditButton();
        const lastName = await this.getFieldValueFromMyAccount('last name');
        expect(lastName).toBe(testData.lastName);
    }

    async verifyAllPersonalDetailsSaved(testData) {
        await this.verifyMyAccountPageDisplayed();
        await this.clickEditButton();
        expect((await this.getFieldValueFromMyAccount('first name')).trim()).toBe(testData.firstName.trim());
        expect((await this.getFieldValueFromMyAccount('last name')).trim()).toBe(testData.lastName.trim());
        expect((await this.getFieldValueFromMyAccount('email')).trim()).toBe(testData.email.trim());
        expect((await this.getFieldValueFromMyAccount('mobile phone')).trim()).toBe(testData.mobilePhone.trim());
        expect((await this.getFieldValueFromMyAccount('home phone')).trim()).toBe(testData.homePhone.trim());
        expect((await this.getFieldValueFromMyAccount('address line 1')).trim()).toContain(testData.addressLine1.trim());
        expect((await this.getFieldValueFromMyAccount('address line 2')).trim()).toContain(testData.addressLine2.trim());
        expect((await this.getFieldValueFromMyAccount('mailing city')).trim()).toBe(testData.mailingCity.trim());
        expect((await this.getFieldValueFromMyAccount('mailing state')).trim()).toBe(testData.mailingState.trim());
        expect((await this.getFieldValueFromMyAccount('mailing country')).trim()).toBe(testData.mailingCountry.trim());
        expect((await this.getFieldValueFromMyAccount('postcode')).trim()).toBe(testData.postcode.trim());
    }

}

export default MyAccountPage;