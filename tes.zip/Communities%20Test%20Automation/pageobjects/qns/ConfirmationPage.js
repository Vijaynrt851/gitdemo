import UIHelper from '../../utils/UIHelper.js';

export default class ConfirmationPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        this.initializeLocators();
    }

    initializeLocators() {
        this.confirmationHeading = this.page.getByText('Noise complaint submitted', { exact: false }).first();
        this.thankYouMessage = this.page.getByText('Thank you for your complaint', { exact: false }).first();
        this.emailMessage = this.page.getByText('email will be sent to you shortly', { exact: false }).first();
        this.referenceNumberMessage = this.page.getByText('reference number', { exact: false }).first();
        
        this.confirmationMessage = this.page.locator(
            'text="Noise complaint submitted", ' +
            'text="Thank you for your complaint", ' +
            'text="This has been logged"'
        ).first();
       
        this.submitNewQueryButton = this.page.getByText('Submit new query', { exact: true });
        this.dateInput = this.page.locator('input[type="date"], input[id*="date"]').first();
    }

    async verifyConfirmationPageDisplayed() {
        await this.page.waitForLoadState('load');
        try {
            await this.UIHelper.verifyElementIsVisible(this.confirmationHeading);
        } catch (error) {
            try {
                await this.UIHelper.verifyElementIsVisible(this.thankYouMessage);
            } catch (error2) {
                const anyConfirmation = this.page.locator('text=/complaint|submitted|thank you/i').first();
                await this.UIHelper.verifyElementIsVisible(this.anyConfirmation);
            }
        }
    }

    async verifySuccessMessage(expectedMessage = 'Thank you for your complaint') {
     await this.UIHelper.verifyElementIsVisible(this.confirmationMessage);
     const messageText = await this.UIHelper.getTextContentOfWebElement(this.confirmationMessage);
        return messageText;
    }

    async verifySubmitNewQueryButtonDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.submitNewQueryButton);
    }

    async clickSubmitNewQuery() {
        await this.UIHelper.verifyElementIsVisible(this.submitNewQueryButton);
        await this.UIHelper.clickOnWebElement(this.submitNewQueryButton);
        await this.page.waitForLoadState('load');
    }

}