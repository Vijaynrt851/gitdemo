import { expect } from '@playwright/test';
import UIHelper from '../../utils/UIHelper.js';

class HomePageQns {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);

        // Key Policies section main Components
        this.keyPoliciesSectionHeading = this.page.getByText('Staying informed', { exact: false });
        this.keyPoliciesHeading = this.page.getByRole('heading', { name: /Key Policies and Processes/i });
        this.keyPoliciesDescription = this.page.locator('p.qns-intro',{hasText: 'Everything from complaints handling to aircraft performance'});
        this.keyPoliciesComplaintsPolicyHeader = this.page.getByRole('button', {name: 'Complaints policy'}).first();
        this.keyPoliciesContactingOtherOrgsHeader = this.page.getByRole('button', {name: 'Contacting other organisations'}).first();
        this.keyPoliciesMonitoringAircraftHeader = this.page.getByRole('button', {name: 'Monitoring and improving aircraft performance'}).first();
        this.keyPoliciesRestrictionOnNightFlightsHeader = this.page.getByRole('button', {name: 'Restrictions on night flights'}).first();
        
        // Complaints policy section link
        this.keyPoliciesComplaintsPolicyButton = this.page.locator('span.anchor-text-wrp.icon-left:has-text("Complaints Policy")');
        
        // Contacting other organisations section links
        this.keyPoliciesCAALink = this.page.locator('a[href*="caa.co.uk"]');
        this.keyPoliciesDfTLink = this.page.locator('a[href*="gov.uk/dft"]');
        this.keyPoliciesNATSLink = this.page.locator('a[href*="nats.aero"]');
        this.keyPoliciesGatwickAirportLink = this.page.getByRole('link', { name: 'Gatwick Airport' });
        this.keyPoliciesLondonCityAirportLink = this.page.getByRole('link', { name: 'London City Airport' });
        this.keyPoliciesLutonAirportLink = this.page.getByRole('link', { name: 'Luton Airport' });
        
       // Restrictions on night flights section link
        this.keyPoliciesRestrictNightFlightsLink = this.page.locator('a[href*="night-flights"]');
    }
     
    async verifyKeyPoliciesComponentDisplayed(componentType,componentName) {
        if (componentType === 'Section Heading') {
            await this.UIHelper.scrollIntoView(this.keyPoliciesSectionHeading);
            await this.UIHelper.verifyElementIsVisible(this.keyPoliciesSectionHeading);
            const text = await this.UIHelper.getTextContentOfWebElement(this.keyPoliciesSectionHeading);
            expect(text).toContain('Staying informed');
        } 
        else if (componentType === 'Main Heading') {
            await this.UIHelper.scrollIntoView(this.keyPoliciesHeading);
            await this.UIHelper.verifyElementIsVisible(this.keyPoliciesHeading);
            const text = await this.UIHelper.getTextContentOfWebElement(this.keyPoliciesHeading);
            expect(text).toContain('Key policies and processes');
        } 
        else if (componentType === 'Description') {
            const text = await this.UIHelper.getTextContentOfWebElement(this.keyPoliciesDescription);
            expect(text).toContain('Everything from complaints handling to aircraft performance, the topics that matter most during your relocation journey.');
        } 
        else if (componentType === 'Accordion Header') {
            await this.verifyKeyPoliciesAccordionHeaderDisplayed(componentName);
        }
    }

    async verifyKeyPoliciesAccordionHeaderDisplayed(headerName) {
        await this.UIHelper.scrollIntoView(this.keyPoliciesHeading);
        const headerMap = {
            'Complaints policy': this.keyPoliciesComplaintsPolicyHeader,
            'Contacting other organisations': this.keyPoliciesContactingOtherOrgsHeader,
            'Monitoring and improving aircraft performance': this.keyPoliciesMonitoringAircraftHeader,
            'Restrictions on night flights': this.keyPoliciesRestrictionOnNightFlightsHeader
        };

        const header = headerMap[headerName];
        if (!header) {
            throw new Error(`Accordion header '${headerName}' not found in header map`);
        }

        await this.UIHelper.verifyElementIsVisible(header);
    }
    
    async verifyKeyPoliciesAccordionExpandCollapse(headerName) {
        await this.UIHelper.scrollIntoView(this.keyPoliciesHeading);
        const headerMap = {
            'Complaints policy': this.keyPoliciesComplaintsPolicyHeader,
            'Contacting other organisations': this.keyPoliciesContactingOtherOrgsHeader,
            'Monitoring and improving aircraft performance': this.keyPoliciesMonitoringAircraftHeader,
            'Restrictions on night flights': this.keyPoliciesRestrictionOnNightFlightsHeader};

        const header = headerMap[headerName];
        await this.clickKeyPoliciesAccordionHeader(headerName);
        await expect(header).toHaveAttribute('aria-expanded','true');
        await this.clickKeyPoliciesAccordionHeader(headerName);
        await expect(header).toHaveAttribute('aria-expanded','false');
    }
    
    async clickKeyPoliciesAccordionHeader(headerName) {
        const headerMap = {
            'Complaints policy': this.keyPoliciesComplaintsPolicyHeader,
            'Contacting other organisations': this.keyPoliciesContactingOtherOrgsHeader,
            'Monitoring and improving aircraft performance': this.keyPoliciesMonitoringAircraftHeader,
            'Restrictions on night flights': this.keyPoliciesRestrictionOnNightFlightsHeader
        };

        const header = headerMap[headerName];
        if (!header) {
            throw new Error(`Accordion header '${headerName}' not found in header map`);
        }

        await this.UIHelper.scrollIntoView(header);
        await this.UIHelper.clickOnWebElement(header);
    }
    
    async openExternalLink(linkLocator) {
        await this.UIHelper.scrollIntoView(linkLocator);
        const [newPage] = await Promise.all([this.page.context().waitForEvent('page'),this.UIHelper.clickOnWebElement(linkLocator)]);
        await newPage.waitForLoadState('domcontentloaded');
        return newPage;
    }
    
    async verifyExternalTabOpened(newPage, expectedUrl) {
        await newPage.waitForLoadState();
        const currentUrl = newPage.url();
        expect(currentUrl).toContain(expectedUrl);
        await newPage.close();
    }
    
    async clickKeyPoliciesExternalLink(linkName) {
        let locator;
        if (linkName === 'Complaints Policy') {
            locator = this.keyPoliciesComplaintsPolicyButton;
        } else if (linkName === 'CAA') {
            locator = this.keyPoliciesCAALink;
        } else if (linkName === 'DfT') {
            locator = this.keyPoliciesDfTLink;
        } else if (linkName === 'NATS') {
            locator = this.keyPoliciesNATSLink;
        } else if (linkName === 'Gatwick Airport') {
            locator = this.keyPoliciesGatwickAirportLink;
        } else if (linkName === 'London City Airport') {
            locator = this.keyPoliciesLondonCityAirportLink;
        } else if (linkName === 'Luton Airport') {
            locator = this.keyPoliciesLutonAirportLink;
        } else if (linkName === 'Night Flights') {
            locator = this.keyPoliciesRestrictNightFlightsLink;
        }
        if (!locator) {
            throw new Error(`No locator found for linkName: ${linkName}`);
        }
        return await this.openExternalLink(locator);
        
    }
    
}

export default HomePageQns;