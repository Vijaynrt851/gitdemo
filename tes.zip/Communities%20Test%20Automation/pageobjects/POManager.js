import { CommonPageObjects } from './CommonPageObjects.js';
import { LoginPage } from './LoginPage.js';
import { FaqPage } from './FaqPage.js';
import { MyProfilePage } from './MyProfilePage.js';
import { SubmitQueryPage } from './SubmitQueryPage.js';
import { HomePage } from './HomePage.js';
import NoiseComplaintFormPage from './qns/NoiseComplaintFormPage.js';
import MyAccountPage from './qns/MyAccountPage.js';
import ConfirmationPage from './qns/ConfirmationPage.js';
import HomePageQns from './qns/HomePageQns.js';

class POManager {
    constructor(page) {
        this.page = page;
        this.CommonPageObjects = new CommonPageObjects(this.page);
        this.LoginPage = new LoginPage(this.page);
        this.FaqPage = new FaqPage(this.page);
        this.MyProfilePage = new MyProfilePage(this.page);
        this.SubmitQueryPage = new SubmitQueryPage(this.page);
        this.HomePage = new HomePage(this.page);
        this.NoiseComplaintFormPage = new NoiseComplaintFormPage(this.page);
        this.MyAccountPage = new MyAccountPage(this.page);
        this.ConfirmationPage = new ConfirmationPage(this.page);
        this.HomePageQns = new HomePageQns(this.page);
    }

    getDemoQAPage() {
        return this.DemoQAPage;
    }

    getCommonPageObjects() {
        return this.CommonPageObjects;
    }

    getDemoQAElementPage() {
        return this.DemoQAElementPage;
    }

    getLoginPage() {
        return this.LoginPage;
    }

    getFaqPage() {
        return this.FaqPage;
    }

    getMyProfilePage() {
        return this.MyProfilePage;
    }

    getSubmitQueryPage() {
        return this.SubmitQueryPage;
    }

    getHomePage() {
        return this.HomePage;
    }

    getNoiseComplaintFormPage() {
        return this.NoiseComplaintFormPage;
    }

    getMyAccountPage() {
        return this.MyAccountPage;
    }

    getConfirmationPage() {
        return this.ConfirmationPage;
    }

    getHomePageQns() {
        return this.HomePageQns;
    }
}

export { POManager };
