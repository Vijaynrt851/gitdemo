import { test, expect } from '@playwright/test';
import UIHelper from '../utils/UIHelper.js';
import { TestDataUtils } from '../utils/TestDataUtils.js';

const testDataUtils = new TestDataUtils();

class CommonPageObjects {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        this.elements = page.locator("div.card.mt-4.top-card").first();
    }

    async launchUrl(url) {
            console.log(' URL ------------------- ', url);
            await this.page.goto(await testDataUtils.getData(url), { waitUntil: 'load', timeout: 60000 });
    }
}

export { CommonPageObjects };
