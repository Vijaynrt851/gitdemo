class supplierLoginPage {

    constructor(page) {
        this.page = page;

        this.userName = page.getByRole('textbox', {
            name: 'Username'
        });

        this.password = page.getByRole('textbox', {
            name: 'Password'
        });

        this.loginBtn = page.getByRole('button', {
            name: 'Log In'
        });
    }

    async navigateToApplication() {
        await this.page.goto(process.env.URL);
    }

    async login(username, password) {
        console.log('LOGIN DEBUG: Attempting login with:', username);
        await this.userName.fill(username);
        await this.password.fill(password);
        await this.loginBtn.click();
    }
}

export default supplierLoginPage;