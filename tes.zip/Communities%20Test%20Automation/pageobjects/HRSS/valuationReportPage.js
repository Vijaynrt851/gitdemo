class ValuationReportPage {

    constructor(page) {

        this.page = page;

        this.searchBox =
            page.getByRole('searchbox', {
                name: 'Search deliverables'
            });

        this.submitReportButton =
            page.getByRole('button', {
                name: 'Submit report'
            });
    }

    async openValuationReport(deliverableId) {

        await this.searchBox.fill(deliverableId);

        await this.submitReportButton.click();
    }

    async selectOption(fieldName, value) {

        await this.page
            .getByRole('combobox', {
                name: fieldName
            })
            .click();

        await this.page
            .getByRole('option', {
                name: value,
                exact: true
            })
            .click();
    }

    async completeValuationReport(testData) {

        // Report Details

        await this.page
            .getByLabel('*Report Prepared By')
            .fill(testData.reportDetails.reportPreparedBy);

        await this.page
            .getByLabel('*Purpose of Valuation')
            .fill(testData.reportDetails.purposeOfValuation);


        await this.page
            .locator('lightning-input[data-field="inspectionDate"] input')
            .fill(testData.reportDetails.inspectionDate);

        await this.page
            .locator('lightning-input[data-field="valuationDate"] input')
            .fill(testData.reportDetails.valuationDate);

        await this.page
            .locator('lightning-input[data-field="preparedByDate"] input')
            .fill(testData.reportDetails.preparedByDate);


        await this.selectOption(
            'Tenure Type',
            testData.reportDetails.tenureType
        );

        await this.selectOption(
            'Property Type',
            testData.reportDetails.propertyType
        );

        await this.selectOption(
            'Legal Issues Identified',
            testData.reportDetails.legalIssuesIdentified
        );


        // Property Details

        await this.page
            .getByLabel('*Reduced Height Area (sq ft)')
            .fill(testData.propertyDetails.reducedHeightArea);

        await this.page
            .getByLabel('*Private Garage Area (sq ft)')
            .fill(testData.propertyDetails.privateGarageArea);

        await this.page
            .getByLabel('*Location Description')
            .fill(testData.propertyDetails.locationDescription);

        await this.page
            .getByLabel('*Property Description')
            .fill(testData.propertyDetails.propertyDescription);

        await this.page
            .getByLabel('*Accommodation Details')
            .fill(testData.propertyDetails.accommodationDetails);

        await this.page
            .getByLabel('*Commentary on State of Repair')
            .fill(testData.propertyDetails.commentaryOnRepair);

        await this.page
            .getByLabel('*Town Planning & Building Regulations')
            .fill(testData.propertyDetails.townPlanningBuildingRegulations);

        await this.page
            .getByLabel('*Energy & Environmental')
            .fill(testData.propertyDetails.energyEnvironmental);

        await this.page
            .getByLabel('*Services & Amenities')
            .fill(testData.propertyDetails.servicesAmenities);

        await this.page
            .getByLabel('*Tenure')
            .fill(testData.propertyDetails.tenure);


        // Comparable Sales

        for (let i = 0; i < testData.comparableSales.length; i++) {

            const sale = testData.comparableSales[i];

            await this.page
                .locator('lightning-input[data-field="flatNumber"] input')
                .nth(i)
                .fill(sale.flatNumber);

            await this.page
                .locator('lightning-input[data-field="buildingName"] input')
                .nth(i)
                .fill(sale.buildingName);

            await this.page
                .locator('lightning-input[data-field="streetNumber"] input')
                .nth(i)
                .fill(sale.streetNumber);

            await this.page
                .locator('lightning-input[data-field="streetName"] input')
                .nth(i)
                .fill(sale.streetName);

            await this.page
                .locator('lightning-input[data-field="saleDate"] input')
                .nth(i)
                .fill(sale.saleDate);

            await this.page
                .locator('lightning-input[data-field="postcode"] input')
                .nth(i)
                .fill(sale.postcode);

            await this.page
                .locator('lightning-input[data-field="salePrice"] input')
                .nth(i)
                .fill(sale.salePrice);

            await this.page
                .locator('lightning-input[data-field="grossInternalArea"] input')
                .nth(i)
                .fill(sale.grossInternalArea);

            await this.page
                .locator('lightning-input[data-field="bedrooms"] input')
                .nth(i)
                .fill(sale.bedrooms);

            await this.page
                .locator('lightning-textarea[data-field="description"] textarea')
                .nth(i)
                .fill(sale.description);

            await this.page
                .locator('lightning-textarea[data-field="comparisonWithSubject"] textarea')
                .nth(i)
                .fill(sale.comparisonWithSubject);
        }


        // Market Value Section

        await this.page
            .locator('lightning-input[data-field="marketValue"] input')
            .fill(testData.marketValueSection.marketValue);

        await this.page
            .locator('lightning-input[data-field="marketValueWords"] input')
            .fill(testData.marketValueSection.marketValueWords);

        await this.page
            .locator('lightning-textarea[data-field="areasNotInspected"] textarea')
            .fill(testData.marketValueSection.areasNotInspected);

        await this.page
            .locator('lightning-input[data-field="approverName"] input')
            .fill(testData.marketValueSection.approverName);

        await this.page
            .locator('lightning-input[data-field="approverEmail"] input')
            .fill(testData.marketValueSection.approverEmail);


        // RICS

        await this.page
            .locator('lightning-combobox[data-field="valuerRICSQual"] button')
            .click();

        await this.page
            .getByRole('option', { name: testData.ricsDetails.valuerRICSQual })
            .click();


        await this.page
            .locator('lightning-combobox[data-field="approverRICSQual"] button')
            .click();

        await this.page
            .getByRole('option', { name: testData.ricsDetails.approverRICSQual })
            .click();


        await this.page
            .locator('lightning-input[data-field="approverRICSNumber"] input')
            .fill(testData.ricsDetails.approverRICSNumber);

        await this.page
            .locator('lightning-input[data-field="valuerRICSNumber"] input')
            .fill(testData.ricsDetails.valuerRICSNumber);

        await this.page
            .locator('lightning-input[data-field="approverJobTitle"] input')
            .fill(testData.ricsDetails.approverJobTitle);

        await this.page
            .locator('lightning-input[data-field="valuerJobTitle"] input')
            .fill(testData.ricsDetails.valuerJobTitle);
    }
}

export default ValuationReportPage;