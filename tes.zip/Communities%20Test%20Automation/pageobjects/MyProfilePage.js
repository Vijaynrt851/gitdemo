import { test, expect } from '@playwright/test';
import UIHelper from '../utils/UIHelper.js';
import { TestDataUtils } from '../utils/TestDataUtils.js';

const testDataUtils = new TestDataUtils();

class MyProfilePage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        // TODO: Replace with actual locators
        this.profileIcon = this.page.locator('[data-testid="profile-icon"]');
        this.myProfilePageTitle = this.page.locator('//h1[contains(text(),"My Profile")]');
        this.nameField = this.page.locator('[data-testid="profile-name"]');
        this.emailField = this.page.locator('[data-testid="profile-email"]');
        this.phoneField = this.page.locator('[data-testid="profile-phone"]');
        this.editButton = this.page.locator('button:has-text("Edit")');
        this.editProfilePageTitle = this.page.locator('//h1[contains(text(),"Edit Profile")]');
    }

    async clickOnProfileIcon() {
        await this.page.waitForLoadState('load');
        await this.UIHelper.clickOnWebElement(this.profileIcon);
    }

    async verifyMyProfilePageDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.myProfilePageTitle);
    }

    async verifyMyDetailsDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.nameField);
        await this.UIHelper.verifyElementIsVisible(this.emailField);
        await this.UIHelper.verifyElementIsVisible(this.phoneField);
    }

    async clickOnEditButton() {
        await this.page.waitForLoadState('load');
        await this.UIHelper.clickOnWebElement(this.editButton);
    }

    async verifyEditProfilePageDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.editProfilePageTitle);
    }
}

export { MyProfilePage };