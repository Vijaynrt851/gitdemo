import UIHelper from '../utils/UIHelper.js';
import { TestDataUtils } from '../utils/TestDataUtils.js';

const testDataUtils = new TestDataUtils();

class SubmitQueryPage {
    constructor(page) {
        this.page = page;
        this.UIHelper = new UIHelper(this.page);
        this.queryTitle = this.page.locator('//input[@name="Subject"]');
        this.queryDescription = this.page.locator('//textarea');
        this.submitButton = this.page.locator('//div[contains(@class,"navigation")]//button');
        this.queryTitleErrorMessage = this.page.locator('//input[@name="Subject" and @aria-invalid="true"]');
        this.queryDescriptionErrorMessage = this.page.locator('//textarea[@aria-invalid="true"]');
        this.successMessage = this.page.locator('//div[contains(@class,"container")]//strong');
        // Case list & case comment locators
        this.caseListSortByDateButton = this.page.getByRole('button', { name: 'Sort by: Date/Time Opened' });
        this.firstCaseRow = this.page
            .locator('tr[data-row-key-value]:not([data-row-key-value="HEADER"])')
            .first()
            .getByRole('link')
            .first();
        this.caseDetailsHeading = this.page.getByRole('heading', { name: 'Case details' });
        this.caseDiscussionHeading = this.page.getByRole('heading', { name: 'Case Discussion' });
        this.commentInput = this.page.getByRole('textbox', { name: 'Add an update' });
        this.postCommentButton = this.page.getByRole('button', { name: 'Post' });
        this.commentText = '';
    }

    async clickSubmitButtonWithoutData() {
        await this.page.waitForLoadState('load');
        await this.UIHelper.clickOnWebElement(this.submitButton);
    }

    async verifyErrorMessagesForAllRequiredFields() {
        await this.UIHelper.verifyElementIsVisible(this.queryTitleErrorMessage);
        await this.UIHelper.verifyElementIsVisible(this.queryDescriptionErrorMessage);
    }

    async enterAllRequiredFieldsAndSubmit() {
        await this.page.waitForLoadState('load');
        const timestamp = testDataUtils.getCurrentTimestamp();
        await this.UIHelper.enterTextForWebElementWithClear(
            this.queryTitle,
            `This is a test query subject - automation - ${timestamp}`
        );
        await this.UIHelper.enterTextForWebElementWithClear(
            this.queryDescription,
            `This is a test query description - automation - ${timestamp}`
        );
        await this.UIHelper.clickOnWebElement(this.submitButton);
    }

    async verifySuccessMessageDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.successMessage);
    }

    async sortCaseListByDate() {
        await this.page.waitForLoadState('load');
        await this.UIHelper.scrollIntoView(this.caseListSortByDateButton);
        await this.UIHelper.clickOnWebElement(this.caseListSortByDateButton);
    }

    async clickOnFirstCaseInList() {
        await this.UIHelper.clickOnWebElement(this.firstCaseRow);
    }

    async verifyCaseDetailsDisplayed() {
        await this.UIHelper.verifyElementIsVisible(this.caseDiscussionHeading);
        await this.UIHelper.verifyElementIsVisible(this.caseDetailsHeading);
    }

    async enterCommentAndClickSubmit() {
        this.commentText = await `Test comment added by automation - ${testDataUtils.getCurrentTimestamp()}`;
        await this.UIHelper.enterTextForWebElementWithClear(this.commentInput, this.commentText);
        await this.UIHelper.clickOnWebElement(this.postCommentButton);
    }

    async verifyCommentAddedSuccessfully() {
        const addedComment = await this.page.getByText(this.commentText, { exact: true });
        await this.UIHelper.verifyElementIsVisible(addedComment);
    }
}

export { SubmitQueryPage };
