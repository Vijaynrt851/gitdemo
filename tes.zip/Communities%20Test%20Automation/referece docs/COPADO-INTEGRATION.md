# Copado Integration

How a Copado deployment triggers this test suite.

## Flow

```
Copado promotion deployed to ExpQA01 / ExpSIT01 / ExpUAT01
        │
        ▼
Copado Function "Trigger Communities Sanity Tests"
        │  reads the global System Property AZURE_PAT
        ▼
POST /_apis/pipelines/2678/runs      ("Copado Post-Deploy Sanity")
        │  templateParameters: ENV + Copado deployment context
        ▼
Cucumber @sanity suite against the environment that was just deployed to
        │
        ▼
JUnit results + Cucumber HTML + Allure published on the Azure DevOps run
```

The handoff is **non-blocking**: the function returns as soon as the run is queued
and never waits for the suite. A failing suite turns the Azure DevOps run red; it
does not fail or roll back the Copado deployment.

## Environment mapping

| Copado environment | Environment record Id | `ENV` parameter | `NODE_ENV` | Test data file | Site under test |
| --- | --- | --- | --- | --- | --- |
| ExpQA01 | `a0fRz000008MDA5IAO` | `QA` | `QA` | `QA_env_test_data.yml` | `heathrowexpansion--expqa01.sandbox.my.site.com` |
| ExpSIT01 | `a0fRz000008MGj3IAG` | `SIT` | `SIT` | `SIT_env_test_data.yml` | `heathrowexpansion--expsit01.sandbox.my.site.com` |
| ExpUAT01 | `a0fRz000008MFztIAG` | `UAT` | `UAT` | `UAT_env_test_data.yml` | `heathrowexpansion--expuat01.sandbox.my.site.com` |

All three use the **site root**, no `/hrs` or other path suffix.

One thing to be aware of on UAT: at the time of writing, `expuat01`'s root redirects
to a *Parking Complaint Form* community, while QA and SIT roots both serve *Heathrow
Community Portal* — the portal the `@sanity` feature exercises. If UAT runs fail at
the login step, that is the likely reason, and the fix is on the org side rather than
in this repo.

Test data files live in `testData/uidata/`. `TestDataUtils` resolves both the data
file and the credentials from `NODE_ENV`, so adding an environment means adding a
`<ENV>_env_test_data.yml` file and a `<ENV>_USERNAME` / `<ENV>_PASSWORD` secret —
no code change.

There is **no fallback to another environment's data file**. A missing file throws.
Falling back is how the original SIT bug hid: a run labelled SIT read the QA file,
tested the QA org and reported green for an environment nobody had touched.

## Azure DevOps setup

**Pipeline** — *Copado Post-Deploy Sanity*, definition id `2678`,
YAML `pipeline/azure/copado-post-deploy-sanity.yml`. `trigger: none`; it only runs
when something queues it.

**Secret variables** on that definition (Pipeline → Edit → Variables, tick *Keep
this value secret*):

| Variable | Value |
| --- | --- |
| `QA_USERNAME` / `QA_PASSWORD` | Portal test user on ExpQA01 |
| `SIT_USERNAME` / `SIT_PASSWORD` | Portal test user on ExpSIT01 |
| `UAT_USERNAME` / `UAT_PASSWORD` | Portal test user on ExpUAT01 |

**Personal access token** for Copado to call the REST API: scope
**Build (read and execute)**, on a service account rather than a person so the
integration survives leavers.

## The REST call Copado makes

```
POST https://dev.azure.com/heathrow/HALCOM%20-%20Communities/_apis/pipelines/2678/runs?api-version=7.1
Authorization: Basic base64(":<PAT>")
Content-Type: application/json
```

```json
{
  "resources": { "repositories": { "self": { "refName": "refs/heads/main" } } },
  "templateParameters": {
    "ENV": "SIT",
    "TAGS": "@sanity",
    "CUCUMBER_BROWSER": "chromium",
    "PARALLEL_THREAD": "2",
    "COPADO_DEPLOYMENT_ID": "a0dRz00000A3s1JIAR",
    "COPADO_PROMOTION": "P26985",
    "COPADO_RELEASE": "HRSS Sprint 3"
  }
}
```

All `templateParameters` values must be **strings**, including `PARALLEL_THREAD`.
`ENV` is constrained to `QA`, `SIT`, `UAT`; anything else is rejected at compile
time with a clear error.

The Copado values are cosmetic but worth passing — they name the run
(`SIT-sanity-a0dRz00000A3s1JIAR-20260818.1`) and land in the report metadata as
`RELEASE` and `CYCLE`, so a red run can be traced to the promotion that caused it.

## CopadoTower setup

CopadoTower (`copadotower.my.salesforce.com`, org `00D8e000000KG4YEAW`) is a
**shared production org** serving Customer Org, VIP, Halo, Noise & Vortex, Retail
Manager and Communities. There is no metadata deploy access to it, so everything
here is built from records through the Salesforce/Copado UI.

### Built already

**System Property `AZURE_PAT`** (`a1qRz0000095VyrIAE`) — global, sensitive, already
in place and already used by the `Deploy_EXPQA01` / `Deploy_EXPSIT01` functions.
Reused as-is; nothing to create.

**Function `Trigger Communities Sanity Tests`** (`a0oRz000009CQ3NIAW`, API name
`Trigger_Communities_Sanity_Tests`) — image `copado-multicloud-dx:v6`, worker `S`.
Queues pipeline 2678 for the environment just deployed to and returns immediately;
it never waits for the suite, so a failing test can't fail the Copado job.

| Parameter | Default |
| --- | --- |
| `azure_pat` | `{$Global.Property.AZURE_PAT}` |
| `target_env` | `QA` |
| `tags` | `@sanity` |
| `browser` | `chromium` |
| `parallel_threads` | `2` |
| `deployment_id` / `promotion_name` / `release_name` | `manual` / `manual` / `N/A` |

The function is **not referenced by anything yet**, so it is inert. It can be run
by hand from the Function record at any time.

### How it is triggered: a Function step on the deployment

Communities releases are run as Copado Deployments whose work is a **Function step** —
e.g. deployment `a0dRz000009oEiXIAU` has `Step 1`, type `Function`, running
`Deploy_EXPQA01`. The sanity trigger is simply **Step 2 on the same deployment**, so
it runs straight after the metadata lands, with no pipeline changes at all.

On the Deployment record, **Add Step**:

| Field | Value |
| --- | --- |
| Step Name | `Sanity Tests` |
| Type | `Function` |
| Function | `Trigger Communities Sanity Tests` |
| `target_env` | `QA`, `SIT` or `UAT` — must match the environment being deployed to |

Leave `azure_pat` at its default `{$Global.Property.AZURE_PAT}`. The resulting
step config looks like:

```json
{
  "functionAPIName": "Trigger_Communities_Sanity_Tests",
  "functionParameters": [
    { "name": "azure_pat", "value": "{$Global.Property.AZURE_PAT}" },
    { "name": "target_env", "value": "QA" },
    { "name": "tags", "value": "@sanity" },
    { "name": "browser", "value": "chromium" },
    { "name": "parallel_threads", "value": "2" }
  ]
}
```

Steps run in order, so put it **after** the deploy step. If the deploy step fails,
the sanity step never runs — which is what you want.

**The step cannot fail the deployment.** The function exits 0 even when Azure DevOps
rejects the request, reporting the problem in the step Result instead. Failing a
deployment whose metadata went in cleanly, because a test-trigger callout didn't,
would be the wrong trade.

Add the step per deployment, the same way `Step 1` is added today. Cloning a previous
deployment carries both steps over.

### Trigger options that don't work here

| Route | Verdict |
| --- | --- |
| Quality Gate Rule | `Quality_Gate_Rule__c.Tool__c` is a fixed picklist — Copado Robotic Testing, PMD, Apex Tests, Checkmarx, Flow Tests, Pull Request. No generic or external-CI option. |
| Automation Rule | Needs an Apex connector alongside the org's `ACCommitToRunQG` / `ACPromotionDeploymentToRunQG`; Apex can't be authored in a production org's UI. |
| Deployment Task (Type `Function`, After Deployment) | `Deployment_Task__c.User_Story__c` is required, so it would have to go on every user story. |
| Pipeline Action override | Would work and is fully automatic, but replaces the packaged `SFDX Deploy` template for those environments — the team would then own a copy of it. Only worth it if the per-deployment step becomes a chore. |

## Running it by hand

Azure DevOps → Pipelines → *Copado Post-Deploy Sanity* → **Run pipeline**, then
pick the environment. The Copado parameters default to `manual`.

Locally:

```bash
npm run sanity:sit
```

with `SIT_USERNAME` / `SIT_PASSWORD` exported (see `.env.example`).

## Coverage

Only `features/Login_welcome.feature` carries `@sanity` today: login, then the
Case List, Submit Query and Complaints tabs. The other portal features are tagged
`@loginToWelcome`. To widen a post-deploy run, either tag more features `@sanity`
or pass a different `TAGS` expression (for example `@sanity or @loginToWelcome`).

## Troubleshooting

| Symptom | Cause |
| --- | --- |
| Step result says `not-queued`, httpCode 302 | PAT expired or missing **Build (read and execute)** — Azure DevOps redirects to a login page |
| `A template expression is not valid` | `ENV` outside `QA`/`SIT`/`UAT`, or a non-string parameter |
| `Missing credentials for environment: X` | `X_USERNAME` / `X_PASSWORD` not set on the pipeline definition |
| `No test data file for environment X` | `X_env_test_data.yml` doesn't exist. Add it rather than reusing another environment's. |
| Run is green but no tests ran | Tag expression matched nothing; check the *Tests* tab |
