# Architecture Overview — Communities Test Automation

This project is a **hybrid test automation framework** combining:
- **Cucumber-JS (BDD)** for Gherkin-driven UI/API tests using the **Page Object Model (POM)**
- **Playwright Test Runner** for standalone spec-based UI tests (visual regression, e2e)

## 🏗️ Layered Architecture

```mermaid
graph TB
    subgraph L1["Test Specification Layer"]
        FEAT["Feature Files<br/>(*.feature - Gherkin)<br/>features/*.feature"]
        SPEC["Playwright Specs<br/>tests/*.spec.js"]
    end

    subgraph L2["Execution Glue Layer"]
        STEPS["Step Definitions<br/>features/step_definitions/*-steps.js"]
        WORLD["World Context<br/>features/support/world.js<br/>(CustomWorld: page, context, poManager)"]
        HOOKS["Hooks<br/>features/support/hooks.js<br/>(BeforeAll/Before/AfterStep/After/AfterAll)"]
        PWCONFIG["playwright.config.js<br/>(projects: chromium, firefox, webkit, mobile...)"]
    end

    subgraph L3["Page Object Layer"]
        POM["POManager.js<br/>(centralized PO factory)"]
        PAGES["Page Objects<br/>LoginPage, FaqPage, MyProfilePage,<br/>SubmitQueryPage, CommonPageObjects,<br/>NoiseComplaintFormPage, DemoQA*"]
    end

    subgraph L4["Utility / Helper Layer"]
        UIH["UIHelper.js<br/>(generic Playwright actions)"]
        BU["BrowserUtils.js<br/>(browser lifecycle, BrowserStack)"]
        TDU["TestDataUtils.js<br/>(env-based test data)"]
        APIU["APiUtils.js<br/>(REST calls: GET/POST/PUT/DELETE)"]
        AH["AccessibilityHelper.js<br/>(axe-core scans)"]
        SH["ScreenshotHelper.js"]
        VH["VideoHelper.js"]
        VCH["VisualComparisonHelper.js"]
    end

    subgraph L5["Data Layer"]
        UIDATA["testData/uidata/*.yml<br/>(QA/SIT/UAT/STAGE/PROD)"]
        APIDATA["testData/apidata/{ENV}/*.json"]
        ENV[".env / process.env<br/>NODE_ENV, BROWSER, credentials"]
    end

    subgraph L6["Driver / Runtime Layer"]
        PW["Playwright Engine<br/>(chromium/firefox/webkit)"]
        BS["BrowserStack<br/>(cloud grid, optional)"]
    end

    subgraph L7["Reporting Layer"]
        CUCREP["Cucumber HTML/JSON/JUnit<br/>+ Allure Cucumber"]
        MULTIREP["reporter.js →<br/>multiple-cucumber-html-reporter"]
        PWREP["Playwright HTML/JUnit Reporter"]
        AXEREP["generateAxeReport.js<br/>(axe-html-reporter)"]
    end

    FEAT --> STEPS
    STEPS --> WORLD
    STEPS --> POM
    HOOKS -->|"initializes"| WORLD
    HOOKS -->|"creates"| BU
    HOOKS --> SH
    HOOKS --> VH
    POM --> PAGES
    PAGES --> UIH
    PAGES --> TDU
    STEPS --> APIU
    UIH --> PW
    BU --> PW
    BU -.->|"cloud mode"| BS
    TDU --> UIDATA
    TDU --> ENV
    APIU --> APIDATA
    SPEC --> PWCONFIG
    PWCONFIG --> PW
    HOOKS --> CUCREP
    CUCREP --> MULTIREP
    SPEC --> PWREP
    AH --> AXEREP
    HOOKS --> AH
```

## 🔄 Execution Flow (Cucumber Scenario Lifecycle)

```mermaid
sequenceDiagram
    participant CJS as cucumber-js Runner
    participant Hook as hooks.js
    participant World as CustomWorld
    participant BUtil as BrowserUtils
    participant PWEngine as Playwright Browser
    participant Step as Step Definition
    participant POM as POManager
    participant Page as Page Object
    participant UIHelper as UIHelper
    participant Data as TestDataUtils/YAML

    CJS->>Hook: BeforeAll (launch browser, write execution-info.json)
    Hook->>BUtil: getBrowser()
    BUtil->>PWEngine: chromium/firefox/webkit.launch()
    CJS->>Hook: Before (per scenario)
    Hook->>World: create context, page
    Hook->>POM: new POManager(page)
    POM->>Page: instantiate all Page Objects
    CJS->>Step: Execute Gherkin step
    Step->>POM: getLoginPage()
    Step->>Page: page method call e.g. enterUsernameAndPassword()
    Page->>Data: getUsernameAndPassword()
    Page->>UIHelper: enterTextForWebElementWithClear()
    UIHelper->>PWEngine: locator.fill()/click()
    CJS->>Hook: AfterStep (screenshot per step, on failure)
    CJS->>Hook: After (close context, save video)
    CJS->>Hook: AfterAll (close browser)
    Hook-->>CJS: reports/cucumber_report.json, junit, allure
```

## 📦 Module Responsibilities

| Layer | Files | Responsibility |
|---|---|---|
| **Config** | `cucumber.js`, `playwright.config.js` | Test runner config, tags, parallelism, browser projects |
| **World/Hooks** | `features/support/world.js`, `features/support/hooks.js` | Shared scenario context (`this.page`, `this.poManager`) + lifecycle (browser launch/close, screenshots, video) |
| **Step Definitions** | `features/step_definitions/login-steps.js`, `faq-steps.js`, `myprofile-steps.js`, etc. | Bind Gherkin steps to Page Object methods via `this.poManager` |
| **Page Object Manager** | `pageobjects/POManager.js` | Single source for instantiating/retrieving all page objects |
| **Page Objects** | `pageobjects/LoginPage.js`, `pageobjects/CommonPageObjects.js`, `FaqPage.js`, `MyProfilePage.js`, `SubmitQueryPage.js`, `NoiseComplaintFormPage.js` | Locators + page-specific actions, built on UIHelper |
| **Utils** | `utils/UIHelper.js`, `utils/BrowserUtils.js`, `utils/TestDataUtils.js`, `utils/APiUtils.js`, `AccessibilityHelper.js`, `ScreenshotHelper.js`, `VideoHelper.js`, `VisualComparisonHelper.js` | Cross-cutting reusable logic: generic UI actions, browser/BrowserStack management, env-driven data loading, REST API calls, a11y scans, screenshot/video capture, visual diffing |
| **Test Data** | `testData/uidata/{ENV}_env_test_data.yml`, `testData/apidata/{ENV}/*.json` | Environment-scoped (QA/SIT/UAT/STAGE/PROD) UI & API fixtures |
| **Playwright Specs** | `tests/*.spec.js` | Standalone Playwright-native tests (e2e, visual comparison) run via `playwright.config.js` (independent of Cucumber pipeline) |
| **Reporting** | `reporter.js`, `generateAxeReport.js`, Allure/JUnit/HTML outputs | Post-run report generation and aggregation |

## 🔑 Key Architectural Patterns
- **Page Object Model (POM)** centralized via `POManager` — step definitions never touch Playwright locators directly.
- **Custom World** (`CustomWorld`) shares `page`, `context`, `poManager`, `apiUtils` across steps in a scenario.
- **Environment-driven configuration** — `NODE_ENV` selects both credentials (`{ENV}_USERNAME`/`{ENV}_PASSWORD`) and data files (YAML/JSON), enabling QA/SIT/UAT/STAGE/PROD runs without code changes.
- **Dual execution modes**: Cucumber-JS (BDD, tag-driven: `@sanity`, `@regression`, `@smoke`) and native Playwright Test (spec-driven, project-based browser matrix).
- **Cross-browser & cloud support**: local (chromium/firefox/webkit/mobile emulation) or BrowserStack via `BrowserUtils`.
- **Observability**: per-step/scenario screenshots, video capture on failure, accessibility (axe-core) scans, and multi-format reporting (HTML, JUnit, Allure).
