import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load .env from project root
dotenv.config({ path: join(__dirname, '../../.env') });

import { test } from '@playwright/test';
import LoginPage from '../../pageobjects/HRSS/supplierLoginPage.js';
import ValuationReportPage from '../../pageobjects/HRSS/valuationReportPage.js';

// Load test data
const valuationReportDataPath = join(__dirname, '../../testData/hrss/valuationReportData.json');
const valuationReportData = JSON.parse(fs.readFileSync(valuationReportDataPath, 'utf-8'));

// Load user credentials
const userCredentialsPath = join(__dirname, '../../testData/hrss/userCredentials.json');
const userCredentials = JSON.parse(fs.readFileSync(userCredentialsPath, 'utf-8'));

// Test each valuation report from test data
valuationReportData.forEach((testCase, index) => {
    test(`${testCase.testCaseName}`, async ({ page }) => {

        console.log(`\n========== Starting Test: ${testCase.testCaseId} ==========`);
        console.log('DEBUG: URL =', process.env.URL);

        // Get corresponding user credentials
        const userCredential = userCredentials[index];
        console.log('DEBUG: Username =', userCredential.username);
        console.log('DEBUG: User Role =', userCredential.userRole);

        const loginPage = new LoginPage(page);
        const valuationPage = new ValuationReportPage(page);

        await loginPage.navigateToApplication();

        await loginPage.login(userCredential.username, userCredential.password);

        console.log(`Opening Valuation Report: ${testCase.deliverableId}`);
        await valuationPage.openValuationReport(testCase.deliverableId);

        console.log(`Completing Valuation Report with test data: ${testCase.testCaseId}`);
        await valuationPage.completeValuationReport(testCase);

        console.log(`========== Test ${testCase.testCaseId} Completed Successfully ==========\n`);

    });
});