   import { test, expect } from '@playwright/test';
   import { POManager } from '../pageobjects/POManager.js';

test("@WebPopup Popup validations",async({page})=>
{
    const poManager = new POManager(page);
    const practicePage = poManager.getPracticePage();
    await practicePage.goTo()
    await practicePage.verifyDisplayText()
    await practicePage.clickOnHideTextBox();
    await practicePage.verifyTextHidden();
    page.on('dialog',dialog => dialog.accept());
    await practicePage.clickOnConfirmbutton
    await practicePage.mouseHover();
    await practicePage.checkTextContentFromIFrame()
})

test("@Screenshot & Visual comparision",async({page})=>
{
    const poManager = new POManager(page);
    const practicePage = poManager.getPracticePage();
    await practicePage.goTo()
    await practicePage.verifyDisplayText()
    await page.locator('#displayed-text').screenshot({path:'./test-results/partialScreenshot.png'});
    await practicePage.clickOnHideTextBox();
    await page.screenshot({path: 'screenshot.png'});
    await expect(page.locator("#displayed-text")).toBeHidden();
});





