/**
 * Playwright Test for Visual Comparison
 * 
 * This test uses Playwright's native toHaveScreenshot() API which requires
 * execution through the Playwright Test Runner (not Cucumber).
 * 
 * Reuses existing framework components:
 * - TestDataUtils for environment configuration and URL resolution
 * - Existing test data YAML files for URL lookup
 * - VisualComparisonHelper for page preparation ONLY
 * 
 * Visual assertions are performed directly using Playwright's native API:
 *   await expect(page).toHaveScreenshot(...);
 * 
 * Execution:
 * - Normal run: npx playwright test visual-comparison.spec.js
 * - Update baselines: UPDATE_SNAPSHOTS=true npx playwright test visual-comparison.spec.js
 */

import { test, expect } from '@playwright/test';
import { TestDataUtils } from '../utils/TestDataUtils.js';
import { VisualComparisonHelper } from '../utils/VisualComparisonHelper.js';

const testDataUtils = new TestDataUtils();
const visualHelper = new VisualComparisonHelper();

test.describe('Visual Comparison Tests', () => {
  
  test('Heathrow Homepage Visual Comparison', { tag: '@TEST' }, async ({ page }) => {
    // Reuse existing framework's URL resolution
    const homeUrl = await testDataUtils.getData('demoUrl');
    
    // Navigate to the application
    await page.goto(homeUrl, { waitUntil: 'load', timeout: 60000 });
    
    // Prepare page for visual comparison using utility
    await visualHelper.preparePage(page, {
      hiddenSelectors: [], // Add selectors for dynamic elements if needed
      disableAnimations: true,
      scrollToTop: true
    });
    
    // Perform visual comparison using Playwright's native assertion
    await expect(page).toHaveScreenshot('heathrow-homepage.png', {
      fullPage: true
    });
  });
  
  test('Heathrow Departures Page Visual Comparison', async ({ page }) => {
    // Reuse existing framework's URL resolution
    const departuresUrl = await testDataUtils.getData('flightUrl');
    
    // Navigate to the departures page
    await page.goto(departuresUrl, { waitUntil: 'load', timeout: 60000 });
    
    // Prepare page for visual comparison
    await visualHelper.preparePage(page);
    
    // Perform visual comparison using Playwright's native assertion
    await expect(page).toHaveScreenshot('heathrow-departures.png', {
      fullPage: true
    });
  });
  
});
