import { test, expect } from '@playwright/test';
import { TestDataUtils } from '../utils/TestDataUtils.js';
import { VisualComparisonHelper } from '../utils/VisualComparisonHelper.js';
import {LoginPage} from '../pageobjects/LoginPage.js';

const testDataUtils = new TestDataUtils();
const visualHelper = new VisualComparisonHelper();
const homePage = String(await testDataUtils.getData('homePage'));
console.log('homePage URL ------------------- ', homePage);
test.describe('Visual Comparison Tests', () => {
  
  test('Heathrow HRSS Homepage Visual Comparison', { tag: '@visual' }, async ({ page }) => {
    // Reuse existing framework's URL resolution
    //const homeUrl = await testDataUtils.getData('homePage');
    
    // Navigate to the application
    await page.goto(homePage, { waitUntil: 'load', timeout: 60000 });
    
    // Prepare page for visual comparison using utility
    await visualHelper.preparePage(page, {
      hiddenSelectors: [], // Add selectors for dynamic elements if needed
      disableAnimations: true,
      scrollToTop: true
    });
    
    // Perform visual comparison using Playwright's native assertion
    await expect(page).toHaveScreenshot('heathrow-hrss-homepage.png', {
      fullPage: true
    });
  });
  
  test('Heathrow HRSS Welcome Page Visual Comparison', { tag: '@visual' },async ({ page }) => {
    // Reuse existing framework's URL resolution
    //const homePage = await testDataUtils.getData('homePage');
    
    // Navigate to the departures page
    await page.goto(homePage, { waitUntil: 'load', timeout: 60000 });
    
    // Prepare page for visual comparison using utility
    await visualHelper.preparePage(page, {
      hiddenSelectors: [], // Add selectors for dynamic elements if needed
      disableAnimations: true,
      scrollToTop: true
    });

const loginPage = new LoginPage(page);
    await loginPage.enterUsernameAndPassword();
    await loginPage.clickLoginButton();
    await loginPage.verifySuccessfulLogin();
    
    // Perform visual comparison using Playwright's native assertion
    await expect(page).toHaveScreenshot('heathrow-hrss-welcome.png', {
      fullPage: true
    });
  });
  
});
